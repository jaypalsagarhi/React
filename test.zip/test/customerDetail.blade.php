<div class="modal fade" id="openCustomerDetails" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog custom-width" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <!-- <h5 class="modal-title" id="example-Modal3">New message</h5> -->
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="card-body">
                <div class="panel panel-primary">
                    <div class=" tab-menu-heading">
                        <div class="tabs-menu1 ">
                            <!-- Tabs -->
                            <ul class="nav panel-tabs">
                                <li><a href="#tab5" class="active" data-bs-toggle="tab">Customer Details</a></li>
                                <li><a href="#tab6" data-bs-toggle="tab">Order History</a></li>
                                <li><a href="#tab7" data-bs-toggle="tab">Recharge History</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="panel-body tabs-menu-body">
                        <div class="tab-content">
                            <div class="tab-pane active " id="tab5">
                                <div class="modal-body table-responsive b_tbl_responsive">
                                    <form>
                                        <table class="table table-bordered text-nowrap table-striped border-bottom">
                                            <tbody>
                                                <tr>
                                                    <th colspan="8">Personal Details</th>
                                                </tr>
                                                <tr>
                                                    <td>Mobile Number:</i></td>
                                                    <td id="cusMobileNo"></td>
                                                    <td>Alternate Number:</td>
                                                    <td id="cusAlternateNo"></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td>Name:</td>
                                                    <td id="cusCustomerName"></td>
                                                    <td>Email:</td>
                                                    <td id="cusEmailId"></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td>Customer Category:</td>
                                                    <td id="cusCustomerCategory" colspan="7"></td>
                                                </tr>
                                                <tr>
                                                    <td>Address:</td>
                                                    <td id="cusAddressDetails" colspan="7"></td>
                                                </tr>
                                                <tr>
                                                    <th colspan="8">eKYC Details:</th>
                                                </tr>
                                                <tr>
                                                    <td>eKYC Status:</td>
                                                    <td id="cusEkycStatus"></td>
                                                    <td>eKYC Date Time:</td>
                                                    <td id="cusEkycDateTime"></td>
                                                    <td>Vendor:</td>
                                                    <td id="cusVendor"></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <th colspan="8">Order Details</th>
                                                </tr>
                                                <tr>
                                                    <td>Consignment No:</td>
                                                    <td id="cusConsignmentNo"></td>
                                                    <td>Status:</td>
                                                    <td id="cusStatus"></td>
                                                    <td>Serial Number:</td>
                                                    <td id="cusSerialNumber"></td>
                                                    <td>Challan Number:</td>
                                                    <td id="cusChallanNumber"></td>
                                                </tr>
                                                <tr>
                                                    <td>Challan Date:</td>
                                                    <td id="cusChallanDate"></td>
                                                    <td>ETD:</td>
                                                    <td id="cusEtd"></td>
                                                    <td>ETI:</td>
                                                    <td id="cusEti"></td>
                                                    <td>Pending Reason:</td>
                                                    <td id="cusPendingReason"></td>
                                                </tr>
                                                <tr>
                                                    <th colspan="8">Delivery Details</th>
                                                </tr>
                                                <tr>
                                                    <td>Delivery Name:</td>
                                                    <td id="cusDeliveryName"></td>
                                                    <td>Mobile Number:</td>
                                                    <td id="cusMobileNumber_del"></td>
                                                    <td>SAP User ID:</td>
                                                    <td id="cusSapUserId"></td>
                                                    <td>Delivery time:</td>
                                                    <td id="cusDeliveryTime"></td>
                                                </tr>
                                                <tr>
                                                    <th colspan="8">Pickup Details</th>
                                                </tr>
                                                <tr>
                                                    <td>Full Name:</td>
                                                    <td id="cusFullName"></td>
                                                    <td>Mobile Number:</td>
                                                    <td id="cusMobileNumbera"></td>
                                                    <td>Serial Number:</td>
                                                    <td id="cusSerialNumber"></td>
                                                    <td>Status:</td>
                                                    <td id="cusPickupStatus"></td>
                                                </tr>
                                                <tr>
                                                    <td>Cancelled Date:</td>
                                                    <td id="cusCancelledDate"></td>
                                                    <td>Cancel Category:</td>
                                                    <td id="cusCancelCategory"></td>
                                                    <td>Cancel Reason:</td>
                                                    <td id="cusCancelReason"></td>
                                                    <td>Pincode:</td>
                                                    <td id="cusPincode"></td>
                                                </tr>
                                                <tr>
                                                    <td>Consumer City</td>
                                                    <td id="cusConsumerCity"></td>
                                                    <td>Hub code:</td>
                                                    <td id="cusHubCode"></td>
                                                    <td>Email:</td>
                                                    <td id="cusEmail"></td>
                                                    <td>Transaction Date:</td>
                                                    <td id="cusTransactionDate"></td>
                                                </tr>
                                                <tr>
                                                    <td>Person Met:</td>
                                                    <td id="cusPersonMet"></td>
                                                    <td>Pickup Date Fareye:</td>
                                                    <td id="cusPickupDateFareye"></td>
                                                    <td>PickUp Challan:</td>
                                                    <td id="cusPickupChallan"></td>
                                                    <td>Consumer Address:</td>
                                                    <td id="cusConsumerAddress"></td>
                                                </tr>
                                                <tr>
                                                    <th colspan="8">Refund Details</th>
                                                </tr>
                                                <tr>
                                                    <td>Ticket No:</td>
                                                    <td id="cusTicketNo"></td>
                                                    <td>Reason:</td>
                                                    <td id="cusReason"></td>
                                                    <td>Remarks:</td>
                                                    <td id="cusRemarks"></td>
                                                    <td>Enter Remarks:</td>
                                                    <td id="cusEnterRemarks"></td>
                                                </tr>
                                                <tr>
                                                    <th colspan="8">Refund Details</th>
                                                </tr>
                                                <tr>
                                                    <td>Status:</td>
                                                    <td colspan="7"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </form>
                                </div>
                            </div>
                            <div class="tab-pane " id="tab6">
                                <div class="modal-body table-responsive b_tbl_responsive">
                                    <table class="table table-bordered text-nowrap table-striped border-bottom">
                                        <tbody>
                                            <tr>
                                                <th colspan="6">Personal Details Recharge</th>
                                            </tr>
                                            <tr>
                                                <td>Mobile Number:</i></td>
                                                <td id="ohMobileNo"></td>
                                                <td>Alternate Number:</td>
                                                <td id="ohAlternateNo"></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>Name: </td>
                                                <td id="ohCustomerName"></td>
                                                <td>Email: </td>
                                                <td id="ohEmailId"></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <th colspan="6">Asset Details</th>
                                            </tr>
                                            <tr>
                                                <td>Asset Name:</i></td>
                                                <td id="ohAssetName"></td>
                                                <td>Purchase Date:</td>
                                                <td id="ohPurchaseDate"></td>
                                                <td>Business Type:</td>
                                                <td id="ohBusinessType"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <div class="table-responsive">
                                        <table class="table border text-nowrap text-md-nowrap mb-0">
                                            <thead class="table-primary">
                                                <tr>
                                                    <th>Ticket No</th>
                                                    <th>Date</th>
                                                    <th>Status</th>
                                                    <th>Description</th>
                                                    <th>Assigned To</th>
                                                    <th>Customer voice & Remarks</th>
                                                    <th>Lat/Long</th>
                                                    <th>Closure Date</th>
                                                    <th>Updated By</th>
                                                    <th>Creation Source</th>
                                                </tr>
                                            </thead>
                                            <tbody id="orderDataDiv">


                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane " id="tab7">
                                <div class="modal-body table-responsive b_tbl_responsive">
                                    <table class="table table-bordered text-nowrap table-striped border-bottom">
                                        <tbody>
                                            <tr>
                                                <th colspan="3">Personal Details</th>
                                                <th colspan="1">
                                                    <input type="hidden" id= "refreshuid" value="">
                                                    <button type="button" id="RefreshRecharge"
                                                        class="btn btn-success">Refresh Recharge</button>
                                                </th>

                                            </tr>
                                            <tr>
                                                <td>Mobile Number:</i></td>
                                                <td id="rhMobileNo"></td>
                                                <td>Alternate Number:</td>
                                                <td id="rhAlternateNo"></td>
                                            </tr>
                                            <tr>
                                                <td>Name: </td>
                                                <td id="rhCustomerName"></td>
                                                <td>Email: </td>
                                                <td id="rhEmailId"></td>
                                            </tr>
                                            <tr>
                                                <td>Registration Amount:</i></td>
                                                <td id="rhRegistrationAmount"></td>
                                                <td>Security Amount:</td>
                                                <td id="rhSecurityAmount"></td>
                                            </tr>
                                            <tr>
                                                <td>First Payment Date:</i></td>
                                                <td id="rhFirstPaymentDate"></td>
                                                <td>Payment Mode:</td>
                                                <td id="rhPaymentMode"></td>
                                            </tr>
                                            <tr>
                                                <td>Asset Datesss:</i></td>
                                                <td id="rhAssetDate"></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <div class="table-responsive">
                                        <table class="table border text-nowrap text-md-nowrap mb-0">
                                            <thead class="table-primary">
                                                <tr>
                                                    <th>Mobile Number</th>
                                                    <th>Amount</th>
                                                    <th>Recharge Type</th>
                                                    <th>Date</th>
                                                    <th>Valid From</th>
                                                    <th>Valid To</th>
                                                    <th>Transaction No</th>
                                                </tr>
                                            </thead>
                                            <tbody id="rechargeDataDiv">

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary br-7" data-bs-dismiss="modal">Close</button>
                {{--   <button type="button" class="btn btn-primary br-7">Send message</button> --}}
            </div>
        </div>
    </div>
</div>
