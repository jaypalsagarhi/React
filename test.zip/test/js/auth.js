Vue.component("registration", {
	template: `
	 <v-form ref="registration" :key="refreshCounter" id="registrationForm" method="POST" :action="action" @submit.prevent="register" novalidate lazy>
		<v-row>
		  <v-col cols="12">
		  	<input 
		  		type="hidden" 
		  		name="pageName" 
		  		:value="pagename"
		  	>
			<v-text-field 
				ref="name" 
				label="Your name *" 
				name="name" 
				type="text" 
				maxlength="201" 
				v-model="name" 
				:error-messages="nameError" 
				@focus="resetValidation"
			/>
			<v-text-field 
				label="Email *" 
				name="email" 
				type="email"
				id="email" 
				v-model="email" 
				maxlength="201" 
				:error-messages="emailError" 
				@keydown.space.prevent 
				@focus="resetValidation"
			/>
			<v-text-field 
				label="Mobile *" 
				name="phone" 
				type="tel" 
				maxlength="10" 
				v-model="mobile" 
				:error-messages="mobileError" 
				@keydown.space.prevent  
				@focus="resetValidation" 
				@keypress="isNumber($event)"
			
			/>
			<div v-if="cityreadonly == 'true' ">
				<v-text-field 
					name="cityName" 
					:value="saved_city" 
					label="Select City" 
					item-text="cityName" 
					item-value="_id" 
					:error-messages="cityError" 
					@focus="resetValidation"  
					v-model="vSelectedCity"
					readonly
				/>
			</div>
			<div v-else>
				<v-select 
					v-if="cities.length>0" 
					ref="select" 
					:items="cities" 
					:value="saved_city" 
					:error-messages="cityError" 
					item-text="cityName" 
					name="cityName" 
					v-model="vSelectedCity" 
					label="Select city *" 
					@change="citySelected" 
					cache-items 
					@focus="resetValidation"
				/>
			</div>
			<v-text-field 
				name="city" 
				type="text" 
				v-model="selectedCity" 
				readonly 
				v-show="false"
			/>
			<v-select 
			v-if="watersource.length>0" 
			ref="select" 
			:items="watersource" 
			:value="saved_source" 
							
			:error-messages="sourceError" 
			item-text="sourceName" 
			name="sourceName" 
			v-model="vSelectedSource" 
			label="Current Drinking Water Source *" 
			@change="sourceSelected" 
			cache-items 
			@focus="resetValidation"
		/>
		<v-text-field 
			name="source" 
			type="text" 
			v-model="selectedSource" 
			readonly 
			v-show="false"
		/>

		<input 
		ref="source" 
		class="datasource"
		name="datasource" 
		type="text" 
		id="source"
		maxlength="201" 
		v-model="datasource" 
		:error-messages="sourcedataError" 
		@focus="resetValidation"
		style="display:none;"/>
	
			<v-text-field 
				label="Create password *" 
				name="password" 
				autocomplete="new-password" 
				:append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
				:type="showPassword ? 'text' : 'password'" 
				v-model="password"
				minlength="8"
				maxlength="30"  
				:error-messages="passwordError" 
				@click:append="showPassword = !showPassword"
				hint="Password must contain a capital letter, a small letter, a number, a special character and at least 8 characters"  
				@focus="resetValidation" 
				@keydown.space.prevent/>
				<v-text-field 
					label="Referral Code (if any)" 
					ref="referralCode" 
					name="referralCode" 
					type="text" 
					minlength="6"
					maxlength="8" 
					class="upper-case-input" 
					v-model="validateCode" 
					:error-messages="referralError"
					@keydown.space.prevent/>
				<v-card-text 
					v-if="isCodeValid" 
					class="px-0 py-0 my-0 success--text referral-code-success">{{successMessage}}
				</v-card-text>
				<div>
					<label>
						<input type="checkbox" v-model="isChecked" id="completeCheck" > 
							<span class="px-2">
								I hereby confirm to be contacted by Livpure Smart Homes Private Limited using SMS, Phone, Email & Whatsapp for communication.
							</span>
					</label>
					<v-card-text v-if="isCheckedError != ''" class="px-0 py-0 my-0 error--text referral-code-error">{{isCheckedError}}
					</v-card-text>
				</div>
			<v-card-actions 
				class="mt-4 flex-column">
				<v-btn 
					type="submit" 
					class="primary action-btn" id="submit_button">Sign Up & Get 7 Days Free Trial
				</v-btn>
				<div 
					class="terms-use"> By creating an account on LivpureSmart, you agree to our
     			<span>
					<a 
						:href="termsURL" 
						target="_blank" 
						class="term-link hand-cursor">
				 <strong>Terms of Use</strong>
</a>
		<strong>&</strong>		
					<a 
						:href="termsofconditonURL" 
						target="_blank" 
						class="term-link hand-cursor">
			<strong> Terms and Conditions.</strong>&nbsp;
					</a>
</span>
					Receive notification from WhatsApp.
				</div>
			</v-card-actions>
		  </v-col>
		</v-row>
	</v-form>`,
		props: ['user_name', 'email_address', 'phone_number', 'saved_city', 'saved_source','data_source','referral_code', 'cities', 'pagename',"watersource","cityreadonly"],
	data() {
		return {
			action:`${window.baseUrl}auth/register`,
			termsURL: `${window.baseUrl}terms_of_use`,
			termsofconditonURL: `${window.baseUrl}terms_and_conditions`,
			refreshCounter: 0,
			showPassword: false,
			validateCode: '',
			successMessage: '',
			isCodeValid: false,
			vSelectedCity: '',
			selectedCity: '',
			vSelectedSource: '',
			selectedSource: '',
			isChecked: true,
			//
			name: this.user_name,
			email: this.email_address,
			mobile: this.phone_number,
			password: '',
			referralCode: this.referral_code,
			datasource:this.data_source,
			//
			referralError: [],
			nameError: [],
			emailError: [],
			mobileError: [],
			passwordError: [],
			cityError: [],
			isCheckedError: false,
			sourceError:[],
			sourcedataError:[],
      	}
	},
	methods: {
		isNumber(evt) {
			evt = (evt) ? evt : window.event;
			const charCode = (evt.which) ? evt.which : evt.keyCode;
			if ((charCode > 31 && (charCode < 48 || charCode > 57))) {
				evt.preventDefault();
			} else {
				return true;
			}
		},
		citySelected() {
			this.selectedCity = arguments[0];
		},
	sourceSelected() {
			this.selectedSource = arguments[0];
			$(".datasource").hide(); 
			if(this.selectedSource == 'Other'){
				$(".datasource").show();
			}
		},
		resetValidation() {
			arguments[0].currentTarget.name === 'sourceName' && (this.sourceError = []);
			arguments[0].currentTarget.name === 'datasource' && (this.sourcedataError = []);
			arguments[0].currentTarget.name === 'cityName' && (this.cityError = []);
			arguments[0].currentTarget.name === 'name' && (this.nameError = []);
			arguments[0].currentTarget.name === 'email' && (this.emailError = []);
			arguments[0].currentTarget.name === 'phone' && (this.mobileError = []);
			arguments[0].currentTarget.name === 'password' && (this.passwordError = []);
			arguments[0].currentTarget.name === 'referralCode' && (this.referralError = []);
			arguments[0].currentTarget.isChecked === 'isChecked' && (this.isCheckedError = '');
		},
		register() {
			this.name = this.name.trim().length === 0 ? '' : this.name.trim();
			console.log("this.isChecked",this.isChecked);
			this.isCheckedError = this.isChecked === true ? '' : "This information is required.";
			this.nameError = this.name.length === 0 ? ['This information is required.']
				: !/^[a-zA-Z ]*$/.test(this.name) ? ['Special characters are not allowed'] : []; // verify name
			this.emailError = this.email.trim().length === 0 ? ['This information is required.']
				: !(emailRegEx.test(this.email)) ? ['Enter a valid email address.'] : [];  // verify email

			// verify mobile number started with 5 only on prod
			this.mobileError = this.mobile.trim().length === 0 ? ['This information is required.']
				: this.mobile.length < 10 ? ['Enter a valid mobile number.']
				: (enviroment === 'PROD' && !mobileRegex.test(this.mobile)) ? ['Enter a valid mobile number.'] : [];

			this.passwordError = this.password.trim().length === 0 ? ['This information is required.']
				: this.password.length < 5 ? ['At least 5 characters required.'] : [];  // verify password

			this.cityError = this.selectedCity.trim().length === 0 ? ['This information is required.'] : [];
	this.sourceError = this.selectedSource.trim().length === 0 ? ['This information is required.'] : [];

if(this.selectedSource == 'Other'){
			this.sourcedataError = this.datasource.trim().length === 0 ? ['This information is required.'] : [];
			}
			// no error in the form
			if (this.nameError.length === 0 && this.emailError.length === 0 && this.cityError.length === 0 && this.sourceError.length === 0 && this.sourcedataError.length === 0
				&& this.mobileError.length === 0 && this.passwordError.length === 0 && this.referralError.length === 0 && this.isCheckedError.length === 0) {
				this.$refs['registration'].$el.submit();
			}
		},
		resetFormData() {
			this.name = this.email = this.password = this.mobile = this.referralCode = this.datasource = this.selectedCity = this.vSelectedCity = this.selectedSource= this.vselectedSource='';
			this.referralError = this.nameError = this.emailError = this.mobileError = this.passwordError = this.cityError = this.sourceError = this.sourcedataError=[];
		},
		refreshComponent() {
			this.refreshCounter++;
		}
	},
	watch: {
		async validateCode(value) { // validate referral input
			if (value.trim().length === 0) {
				this.referralError = [];
			} else if (value.length >= 6 && value.length <= 8 ) {
				try {
					const data = await getData(`${window.baseUrl}Auth/validateReferralCode`, 'post', {'referralCode': value.toUpperCase()});

					const response = JSON.parse(data);

					this.isCodeValid = response.success;
					this.successMessage = response.success ? response.message : '';
					this.referralError = [];
					if (!response.success) {
						this.referralError = [response.message];
					}
				} catch (err) {
					console.log(err);
				}
			} else {
				this.referralError = ['Please enter the valid referral code'];
			}
		}
	},
	mounted() {
		//console.log('mounted')
		this.vSelectedCity = this.selectedCity = this.saved_city;
		this.vSelectedSource = this.selectedSource = this.saved_source;
	},
	deactivated() {
		//console.log('deactivated')
	}
});

Vue.component("login", {
	template: `
	 <v-form ref="login" id="loginForm" method="POST" :action="action" @submit.prevent="login" lazy novalidate>
		<v-row>
		  <v-col cols="12">
			<v-text-field ref="username" label="Email Id / Mobile Number" name="username" :error-messages="userNameError"
			v-model="username" maxlength="201" @keydown.space.prevent/>
			
			<v-text-field label="Password" name="password" v-model="password"  :error-messages="passwordError" 
				:append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'" maxlength="30" 
				:type="showPassword ? 'text' : 'password'"
				@click:append="showPassword = !showPassword" autocomplete="new-password">
			</v-text-field>
			<v-card-actions class="mt-0 flex-column" >
				<a href="forgot" class="forget-password align-self-end">Forgot password?</a>
				<v-btn type="submit" class="primary action-btn mt-6">Log in</v-btn>
			</v-card-actions>
		  </v-col>
		</v-row>
	</v-form>`,
	data() {
		return {
			action:`${window.baseUrl}auth/login`,
			showPassword: false,
			username: '',
			userNameError: '',
			password: '',
			passwordError: ''
		}
	},
	methods: {
		login() {
			this.userNameError = '';
			if (this.username.trim() === '') {
				this.userNameError = 'Email/Mobile is required.';
			} else {
				if (this.username.includes('@')) {
					this.userNameError = !emailRegEx.test(this.username) ? 'Enter a valid email address.' : '';
				} else {
					this.userNameError = (enviroment === 'PROD' && !mobileRegex.test(this.username)) ? 'Enter a valid mobile number.' : '';
				}
			}

			this.passwordError = this.password.trim() === '' ? 'This information is required.' : '';


			if (this.userNameError.trim().length === 0 && this.passwordError.trim().length === 0) {
				this.$refs['login'].$el.submit();
			}
		},
		resetFormData() {
			this.passwordError = this.userNameError = '';
			this.$refs['login'].$el.reset();
			this.$refs['login'].resetValidation();
			//this.$refs.username.focus();
		}
	},
	mounted() {
		//console.log(this.$refs.username.$el);
		this.$refs.username.$el.focus();
		//this.$nextTick(() => this.$refs['username'].$el.focus());
	}
});
