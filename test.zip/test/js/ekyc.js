Vue.component("upload-aadhar", {
	template: `
	<v-card flat class="align-me-center flex-column transparent-background">
		<v-card flat class="aadhar-thanks-block-wrapper">
			<span class="thank-you-text">Thank You for Choosing Livpure Smart</span>
			<span class="payment-id-text" v-if="paymentid != ''">Payment ID: {{paymentid}}</span>
			<span class="livpure-product-text"> 
				Please complete the final step by uploading correct KYC documents for establishing identity and address so that we go ahead with the installation on priority at the address provided by you.
			</span>
		</v-card>
		<div class="align-me-center" :class="{'pt-3' : !$vuetify.breakpoint.xs}">
			<span class="desk-module-title final-step" :class="{'final-step-title' : $vuetify.breakpoint.xs}" >Final Step : Upload KYC Documents</span>
		</div>
		
		<form 
			ref="uploadAadhar" 
			id="uploadAadhar" 
			method="POST" 
			:action="action" 
			enctype="multipart/form-data" 
			@submit.prevent="uploadDocuments"
			class="form-module aadhar-form-wrapper px-4 pt-0 desk-form-wrapper" 
			:class="{'px-6' : !$vuetify.breakpoint.xs}"
			novalidate 
			lazy>
			<v-row>
				<v-col cols="12">
					<div class="flex">
						<div class="salutation-wrapper-select">
							<v-select 
								:items="salutationFields" 
								name="salutationCode" 
								item-text="value" 
								item-value="id" 
								class="primary--text" 
								v-model="prefix" 
								@change="prefixSelected"/>
							<v-text-field 
								name="salutationCode" 
								type="text" 
								v-model="salCode" 
								readonly 
								v-show="false"/>
						</div>
						<v-text-field 
							class="user-full-name" 
							name="name" 
							maxlength="201"
							type="text" 
							v-model="name" 
							hint="Enter name as it appears in KYC documents."
							:error-messages="nameError"
							persistent-hint/>
					</div>
		
					<div class="upload-proof">
						<div ref="idProofUpload" class="id-proof">
							<div class="id-proof-select mr-3">
								<v-select 
									:items="idprooflist" 
									label="Select proof of identity" 
									class="primary--text" 
									name="selectIdProof" 
									v-model="idProofType" 
									:error-messages="idProofError" 
									:hint="idProofHint"
									@change="idProofSelected"
									@focus="resetValidation"
									persistent-hint flat single-line>
								</v-select>
								<v-text-field 
									name="idProofType" 
									type="text" 
									v-model="idProofType" 
									v-show="false" 
									readonly>	
								</v-text-field>
							</div>
							<div class="address-proof-input">
								<div class="proof-upload-container">
									<v-card  class="flex flex-column align-half">
										<v-file-input
											id="idProofFile1"
											v-model="idProofFile1" 
											class="v-file-in" 
											name="idProof[]"
											placeholder="Front"
											color="primary" 
											:rules="rules" 
											:error-messages="idProofErrorFile1" 
											accept="image/jpeg, image/png, image/jpg, application/pdf" 
											prepend-icon="" prepend-inner-icon="mdi-upload" 
											:disabled="!isIdNameSelected" 
											:truncate-length="$vuetify.breakpoint.xs ? 7 : 15" 
											@change="previewImage('i1')">
										</v-file-input>
										<div class="image-preview" v-show="isIdNameSelected">
											<img 
												class="preview" 
												:src="idProofPreview1" 
												@click="invokeFileInput('idProofFile1')">
											<div class="subheading preview-file-name">
												{{idProofFile1 && idProofFile1.size <= 26214400 ? idProofFile1.name : ""}}
											</div>
										</div>
									</v-card>
									<v-card class="flex flex-column align-half">
										<v-file-input 
											id="idProofFile2"
											v-model="idProofFile2" 
											class="v-file-in" 
											name="idProof[]"
											placeholder="Back (optional)"
											color="primary" 
											:rules="rules" 
											:error-messages="idProofErrorFile2" 
											accept="image/jpeg, image/png, image/jpg, application/pdf" 
											prepend-icon="" prepend-inner-icon="mdi-upload" 
											:disabled="!isIdNameSelected" 
											:truncate-length="$vuetify.breakpoint.xs ? 7 : 15" 
											@change="previewImage('i2')">
										</v-file-input>
										<div class="image-preview" v-show="isIdNameSelected">
											<img 
												class="preview" 
												:src="idProofPreview2" 
												@click="invokeFileInput('idProofFile2')">
											<div class="subheading preview-file-name">
												{{idProofFile2 && idProofFile2.size <= 26214400 ? idProofFile2.name : ""}}
											</div>
										</div>
									</v-card>
								</div>
							</div>
						</div>
						<div ref="addressProofUpload" class="address-proof">
							<div class="address-proof-select">
								<v-select 
									:items="addressprofflist" 
									label="Select proof of address" 
									class="primary--text" 
									name="selectAddressProof" 
									v-model="addressProofType" 
									:error-messages="addressProofError"  
									:hint="addressProofHint"
									@change="addressProofSelected"  
									@focus="resetValidation"
									persistent-hint flat single-line />
								<v-text-field 
									name="addressProofType" 
									type="text" 
									v-model="addressProofType" 
									readonly 
									v-show="false"/>
							</div>
							<div class="address-proof-input">
								<div class="proof-upload-container">
									<div class="flex flex-column align-half">
										<v-file-input 
												id="addressProofFile1"
												v-model="addressProofFile1" 
												class="v-file-in" 
												name="addressProof[]"
												placeholder="Front"
												color="primary" 
												:rules="rules" 
												:error-messages="addressProofErrorFile1" 
												accept="image/jpeg, image/png, image/jpg, application/pdf" 
												prepend-icon="" prepend-inner-icon="mdi-upload" 
												:disabled="!isAddressNameSelected" 
												:truncate-length="$vuetify.breakpoint.xs ? 7 : 15" 
												@change="previewImage('a1')">
										</v-file-input>
										<div class="image-preview" v-show="isAddressNameSelected">
											<img 
												class="preview" 
												:src="addressProofPreview1" 
												@click="invokeFileInput('addressProofFile1')">
											<div class="subheading preview-file-name">
												{{addressProofFile1 && addressProofFile1.size <= 26214400 ? addressProofFile1.name : ""}}
											</div>
										</div>
									</div>
									<div class="flex flex-column align-half">
										<v-file-input 
												id="addressProofFile2"
												v-model="addressProofFile2" 
												class="v-file-in" 
												name="addressProof[]"
												placeholder="Back (optional)"
												color="primary" 
												:rules="rules" 
												:error-messages="addressProofErrorFile2" 
												accept="image/jpeg, image/png, image/jpg, application/pdf" 
												prepend-icon="" prepend-inner-icon="mdi-upload" 
												:disabled="!isAddressNameSelected" 
												:truncate-length="$vuetify.breakpoint.xs ? 7 : 15" 
												@change="previewImage('a2')">
										</v-file-input>
										<div class="image-preview" v-show="isAddressNameSelected">
											<img 
												class="preview" 
												:src="addressProofPreview2" 
												@click="invokeFileInput('addressProofFile2')">
											<div class="subheading preview-file-name">
												{{addressProofFile2 && addressProofFile2.size <= 26214400 ? addressProofFile2.name : ""}}
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<p class="upload-proof-text">Please upload files in these formats only jpeg, png, jpg and pdf. (files should not be password protected)</p>
						<v-card-actions class="mt-6 flex-column">
							<v-btn ref="uploadKYCProofs" type="submit" class="primary action-btn mt-6" :loading="isLoading">Submit</v-btn>
						</v-card-actions>
						
					</div>
				</v-col>
			</v-row>
		</form>
	</v-card>
	`,
	props: ['idprooflist', 'addressprofflist', 'fullname', 'paymentid'],
	data() {
		return {
			action:`${window.baseUrl}ekyc/process`,
			isLoading: false,
			isValidAddressFileSize: false,
			isValidIdFileSize: false,
			name: "",
			gap: 0,
			aadhar: false,
			addressProofType: '',
			idProofType: '',

			addressProofFile1: null,
			addressProofFile2: null,
			idProofFile1: null,
			idProofFile2: null,

			prefix: {id: '0002'},
			salCode: '0002',
			salutationFields: [{id: '0002', value: 'Mr.'}, {id: '0001', value: 'Ms.'}],
			isIdNameSelected: false,
			isAddressNameSelected: false,

			addressProofError: [],
			idProofError: [],
			nameError: [],

			idProofErrorFile1: [],
			idProofErrorFile2: [],
			addressProofErrorFile1: [],
			addressProofErrorFile2: [],

			defaultImage: "/assets/images/noimage.jpg",
			defaultPdfImage: "/assets/images/pdficon.svg",
			idProofPreview1: "",  // we will store base64 format of image in this string
			idProofPreview2: "",  // we will store base64 format of image in this string

			addressProofPreview1: "",  // we will store base64 format of image in this string
			addressProofPreview2: "",  // we will store base64 format of image in this string

			showIdProofInput2: false,
			showIdProofInput3: false,
			showAddressProofInput2: false,
			showAddressProofInput3: false,

			idProofHint: "",
			addressProofHint: "",

			rules: [
				value => !value || value.size < 26214400 || 'file size should be less than 25 MB!',
			]
		}
	},
	methods: {
		prefixSelected() {
			this.salCode = arguments[0];
		},
		resetValidation() {
			arguments[0].currentTarget.name === 'selectAddressProof' && (this.addressProofError = []);
			arguments[0].currentTarget.name === 'selectIdProof' && (this.idProofError = []);
		},
		invokeFileInput(elementId) {
			document.getElementById(elementId).click();
		},
		previewImage(type) {

			let previewDataKey = "", uploadedFile = null;

			if (type === "i1") {
				previewDataKey = "idProofPreview1";
				uploadedFile = this.idProofFile1;
			} else if (type === "i2") {
				previewDataKey = "idProofPreview2";
				uploadedFile = this.idProofFile2;
			} else if (type === "a1") {
				previewDataKey = "addressProofPreview1";
				uploadedFile = this.addressProofFile1;
			} else {
				previewDataKey = "addressProofPreview2";
				uploadedFile = this.addressProofFile2;
			}

			//25 MB => 26,214,400 Bytes (Binary)
			if(uploadedFile && uploadedFile.size <= 26214400) {
				this[previewDataKey] = uploadedFile.type !== 'application/pdf' ? URL.createObjectURL(uploadedFile) : this.defaultPdfImage;
			} else {
				this[previewDataKey] = this.defaultImage;
			}

			// destroy previous object url
			URL.revokeObjectURL(uploadedFile);
		},
		idProofSelected() {
			this.isIdNameSelected = true;
			this.$refs['idProofUpload'].classList.add('type-selected');

			this.idProofHint = this.getInputHint(this.idProofType);

		},
		addressProofSelected() {
			this.isAddressNameSelected = true;
			this.$refs['addressProofUpload'].classList.add('type-selected');

			this.addressProofHint = this.getInputHint(this.addressProofType);
		},
		getInputHint(type) {
			const selectedType = type.toLowerCase();
			let message = "";
			if(selectedType.indexOf('aadhaar') !== -1 || selectedType.indexOf('voter') !== -1) {
				message = `Please upload image of both front and back of your ${type}.`;
			} else if(selectedType.indexOf('rent') !== -1 ){
				message = "Please upload image of First page and Address page of your Rent Agreement.";
			}  else if(selectedType.indexOf('passport') !== -1 ){
				message = "Please upload image of First and Last page of your Passport.";
			}

			return message;
		},
		uploadDocuments() {

			this.nameError = this.name.trim() === '' ? ['This information is required.'] : '';

			this.idProofError = this.idProofType === '' ? ['This information is required.'] : [];
			this.addressProofError = this.addressProofType === '' ? ['This information is required.'] : [];

			if (this.idProofError.length === 0) {
				if (!this.idProofFile1) {
					this.idProofErrorFile1 = ['Please upload a valid ID proof.'];
				} else if (!allowedFileTypes.includes(this.idProofFile1.type)) {
					this.idProofErrorFile1 = ['file format not supported.'];
				} else {
					this.idProofErrorFile1 = !(this.idProofFile1.size <= 26214400) ? [`file size should be less than ${maxAllowedFileSize} MB!.`] : [];
				}

				if (this.idProofFile2) {
					if (!allowedFileTypes.includes(this.idProofFile2.type)) {
						this.idProofErrorFile2 = ['file format not supported.'];
					} else {
						this.idProofErrorFile2 = !(this.idProofFile2.size <= 26214400) ? [`file size should be less than ${maxAllowedFileSize} MB!.`] : [];
					}
				}
			}

			if (this.addressProofError.length === 0) {
				if (!this.addressProofFile1) {
					this.addressProofErrorFile1 = ['Please upload a valid address proof.'];
				} else if (!allowedFileTypes.includes(this.addressProofFile1.type)) {
					this.addressProofErrorFile1 = ['file format not supported.'];
				} else {
					this.addressProofErrorFile1 = !(this.addressProofFile1.size <= 26214400) ? [`file size should be less than ${maxAllowedFileSize} MB!.`] : [];
				}


				if (this.addressProofFile2) {
					if (!allowedFileTypes.includes(this.addressProofFile2.type)) {
						this.addressProofErrorFile2 = ['file format not supported.'];
					} else {
						this.addressProofErrorFile2 = !(this.addressProofFile2.size <= 26214400) ? [`file size should be less than ${maxAllowedFileSize} MB!.`] : [];
					}
				}
			}


			if (this.addressProofError.length === 0 && this.idProofError.length === 0
				&& this.idProofErrorFile1.length === 0 && this.addressProofErrorFile1.length === 0
				&& this.idProofErrorFile2.length === 0 && this.addressProofErrorFile2.length === 0
				&& this.nameError.length === 0) {
				this.isLoading = true;
				this.$refs['uploadAadhar'].submit();
			}

		}
	},
	mounted() {
		this.name = this.fullname;
		this.idProofPreview1 = this.defaultImage;
		this.idProofPreview2 = this.defaultImage;
		this.addressProofPreview1 = this.defaultImage;
		this.addressProofPreview2 = this.defaultImage;
	}
});
