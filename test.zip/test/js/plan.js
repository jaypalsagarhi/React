var plantemplate=`<section class="plan-section  plan-desk planV1">
		<div class = "plan_webView">
			<div class="container b_newPlan">
				<div class="plan_product prod_card" v-bind:class="{ 'active': i === activeIndex }"   v-for="(plan, i) in plans" @click="planSelected" :data-tier="plan.planName.toLowerCase()" :data-websiteTitle="plan.websiteTitle" :data-pricePerMonth="plan.pricePerMonth" v-if="plan.show != 'N'"  :key="i" :id="generateId(plan.planName , plan.planId)">
					<div class="b_card bolt_card">
						<p><span class="plan_title">{{ plan.websiteTitle }}</span> </p>
						<p v-if="plan.planName == 'Zinger-Unlimited' || plan.planName == 'Stealth-Unlimited' || plan.planName == 'HydroBoost-Unlimited'">Universal Water Plan</p>
						<p v-if="plan.planName == 'Silver'">Multiple Water Plans</p>
						<p v-if="plan.planName == 'Bolt-Cu-Unlimited'">Multiple Water Plans</p>
						<hr>
						<p><span>&#x20b9; {{ plan.pricePerMonth }}</span>/mo</p>
						<button class="b-btn_primary" data-toggle="modal" data-target="#basicModal" @click="sendInfo({item_name:replaceSpaces(plan.websiteTitle)})" >Select Duration</button>
						
						<img :src="cdn + plan.planType" alt="ROimage" style="width: 99px; height: 99px; margin-top: 10px;">
						<div class="b_container container">
							<ul>
								<li v-for="(contentValue, i) in plan.content[0]" :key="i"> <img :src="cdn + 'assets/images/correct-plan.png'" alt="check"> {{ contentValue }}</li>							
							</ul> 
							<hr>
							<ul class="b_freeTrial">
								<li>7 Days Free Trial</li>  
								<li>Free Installation</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	
	<!-- Mobile Section data Start -->
	<section class="plan-section plan-desk planV1 plan_mob_view">
	
		<div v-for="(plan, i) in plans" v-if="plan.show != 'N'" :key="i" >
				<div class="b_newFlex-mob" :class="generateMobClassID(plan.planName)" @click="planSelected" :data-tier="plan.planName.toLowerCase()" :data-websiteTitle="plan.websiteTitle" :data-pricePerMonth="plan.pricePerMonth" :id="generateIdMob(plan.planName, plan.planId)">
                    <div style="width: 65px;height: 55px;background: #ebf2fa;text-align: center;border-radius: 50%;">
                    <img :src="plan.planType" alt="img" style="width: 35px;margin-top: 9px;"></div>
                    <div class="p_name">
                        <p class="product_Name-mob">{{ plan.websiteTitle }}	</p>
                        <p style="font-size: 12px;color: #8592a6;" v-if="plan.planName == 'Silver'">Multiple Water Plans</p>
						<p style="font-size: 12px;color: #8592a6;" v-if="plan.planName == 'Bolt-Cu-Unlimited'">Multiple Water Plans</p>
						<p style="font-size: 12px;color: #8592a6;" v-if="plan.planName == 'Zinger-Unlimited' || plan.planName == 'Stealth-Unlimited' || plan.planName == 'HydroBoost-Unlimited'">Universal Water Plan</p>


                    </div>
                    <div class="b_productPlan-mob">
                        <p class="b_mobPrice"><span>&#x20b9; {{ plan.pricePerMonth }}</span>/mo</p>
                        <a href="javascript:void(0)" :id="generateMobClassID(plan.planName)" >Know More <img :src="cdn + 'assets/images/more_know.png'" alt="img"></a>
                    </div>
                </div>

                <!-- Bolt description -->
                <div class="plan_product active" :class="generateProductClassId(plan.planName)+'_Product'" :id="generateProductClassId(plan.planName)+'_planProduct' " style="width: 40%;">
                    <div class="b_card" :class="generateProductClassId(plan.planName)+'_card'">
                        <div class="b_mviewFlex">
                            <div style="text-align: start;">
                                <p><span>{{ plan.websiteTitle }}</span> </p>
								<p v-if="plan.planName == 'Zinger-Unlimited' || plan.planName == 'Stealth-Unlimited' || plan.planName == 'HydroBoost-Unlimited'">Universal Water Plan</p>
						<p v-if="plan.planName == 'Silver'">Multiple Water Plans</p>
                              

								
                            </div>
                            <div><p><span>&#x20b9; {{ plan.pricePerMonth }}</span>/mo</p></div>
                        </div>
                        <hr>
                        <div class="b_container container">
                            <div class="b_mviewFlex">
                                <div>
                                    <ul>
                                        <li v-for="(contentValue, i) in plan.content[0]" :key="i"> <img :src="cdn + 'assets/images/circle.png'" alt="img"> {{ contentValue }}</li>
                                        
                                    </ul> 
                                    <button class=" b-btn_primary" data-toggle="modal" data-target="#basicModal" @click="sendInfo({item_name:replaceSpaces(plan.websiteTitle)})">Select Duration</button>
                                </div>
                                <div>
								
                                <img :src="cdn + plan.planType" alt="ROimage11" style="   width: 78px;
                                    height: 118px;">
                                </div>
                            </div>
                            <hr>
                            <ul class="b_freeTrial">
                                <li>7 Days Free Trial</li>
                                <li>Free Installation</li>
                            </ul>
                        </div>
                    </div>
                </div>
				</div>

		
		
	</section>
	<!-- Mobile Section data End -->

	<!-- select plan modal -->
    <div class="modal fade" id="basicModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true" ref="myModal">
        <div class="modal-dialog" style="width: 40%;">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <ul class="nav nav-tabs b_nav_tabs" id="tabContent">				
                    <li class="b_tab"    v-for="(tabs, i) in passedData" :key="i"  :value="'tab'+tabs.planName.toLowerCase()" :data-planname="tabs.planName.toLowerCase()" :class="{ 'active': i === 0 }">
					<a class="b_tabList arrow-bottom b-plan" :href=generateHref(tabs.planName,tabs.planId) data-toggle="tab"> {{ tabs.planName === 'Bolt-Unlimited' || tabs.planName === 'Zinger-Unlimited' || tabs.planName === 'HydroBoost-Unlimited' || tabs.planName === 'Stealth-Unlimited' || tabs.planName === 'Bolt-Cu-Unlimited' ? 'Family Plan' : tabs.planName + ' Plan' }}
					</a>
					</li>                    
                </ul>
				<div class="tab-content b_plans">
				<div class="tab-pane"  v-for="(plan, j) in passedData" :key="j" :id="generateTabId(plan.planName,plan.planId)" :class="{ 'active': j === 0 }">
					<p class="ul_water"><span style="font-family: 'Source Sans Pro'; font-weight: bold;font-size: 18px;">{{plan.liters}} Liters</span> <span style="font-family: 'Source Sans Pro';font-size: 14px;">every month</span> 
					</p>

						<div class="row b_Plan1 b_selectButton" v-for="(ptype, k) in plan.price" :key="ptype.duration" :class="{ 'active b_bestSeller': k === 0 }"    @click="setButtonData(ptype.duration,ptype.price,ptype.pricePerMonth,ptype.epd,plan.planName)">
							<div class="col-md-1 col-sm-1 b_selectRadio" style="padding: 0;">
								<input type="radio" name="radiobutton1" id="" checked>
							</div>
							<div class="col-md-11 col-sm-11" style="padding: 0;">
								<div>				
							
							<p class="b_planP b_border" style="border-bottom: 1px solid #193357;font-size: 16px;" > 
									<span class="b_planP" style="font-size: 16px;
									font-weight: bold;">₹{{ ptype.pricePerMonth }}</span>  
									<span class="b_planSpan" style=" font-size: 12px;" v-if="ptype.duration !== '1'" >/month</span>
									<span class="b_planSpan" style=" font-size: 12px;" v-if="ptype.duration === '1'" > / 28 Days</span>
							</p>

								<div class="row b_selctPop" v-if="ptype.duration  !== '1'">
									<div class="col-md-5 b_border" style="border-right: 1px solid #193357;padding-bottom:0;align-self: center;">
										<span class="b_planSpan">Validity</span>
										<p class="b_planP" style="font-weight: bold;">{{ptype.duration}} MONTHS</p>
									</div>
									<div class="col-md-7" style="padding-bottom:0;align-self: center;">
										<p class="b_planSpan" style="font-size: 13px;">Total Plan Amount</p>
										<p class="b_planP" style="font-size: 15px;
											font-weight: 600;">₹ {{ptype.price}} <span style="font-size: 10px"><strike>{{plan.amount*ptype.duration}}</strike></span> 
											<span style="background: #48a513;font-size: 9px;color: white;padding: 2px;">{{ptype.saveMessage}}</span></p>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<p id="depositAmountShow" :data-depositAmount="plan.depositAmount" style="text-align: center;margin-top: 12px;    font-weight: bold;
					">+ 100% Refundable Deposit: ₹{{plan.depositAmount}}*</p>
					<v-btn  class="b_btn_pay subscribe-action-button" :id="plan.planName.toLowerCase()" :data-plan-tier="plan.planName"  
					:data-plan-id="plan.planId":data-rplan-id="plan.rPlanId" :data-plan-dpAmount="plan.dpAmount" :data-plan-status="plan.status" :data-plan-productType="plan.productType"  :data-duration="buttonDurationValue" :data-id="buttonEncryptPriceValue" :data-price="buttonPriceValue" :data-pricePerMonth="buttonPricePMValue" @click.native.stop="subscribeNow"
>{{alreadySubscribed == 1 && currentPlanId == plan.planId ? 'Recharge' : alreadySubscribed == 1 ? 'Change Plan' : 'Subscribe'}}
</v-btn>
<span v-if="plan.planId == '61'"><p style="text-align: center;margin-top: 12px;" v-if ="plan.rateperliter">Add more water @ ₹{{Math.round(plan.rateperliter)}}/litre*</p></span>
<span v-else><p style="text-align: center;margin-top: 12px;" v-if ="plan.rateperliter">Add more water @ ₹{{plan.rateperliter}}/litre*</p></span>
				</div> 
				
				<!-- tab pane end -->				

			</div>
            </div>
        </div>
    </div>`;

Vue.component('plans', {
	template: plantemplate,
	props: ['kycdone', 'producttype', 'pageurl', 'currentplan', 'premiumplan', 'currentplanname', 'fromropremium', 'userplanid', 'userplanmodel', 'forceshow', 'logindata', 'deposit', 'dynamicdepositamt', 'premiumstatus', 'premiumamount', 'premiumdepositamount', 'premiumplanduration', 'premiumplanname', 'premiumplanid', 'envyboltplan', 'userid'],

	data() {
		return {
			plans: app.plans,
			cdn:app.cdn,
			boltMinilizer:app.boltMinilizer,
			unlimitedPlans:app.zingerplanResult,
			stealthPlans:app.stealthPlans,
			alkalinePlans:app.alkalinePlans,
			boltCopperPlan:app.boltCopperPlan,			
			isMobile: true,
			loading: false,
			selectedIndex: "1",
			toggle_one: 0,
			refreshPlansCounter: 0,
			selectedPlan: this.currentplan,
			duration: 1,
			selectedAmount: 0,
			alreadySubscribed: this.kycdone,
			currentPlanId: this.userplanid,
			defaultPlanId: this.userplanid + '_12',
			productType: this.producttype,
			pageUrl: this.pageurl,
			planPrices: [],
			passedData:[],
			buttonDurationValue: null,
			buttonPriceValue: null,
			buttonPricePMValue: null,
			buttonEncryptPriceValue: null,
			buttonEncryptDepositAmountValue: null,
			activeIndex:1,
		};
	},
	methods: {
		replaceSpaces(websiteTitle) {
            return websiteTitle.replace(/\s+/g, '-').toLowerCase();
        },
		setButtonData(duration,price,pricePerMonth,epd,planName){
			this.buttonDurationValue = duration;
			this.buttonPriceValue = price;
			this.buttonPricePMValue = pricePerMonth;
			this.buttonEncryptPriceValue = epd;
			depositAmount = document.getElementById('depositAmountShow').getAttribute('data-depositAmount');
			if(typeof dataLayer !== "undefined"){
				window.dataLayer = window.dataLayer || [];
				dataLayer.push({
					'event': 'plan_selected',
					'planType': planName,
					'planDuration': duration,
					'ecommerce': {
						'value': parseInt(price) + parseInt(depositAmount),
						'currency': 'INR',
						'items': [{
							'item_name': planName,
							'item_id': pricePerMonth,
							'price': price,
							'item_brand': 'Livpure Smart RO',
							'item_category': 'RO Subscription',
							'item_variant': planName + ' - ' + duration + ' months',
						}]
					},
					'item_brand': 'Livpure Smart RO111',
					'item_category': 'RO Subscription'
				});

				userType = 'guest';
				if (this.userid != '') userType = 'signin';
				dataLayer.push({
					event: 'set_user_id',
					user_id: this.userid,
					event_fired: "plan_selected",
					user_type: userType
				});
			}
			
		},

		sendInfo(planData){
			if(planData.item_name === 'bolt-mineralizer'){
				this.passedData = this.boltMinilizer;
			}
			if(planData.item_name === 'zinger-copper-hot'){
				this.passedData = this.unlimitedPlans;
			}
			if(planData.item_name === 'stealth-under-the-sink'){
				this.passedData = this.stealthPlans;				
			}
			if(planData.item_name === 'bolt-copper-mineralizer'){
				this.passedData = this.boltCopperPlan;				
			}
			if(planData.item_name === 'hydroboost'){
				this.passedData = this.alkalinePlans;				
			}

			let tabInterValPopup = setInterval(() => {				
				const childDiv = this.$refs.myModal.querySelector('.b_Plan1.active');				
				if(childDiv){					
					childDiv.click();				
					clearInterval(tabInterValPopup);
				}				
			},500);	
			
		},
		
		generateHref(planName,planId) {
            let id;
            if(planName === 'Silver'){              
                id = '#silver'+planId;
            }
			if(planName === 'Bolt-Unlimited'){              
                id = '#unlimited'+planId;
            }
			
			if(planName === 'Bolt-Cu-Unlimited'){             
				id = '#bolt-cu-unlimited'+planId;
			}
			if(planName === 'HydroBoost-Unlimited'){              
                id = '#gold'+planId;
            }      
			if(planName === 'Gold'){              
				id = '#goldTab'+planId;
			}      
            return id;
        },
		generateTabId(planName,planId) {
			let id;
			if(planName === 'Silver'){              
				id = 'silver'+planId;
			}
			if(planName === 'Bolt-Cu-Unlimited'){              
				id = 'bolt-cu-unlimited'+planId;
			}
			if(planName === 'Bolt-Unlimited'){              
				id = 'unlimited'+planId;
			}
			if(planName === 'HydroBoost-Unlimited'){              
				id = 'gold'+planId;
			}
			if(planName === 'Stealth-Unlimited'){              
				id = 'unlimited'+planId;
			}
			if(planName === 'Zinger-Unlimited'){              
				id = 'unlimited'+planId;
			}
			if(planName === 'Gold'){              
				id = 'goldTab'+planId;
			}
			
			
			return id;
		},
		generateId(planName , planId) {
            let id;
            if(planName === 'Silver'){              
                id = 'b_boltProduct' + planId;
            }
            if(planName === 'Bolt-Unlimited'){              
                id = 'b_bolt-Unlimited';
            }
			if(planName === 'Zinger-Unlimited'){              
                id = 'b_zingerProduct';
				// working
            }
			if(planName === 'Stealth-Unlimited'){              
                id = 'b_stealthProduct';
            }
			if(planName === 'HydroBoost-Unlimited'){              
                id = 'b_alkalineProduct';
            }
			if(planName === 'Bolt-Cu-Unlimited'){              
				id = 'bolt-cu-unlimited';
			}
            return id;
        },
		generateIdMob(planName, planId) {
            let id;
            if(planName === 'Silver'){              
                id = 'b_boltProduct-mob' + planId;
            }
            if(planName === 'Bolt-Unlimited'){              
                id = 'b_bolt-Unlimited';
            }
			if(planName === 'Bolt-Cu-Unlimited'){              
				id = 'bolt-cu-unlimited-mob';
			}
			if(planName === 'Zinger-Unlimited'){              
                id = 'b_zingerCopper-mob';
            }
			if(planName === 'Stealth-Unlimited'){              
                id = 'b_uts-mob';
            }
			if(planName === 'HydroBoost-Unlimited'){              
                id = 'alkaline_mob';
            }
			/* if(planName === 'Gold'){              
				id = '#goldTab';
			} */
            return id;
        },
		generateMobClassID(planName) {
            let id;
            if(planName === 'Silver'){              
                id = 'bolt_knowButton';
            }
            if(planName === 'Bolt-Unlimited'){              
                id = 'bolt_knowButton';
            }
			if(planName === 'Bolt-Cu-Unlimited'){              
				id = 'bolt-cu-unlimited';
			}
			if(planName === 'Zinger-Unlimited'){              
                id = 'copper_knowButton';
            }
			if(planName === 'Stealth-Unlimited'){              
                id = 'uts_knowButton';
            }
			if(planName === 'HydroBoost-Unlimited'){              
                id = 'alkaline_knowButton';
            }
            return id;
        },
		generateProductClassId(planName) {
            let id;
            if(planName === 'Silver'){              
                id = 'bolt';
            }
            if(planName === 'Bolt-Unlimited'){              
                id = 'bolt';
            }
			if(planName === 'Bolt-Cu-Unlimited'){              
				id = 'bolt-cu-unlimited';
			}
			if(planName === 'Zinger-Unlimited'){              
                id = 'copper';
            }
			if(planName === 'Stealth-Unlimited'){              
                id = 'uts';
            }
			if(planName === 'HydroBoost-Unlimited'){              
                id = 'alkaline';
            }
            return id;
        },
		subscribeNow() {
          		const duration = arguments[0].currentTarget.getAttribute('data-duration'),
		  		price = arguments[0].currentTarget.getAttribute('data-price'),
		  		pricepermonth = arguments[0].currentTarget.getAttribute('data-pricepermonth'),
				planId = arguments[0].currentTarget.getAttribute('data-plan-id'),
				planName = arguments[0].currentTarget.getAttribute('data-plan-tier'),
				rPlanId = arguments[0].currentTarget.getAttribute('data-rplan-id');
				planDpAmount = arguments[0].currentTarget.getAttribute('data-plan-dpAmount');
				planStatus = arguments[0].currentTarget.getAttribute('data-plan-status');
				planProductType = arguments[0].currentTarget.getAttribute('data-plan-productType');
				iD = arguments[0].currentTarget.getAttribute('data-id');

			if(typeof analytics !== "undefined"){
				analytics.track('Plan Selected', {
					plan_tier: planName,
					plan_id: planId,
					plan_duration: duration,
					rplan_id: rPlanId,
					plan_dpamount: planDpAmount,
					plan_producttype: planProductType,
					plan_status: planStatus,
				});
			}
			
			if (this.kycdone == '1' && this.userplanid == planId) {
				planNameValue = "Recharge Plan";
			} else if (this.kycdone == '1') {
				planNameValue = "Change Plan";

			} else {
				planNameValue = "Add to Cart";
			}
			if (this.kycdone == '1' && this.userplanid == planId) {
				purchase_type = "RO Subscription Recharged";
			} else if (this.kycdone == '1') {
				purchase_type = "RO Subscription Changed - Upgraded";

			} else {
				purchase_type = "RO Subscription Started";

			}
			if(typeof dataLayer !== "undefined"){
				dataLayer.push({
					ecommerce: null
				});  // Clear the previous ecommerce object.
				dataLayer.push({
					'event': planNameValue,
					'page_url': this.pageurl,
					'emi_value': '',
					'emi_duration': '',
					'purchase_type': purchase_type,
					'ecommerce': {
						'items': [{
							'item_name': 'Live Pure Smart - Bolt/Envy', // Name or ID is required.
							'item_id': pricepermonth,
							'price': price,
							'item_brand': 'Livpure Smart RO',
							'item_category': 'RO Subscription',
							'item_variant': planName,
							'quantity': '1'
						}]
					}
				});
			}
			const url = `${window.baseUrl}plan/save`; // Replace with your API endpoint URL

			const data = JSON.stringify({
				"planId": planId,
				"planProductType": planProductType,
				"planStatus":planStatus,
				"planName":planName,
				"rPlanId":rPlanId,
				"planDpAmount": planDpAmount,
				"iD":iD
			});
			const requestOptions = {
			method: 'POST',
				headers: {
					'Content-Type': 'application/json',
				},
				body: data,
			};
			
			fetch(url, requestOptions)
			.then(response => response.text())
			.then(data => {
				setTimeout(() => {
				window.location.href = `${window.baseUrl}plan/installationAddress`; // Replace with the URL to redirect to
				}, 1000); // 1000 milliseconds = 1 second
			})
			.catch(error => {
				console.error('Error:', error);
			});
		},
		getPlanTierImage: function (planName) {
			return plansIconPath[planName.toLowerCase()];
		},

		selectedplan() {

			planName = arguments[0].currentTarget.getAttribute('id')

			$('#selectedPlanName').attr('data-plan-name', planName);

		},
		selectDuration() {

			planName = arguments[0].currentTarget.getAttribute('data-plan-name')


			$('#' + planName + 'planduration').show();
		},
		depotooltiptxt()
		{
			 const planname = arguments[0].currentTarget.getAttribute('data-plan-name');
     	 $('#depotooltiptext'+ planname ).removeClass('d-none');
		},

		tooltipclose(){
	     const planname = arguments[0].currentTarget.getAttribute('data-plan-name');
     	 $('#depotooltiptext'+ planname ).addClass('d-none');
		},

		cancelpopup() {
			planName = arguments[0].currentTarget.getAttribute('data-plan-name')
			$('#' + planName + 'planduration').hide();
         },


		planDuration() {

			duration = arguments[0].currentTarget.getAttribute('data-duration');
			planName = arguments[0].currentTarget.getAttribute('data-tier');
			price = arguments[0].currentTarget.getAttribute('data-price');
			item_id = arguments[0].currentTarget.getAttribute('value');
			if(typeof dataLayer !== "undefined"){
				window.dataLayer = window.dataLayer || [];
				dataLayer.push({
					'event': 'plan_selected',
					'planType': planName,
					'planDuration': duration,
					'ecommerce': {
						'value': parseInt(price) + parseInt(this.plans[0].depositAmount),
						'currency': 'INR',
						'items': [{
							'item_name': planName,
							'item_id': item_id,
							'price': price,
							'item_brand': 'Livpure Smart RO',
							'item_category': 'RO Subscription',
							'item_variant': planName + ' - ' + duration + ' months',
						}]
					},
					'item_brand': 'Livpure Smart RO',
					'item_category': 'RO Subscription'
				});

				userType = 'guest';
				if (this.userid != '') userType = 'signin';	
				dataLayer.push({
					event: 'set_user_id',
					user_id: this.userid,
					event_fired: "plan_selected",
					user_type: userType
				});
			}

			semiAnuallyText = "";
			anuallyText = "";


			planNameValue = document.getElementById(planName).innerText;
			if (planNameValue.indexOf("Change") >= 0) {
				planNameValue = "Change Plan";
			} else {
				planNameValue = "Add to Cart";
			}



			if (arguments[0].currentTarget && arguments[0].currentTarget.hasAttribute('data-parent2')) {

				const parent = arguments[0].currentTarget.getAttribute('data-parent2'),
					planTier = arguments[0].currentTarget.getAttribute('data-tier');



				selectedTier = document.getElementById(parent);





				selectedTier.querySelector('.final-amount').textContent = arguments[0].currentTarget.getAttribute('data-price');
				//  selectedTier.querySelector('.subscribe-action-button').setAttribute('data-duration', arguments[0].currentTarget.getAttribute('data-duration'));
				selectedTier.querySelector('.subscribe-action-buttonnew').setAttribute('data-duration', arguments[0].currentTarget.getAttribute('data-duration'));
				document.getElementById('selectPlan').getAttribute('data-current-tier') !== planTier && document.getElementById('selectPlan').setAttribute('data-current-tier', planTier);

			}



			if (arguments[0].currentTarget && arguments[0].currentTarget.hasAttribute('data-parent')) {

				const parent = arguments[0].currentTarget.getAttribute('data-parent'),
					planTier = arguments[0].currentTarget.getAttribute('data-tier'),



					selectedTier = document.getElementById(parent);





				selectedTier.querySelector('.final-amount').textContent = arguments[0].currentTarget.getAttribute('data-price');
				selectedTier.querySelector('.subscribe-action-button').setAttribute('data-duration', arguments[0].currentTarget.getAttribute('data-duration'));
				// selectedTier.querySelector('.subscribe-action-buttonnew').setAttribute('data-duration', duration);
				document.getElementById('selectPlan').getAttribute('data-current-tier') !== planTier && document.getElementById('selectPlan').setAttribute('data-current-tier', planTier);

			}


		},
		planSelected() {
			planName = arguments[0].currentTarget.getAttribute('data-tier');
			pricePerMonth = arguments[0].currentTarget.getAttribute('data-pricePerMonth');
			websiteTitle = arguments[0].currentTarget.getAttribute('data-websiteTitle');
			window.dataLayer = window.dataLayer || [];
			dataLayer.push({
				'event': 'select_item',
				'planType': planName,
				'pricePerMonth':pricePerMonth,
				'planTitle':websiteTitle,
				'item_brand': 'Livpure Smart RO',
				'item_category': 'RO Subscription'
			});

			userType = 'guest';
			if (this.userid != '') userType = 'signin';
			dataLayer.push({
				event: 'set_user_id',
				user_id: this.userid,
				event_fired: "select_item",
				user_type: userType
			});
			document.getElementById('selectPlan').setAttribute('data-current-tier', arguments[0].currentTarget.getAttribute('data-tier'));
		},
		onResize() {
			this.isMobile = window.innerWidth < 600;
			document.getElementById('selectPlan') && document.getElementById('selectPlan').classList.add('xs-above');
		},
		fixedToOneDecimal: function (value) {
			const rounded = Math.pow(10, 1);
			return (value - Math.floor(value)) !== 0 ? (Math.round(value * rounded) / rounded).toFixed(1) : value;
		},
		loadJSON(callback) {

            var xobj = new XMLHttpRequest();
            xobj.overrideMimeType("application/json");
            xobj.open('GET', app.url, true)
            xobj.onreadystatechange = function () {
                if (xobj.readyState == 4 && xobj.status == "200") {
                    callback(xobj.responseText);
                }
            };
            xobj.send(null);
        },
        init() {
            let that = this
            that.loadJSON(function (response) {
                var data = JSON.parse(response);
                that.plans = data.plans;
				that.boltMinilizer = data.boltMinilizer;
				that.unlimitedPlans = data.unlimitedPlans;	
				that.stealthPlans = data.stealthPlans;
				that.alkalinePlans = data.alkalinePlans;
				that.boltCopperPlan = data.boltCopperPlan;
            });
        }
	},
	mounted() {
		this.init();
		this.onResize();
		window.addEventListener('resize', this.onResize, { passive: true });

		if (this.currentplan !== '') {
			document.getElementById('selectPlan').setAttribute('data-current-tier', this.currentplan.toLowerCase());
		}
		const referrer = document.referrer;
		// Store the referrer in sessionStorage if it matches specific conditions
		if (referrer.includes('stealth-under-sink') || referrer.includes('zinger-copper-hot') || referrer.includes('bolt-copper-minilizer')) {
			sessionStorage.setItem('previousReferrer', referrer);
		}

		// Retrieve the previous referrer from sessionStorage
		const previousReferrer = sessionStorage.getItem('previousReferrer');

		// Check if previousReferrer is not null before proceeding
		if (previousReferrer !== null) {
			// Switch statement to set the activeIndex based on the previous referrer
			switch (true) {
				case previousReferrer.includes('bolt-copper-minilizer'):
					this.activeIndex = 2;
					break;
				case previousReferrer.includes('stealth-under-sink'):
					this.activeIndex = 6;
					break;
				case previousReferrer.includes('zinger-copper-hot'):
					this.activeIndex = 5;
					break;
				default:
					this.activeIndex = 1;
					break;
			}
		}

	},
});


Vue.nextTick(function () {

	if(sessionStorage.getItem('previousReferrer')){
		let tabInterVal = setInterval(() => {
			// Trigger click event on the active prod_card element
			const activeProdCard = document.querySelector('.prod_card.active');
			if (activeProdCard) {
				activeProdCard.click();
				clearInterval(tabInterVal);
			}
		},500);
	}

	if(!sessionStorage.getItem('previousReferrer')){
		let tabInterVal = setInterval(() => {
			let element = document.querySelector('.prod_card');
			let elementMb = document.querySelector('#b_boltProduct-mob61');
			if(element){
				element.click();		
				clearInterval(tabInterVal);
			}
			if(elementMb){
				elementMb.click();		
				clearInterval(tabInterVal);
			}
		},500);
		let tabInterValmob = setInterval(() => {
			let element = document.querySelector('#b_boltProduct-mob');
			if(element){
				var classelement=document.getElementsByClassName(element);
				console.log("classelement", classelement);
				if(element.id=='b_uts-mob'){$("#b_tabName-mob").text("Stealth Under The Sink");}
				if(classelement){
					classelement[0].style.display='block';
					if(element.id=='alkaline_mob'){$("#b_tabName-mob").text("HydroBoost Details");}
					if(element.id=='b_zingerCopper-mob'){$("#b_tabName-mob").text("Zinger Copper Details");}
					if(element.id=='b_boltProduct-mob'){$("#b_tabName-mob").text("Bolt Mineralizer Details");}
					if(element.id=='b_uts-mob'){$("#b_tabName-mob").text("Stealth Under The Sink");}				
					clearInterval(tabInterValmob);
				}
			}			
		},500);
	}
	
 })