Vue.component("address-form", {

	template: `
	 <v-form ref="addressForm" id="addressForm" method="POST" :action="actionURL" @submit.prevent="saveAddress" class="desk-form-wrapper" novalidate lazy >
		  <div>
		  	<v-row py="0" my="0" v-if="is_error" style="background: #F2F2F2; margin-top: 0;">
				<v-alert text prominent type="error" icon="mdi-alert">
					{{error_message}}
				</v-alert>
			</v-row>
			 <div class="disabled-inputs">
				<v-icon class="mr-1">person</v-icon>
				<span class="subheading mr-2">{{name}}</span>
			</div>
			 <div class="disabled-inputs">
				<v-icon class="mr-1">email</v-icon>
				<span class="subheading mr-2">{{email}}</span>
			</div>
			 <div class="disabled-inputs">
				<v-icon class="mr-1">phone</v-icon>
				<span class="subheading mr-2">{{mobile}}</span>
			</div>

			<v-col col="12" class="py-0">
				<v-text-field 
					label="Flat / House / Floor / Building" 
					name="addressLine1" 
					maxlength="201" 
					type="text" 
					v-model="addressLineFirstLine" 
					:error-messages="addressLine1Error"  
					@focus="resetValidation"
				/>
				<v-text-field 
					label="Colony / Street / Locality" 
					name="addressLine2" 
					maxlength="201" 
					type="text" 
					v-model="addressLineSecondLine" 
					:error-messages="addressLine2Error"  
					@focus="resetValidation"
				/>
				<v-text-field 
					label="6 digit pincode (e.g. 110011)" 
					name="pincode" 
					type="tel" 
					pattern="[1-9][0-9]{5}" 
					@keypress="isNumber($event)"
					minlength="6" 
					maxlength="6" 
					@input="fetchAreaAndCity" 
					v-model="pinCode" 
					:error-messages="pinCodeError"  
					@focus="resetValidation"
				/>
				<v-select 
					ref="area" 
					:items="areas"  
					name="vselectArea" 
					item-text="area" 
					item-value="area_id" 
					hide-selected
					no-data-text="Please enter a valid pincode." 
					label="Select Area" 
					@input="addHubCode"
					:error-messages="areaError"  
					@focus="resetValidation" 
					v-model="vSelectedArea"
				/>
				<v-text-field 
					name="area" 
					type="text"  
					v-model="selectedArea" 
					readonly 
					v-show="false"
				/>
				    <v-text-field 
					name="vselectCity" 
					:value="popupcity" 
					label="Select City" 
					item-text="cityName" 
					item-value="_id" 
					@input="addState" 
					:error-messages="cityError" 
					@focus="resetValidation"  
					v-model="vSelectedCity"
					readonly
				/>
				<v-text-field
				 	name="city" 
				 	type="text" 
				 	v-model="selectedCity" 
				 	placeholder="City" 
				 	v-show="false" 
				 	readonly
				 />
				<v-card-text 
					class="flex alternate-mobile-wrapper px-0 mx-0" 
					@click="showAlternatePhNo = true"
					v-if="!showAlternatePhNo">
						<span 
							class="show-alternate">Alternate mobile number
						</span>
						<img 
							src="/assets/images/plusSign.svg" 
							width="22px" 
							height="22px"
							alt="+"
						>
				</v-card-text>
				<v-text-field 
					label="Alternate mobile number (If any)" 
					ref="alternatePhNo" 
					v-model="alternatePhNo" 
					maxlength="10" 
				 	name="alternatePhNo" 
				 	type="tel" 
				 	v-show="showAlternatePhNo"
				 	@keypress="isNumber($event)"
				 	@keydown.space.prevent  
				 	:error-messages="alternatePhNoError"  
				 	@focus="resetValidation"
				 />
				<v-text-field 
					ref="state" 
					name="state" 
					type="text" 
					v-model="selectedState" 
					readonly 
					v-show="false"
				/>
				<v-text-field 
					ref="hubCode" 
					name="hub_code" 
					type="text" 
					v-model="selectedHubCode" 
					readonly 
					v-show="false"
				/>
			</v-col>
			<v-card-actions 
				class="my-6  flex-column">
				<v-btn 
					type="submit" 
					class="primary action-btn" 
					block>Save &amp; Continue
				</v-btn>
			</v-card-actions>
			<v-card-actions class="text-center align-me-center" style="cursor:pointer">
			<span 
			class="back-btn"
			id="backbtn"
		
			@click="backbtn()"
			block>
	    	<img src="/ro-subscription/assets/images/back-button.svg" style="padding: 0px 4px 0px 0px;">Back
		  </span>
			</v-card-actions>
		  </div>
	</v-form>`,
	props: ['userid', 'name', 'email', 'mobile', 'address_l1', 'address_l2', 'sel_city', 'sel_state', 'sel_pincode', 'sel_area', 'hubcode', 'is_error', 'error_message', 'edit', 'altphno', 'popupcity','notavailError'],
	data() {
		return {
			actionURL: '',
			showAlternatePhNo: false,
			showPassword: false,
			validateCode: '',
			oldPinCode: '',
			cities: app.cities,
			addressLineFirstLine: this.address_l1,
			addressLineSecondLine: this.address_l2,
			selectedCity:'',
			vSelectedCity: '',
			pinCode: this.sel_pincode,
			alternatePhNo: this.altphno,
			selectedArea: this.sel_area,
	fromreview:this.fromreview,
			vSelectedArea: {},
			areas: [],
			areasArry: [],
			selectedState: this.sel_state,
			selectedHubCode: this.hubcode,
			notavailError:this.notavailError,
			errors: [],
			//alternatePhNo: '',
			notServiceable: false,
			//
			addressLine1Error: [],
			addressLine2Error: [],
			pinCodeError: [],
			areaError: [],
			cityError: [],
			alternatePhNoError: []

		}
	},
	methods: {
		isNumber(evt) {
			evt = (evt) ? evt : window.event;
			const charCode = (evt.which) ? evt.which : evt.keyCode;
			if ((charCode > 31 && (charCode < 48 || charCode > 57))) {
				evt.preventDefault();
			} else {
				return true;
			}
		},
		resetValidation() {
			if(arguments[0].currentTarget.name === 'pincode'){
				this.pinCodeError = [];this.areaError = [];this.cityError = [];
			}
			arguments[0].currentTarget.name === 'addressLine1' && (this.addressLine1Error = []);
			arguments[0].currentTarget.name === 'addressLine2' && (this.addressLine2Error = []);
			arguments[0].currentTarget.name === 'vselectArea' && (this.areaError = []);
			arguments[0].currentTarget.name === 'vselectCity' && (this.cityError = []);
			arguments[0].currentTarget.name === 'alternatePhNo' && (this.alternatePhNoError = []);
		},
		resetErrorAreaAndCity(){
			this.areaError = [];this.cityError = [];
		},
		saveAddress() {

			//console.log(this.addressLine1, this.addressLine2, this.pincode , this.selectedArea, this.alternatePhNo, this.areaError, this.cityError )
			this.addressLine1Error = this.addressLineFirstLine.trim().length === 0 ? ['This information is required.'] : [];
			this.addressLine2Error = this.addressLineSecondLine.trim().length === 0 ? ['This information is required.'] : [];

			if (this.pinCode.trim().length === 0) {
				this.selectedCity
				this.pinCodeError = ['This information is required.'];
			} else if (this.pincode !== '' && this.pinCode.length !== 6) {
				this.pinCodeError = ['Please enter a  valid pincode.'];
			} else {
				if (this.notServiceable) {
					this.pinCodeError = 'We are currently not servicing in this area.'
				} else {
					this.pinCodeError = !pinCodeRegex.test(this.pinCode) ? ['Please enter a  valid pincode.'] : [];
				}
			}
			this.areaError = this.selectedArea.length === 0 ? ['This information is required.'] : [];
			this.cityError = this.selectedCity.length === 0 ? ['This information is required.'] : [];

			if (this.alternatePhNo.trim().length !== 0) {
				this.alternatePhNoError = (this.alternatePhNo.length < 10 || !mobileRegex.test(this.alternatePhNo)) ? ['Enter a valid mobile number.'] : [];
			}

			if (this.addressLine1Error.length === 0 && this.addressLine2Error.length === 0
				&& this.pinCodeError.length === 0 && this.areaError.length === 0 && this.cityError.length === 0 && this.alternatePhNoError.length === 0) {
				if(typeof analytics !== "undefined"){
					analytics.identify(this.userid, {
						pincode: this.pinCode,
						city: this.selectedCity,
						state: this.selectedState
					});

					analytics.track('Added Address', {
						pincode: this.pinCode,
						city: this.selectedCity,
						state: this.selectedState
					});
				}

				this.$refs['addressForm'].$el.submit();
			}
		},
		addState() {
			this.resetErrorAreaAndCity();
			const cityDetails = app.lookupStates[arguments[0]];
			this.selectedState = cityDetails.state;
			this.selectedCity = cityDetails.city;
		},
		addHubCode() {
			this.resetErrorAreaAndCity();
			const area = arguments[0];
			const areaDeatils = this.areasArry.find(function (element) {
				return element.area === area;
			});



			this.selectedArea = areaDeatils.area;


			this.vSelectedCity = this.selectedCity =  areaDeatils.city;
			this.selectedState = areaDeatils.state;
			this.selectedHubCode = areaDeatils.hub_code;
		},
		backbtn(){
	if(this.fromreview == 'true' || this.fromreview == '1'){
				 window.location.href = `${window.baseUrl}Review`;
			}else{
			
			window.location.href = `${window.baseUrl}Plan`;//added plan Name
		}

		},

		async fetchAreaAndCity() {
			this.vSelectedArea = this.selectedArea = "";
			this.vSelectedCity = this.selectedCity = "";
			const pinCode = arguments[0];
			this.pinCodeError = [];
			this.notServiceable = false;

			if (pinCode.trim() !== '' && pinCode.trim().length === 6) {

				if (!pinCodeRegex.test(this.pinCode)) {
					this.pinCodeError = ['Please enter a  valid pincode.'];
				} else {
					this.oldPinCode = pinCode;
					try {
						const data = await getData(`${window.baseUrl}Address/fetchLocation`, 'post',
							{
								"pincode": pinCode
							}
						);

						const response = JSON.parse(data);
						if (response.success === false ||response.success == 'false' || response == undefined) {
							this.areas = [];
							this.areasArry = [];

							this.notServiceable = true;
							this.pinCodeError = ['We are currently not servicing in this area.'];
							this.vSelectedArea=  this.selectedArea = "";
							this.vSelectedCity = this.selectedCity = "";
						} else if (Array.isArray(response.pincode)) {

							this.areas = [];
							this.areasArry = [];
							const isplanavailable = await getData(`${window.baseUrl}address/isplanavailable`, 'post',
								{
									"city": response.pincode[0].city
								}
							);
							if(isplanavailable == 'N'){
								this.notServiceable = true;
								this.pinCodeError = ['This plan does not exist in the selected pincode. Kindly change your plan to continue.'];
							}
							response.pincode.forEach(areaObj => {
								if (areaObj && areaObj != "" && areaObj != null && areaObj.hasOwnProperty('area')) {
									this.pincodeCity = areaObj.city;
									this.areas.push(areaObj.area);
									this.areasArry.push(areaObj);
								}
							})
						}
						else {
							this.records = response.pincode;
							this.areas.push(this.records.area);
							this.areasArry.push(this.records);
						}
					} catch (err) {
						console.log(err);
					}
				}
			} else {
				this.areas = [];
				this.areasArry = [];
				// this.pinCodeError = ['Please enter a  valid pincode.'];
			}
		},
		async fetchInitialDetails() {
			if (this.sel_pincode !== '') {
				await this.fetchAreaAndCity(this.sel_pincode);
				const area_name = this.sel_area;
				const user_area = this.areasArry.find(function (element) {
					return element.area === area_name
				});
				if(typeof user_area != 'undefined'){
					this.vSelectedArea = {
						area_id: user_area.area,
						area: this.sel_area
					};
					if(this.sel_city !== ''){
					this.vSelectedCity = this.sel_city;
					this.selectedCity = this.sel_city;
					}
				}else if(this.sel_city !== ''){
					this.vSelectedArea=  this.selectedArea = "";
					this.vSelectedCity = this.selectedCity = "";
					//this.sel_city= '';
					
				}

			}
		}
	},
	mounted() {
		this.actionURL = this.edit == 'Y' ? `${window.baseUrl}Address/updateAddress` : `${window.baseUrl}Address/saveAddress`;

		this.fetchInitialDetails();
	},
	watch: {}
});
