Vue.component("review-pay", {
	template: `
	<v-card flat class="mx-0 px-0">
		<v-row 
			justify="center" 
			align="center" 
			class="mb-2 select-plan-text align-me-center" style="font-size:16px;font-weight:bold;"
			v-if="$vuetify.breakpoint.xs">
			Review &amp; Pay
		</v-row>
		<div class="review-payment-details">
			<v-card-text 
				class="flex flex-column review-plan-border">
				<span 
					class="mb-2 review-section-tile">Plan Details
				</span>
				<div>
					<span 
						class="review-pay-title">Plan Name:
					</span>
					<span 
						class="review-address-text">{{name}}
					</span>
				</div>
			 
				<div 
				class="flex flex-row" v-if="paid !='N'">
				<span 
					class="review-pay-title">Payable  amount:
					<span 
						class="success--text pay-amount">
						<v-icon class="rs-icon-pay">mdi-currency-inr</v-icon>{{payableamount}}&nbsp;(Incl of GST)
					</span>
				</span>
			</div>

				

			   <div v-if="paid==='N'">

			   <div 
				class="flex flex-row">
				<span 
					class="review-pay-title">Plan amount:
					<span 
						class="success--text pay-amount" style="color:black !important">
						<v-icon class="rupees-icon-pay">mdi-currency-inr</v-icon>{{payableamount}}&nbsp;(Incl of GST)
					</span>
				</span>
			</div>
			
				<div class="flex flex-row">
				
				<span class="review-pay-title">Installation Charge(One Time):
					<span class="success--text" style="color:black !important">
					<del style="font-weight:normal;color:darkgrey!important;"> ₹300</del>
						<v-icon class="rupees-icon-pay">mdi-currency-inr</v-icon>{{charges}}
					</span>
				</span>
			</div>
			

			<div v-if="deposit === 'true'">
				
					<span class="review-pay-title">Security Deposit:
		<span class="alignright success--text pay-amount" style="color:#333333 !important">
						
							<v-icon class="rupees-icon-pay">mdi-currency-inr</v-icon>{{depositamount}}
						</span>
					</span>
<div class="clear-both">
                <div class="security-padd">
                    <p class="alignleft plan-details-sub-section review-pay-title">Security Deposit is 100% Refundable</p>
				</div>
</div>

</div>


			<div 
				class="flex flex-row">
				<span 
					class="review-pay-title">Payable amount:
					<span 
						class="success--text pay-amount">
						<v-icon class="rs-icon-pay">mdi-currency-inr</v-icon>{{newtotalamount}}
					</span>
				</span>
			</div>
			</div>

			<div v-if="paid !='N'">
					<span 
						class="review-pay-title">Duration:
					</span>
					<span 
						class="review-address-text">{{subperiod}} {{subperiod == 1 ? 'Month' : 'Months'}}
					</span>
				</div>
			
			</v-card-text>
			<v-expansion-panels v-model="panel" hover accordion >
			<v-expansion-panel>
				<v-expansion-panel-header @click="onClickSubscribe"> <span class="review-pay-title"> Subscribe @ {{permonthamount}} per Month</span> </v-expansion-panel-header>
				<v-expansion-panel-content>
			<div class="mainClass">
			<div class="innerMainClass v-container">
							<div class="align-me-center  mb-2 flex-column" >
								<span class="mb-2 review-section-tile" style="font-size: 19px;">Choose your payment Method</span>
							</div>
							<!-- Credit / Debit Card Section -->
							<div class="credit_debit_card headline mb-1" style="width:100%">
								<div class="mainCardSection">
									<div style="display: block">
										<v-card-actions class="mt-4  flex-column">
											<v-container>
											<label style="cursor:pointer;">
												<v-row class="">
													<v-col cols="3" sm="1" xs="3">
														<input type="radio" value="card_button" id="card_button" data-form="card_button" name="pay_methods">
													</v-col>
													<v-col cols="6" sm="6" xs="3">
														<p for="card_button" class="pullLeft">Credit / Debit ATM Card</p>
													</v-col>
												</v-row>

												<v-row class="cardInnerSection" for="card_button">			
													<v-col cols="4" sm="3" xs="3" class="respImages">
														<v-img src="./assets/images/visacard-icon-4x.png" alt="Livpuresmart visacard Icon"></v-img>
													</v-col>
													<v-col cols="4" sm="3" xs="3" class="respImages">
														<v-img src="./assets/images/mastercard-icon-4x.png" alt="Livpuresmart Mastercard Icon"></v-img>
													</v-col>
												</v-row>
												</label>
											</v-container>
											<form id="reviewForm" method="POST">
												<input type="hidden" :name="'data'+planid" :id="'data'+planid" :value="orderdata" />
												<input type="hidden" name="radio_button" :value="duration" checked/>
												<v-btn 
													style="display: none"
													class="primary action-btn mt-6 card_button" 
													id="rzp-button1"
													@click="showPayentGatewayForCardUpi" 
													:disabled="!checkbox">
													Authorize&nbsp;₹&nbsp;{{permonthamount}}*
												</v-btn>
											</form>
											<!-- div class="align-me-center  mb-2 flex-column">
												<p><span class="subtitle-2" style="color:#452f8a !important;">
												*₹&nbsp;{{amount}} will be charged to authorize</span></p>
											</div -->
											<!-- div class="align-me-center mb-2">
												<div class="term-conditions-checkbox">
													<v-checkbox	
														v-model="checkbox"
														color="primary" 
														class="shrink ml-2 mx-0 px-0" 
														label="" 
														hide-details dense/>
													<span class="term-conditions">I hereby agree to Livpure Smart 
														<a href="TermsCondition" target="_blank" class="term-conditions hand-cursor"><strong>Terms & Conditions</strong>and Authorize automatic charge of my payment instrument.</a>
													</span>
												</div>
											</div -->

										</v-card-actions>
									</div>
								</div>
							</div>
							<!-- Debit/Credit Card ENd -->

							<!-- Net Banking  Section-->
							<div class="credit_debit_card headline mb-1" style="width:100%">
								<div class="mainCardSection">
									<div style="display: block">
										<v-card-actions class="mt-4  flex-column">
											<v-container>
											<label style="cursor:pointer;">
												<v-row class="">
													<v-col cols="3" sm="1" xs="3">
														<input type="radio" value="net_banking_button" id="net_banking_button" data-form="net_banking_button" name="pay_methods">
													</v-col>
													<v-col cols="6" sm="6" xs="3">
														<p class="pullLeft" for="card_button">Net Banking</p>
													</v-col>
												</v-row>
												<v-row class="cardInnerSection"  for="card_button">			
													<v-col cols="4" sm="6" xs="3" class="respImagesNetBank">
														<v-img src="./assets/images/net-banking-icon-4x.png" alt="Livpuresmart Netbanking Icon"></v-img>
													</v-col>
												</v-row>
												</label>
											</v-container>
											<form id="reviewForm" method="POST">
												<input type="hidden" :name="'data'+planid" :id="'data'+planid" :value="orderdata" />
												<input type="hidden" name="radio_button" :value="duration" checked/>
												<v-btn 
													style="display: none"
													class="primary action-btn mt-6 net_banking_button" 
													id="rzp-button1"
													@click="showPayentGatewayForEmandate" 
													:disabled="!checkbox">
													Authorize&nbsp;₹&nbsp;{{permonthamount}}*
												</v-btn>
											</form>
											<!-- div class="align-me-center  mb-2 flex-column">
												<p><span class="subtitle-2" style="color:#452f8a !important;">
												*₹&nbsp;{{amount}} will be charged to authorize</span></p>
											</div -->
											<!-- div class="align-me-center mb-2">
												<div class="term-conditions-checkbox">
													<v-checkbox	
														v-model="checkbox"
														color="primary" 
														class="shrink ml-2 mx-0 px-0" 
														label="" 
														hide-details dense/>
													<span class="term-conditions">I hereby agree to Livpure Smart 
														<a href="TermsCondition" target="_blank" class="term-conditions hand-cursor"><strong>Terms & Conditions</strong>and Authorize automatic charge of my payment instrument.</a>
													</span>
												</div>
											</div -->

										</v-card-actions>
									</div>
								</div>
							</div>
							<!-- Net Banking END -->



							<!-- UPI Section Starts -->
							<div class="credit_debit_card headline mb-1" style="width:100%">
								<div class="mainCardSection">
									<div style="display: block">
										<v-card-actions class="mt-4  flex-column">
											<v-container>
											<label style="cursor:pointer;">
												<v-row class="">
													<v-col cols="3" sm="1" xs="3">
														<input type="radio" value="wallet_button" id="wallet_button" data-form="wallet_button" name="pay_methods">
													</v-col>
													<v-col cols="6" sm="6" xs="3">
														<p class="pullLeft" for="card_button">UPI</p>
													</v-col>
												</v-row>
												<v-row class="cardInnerSection"  for="card_button">			
													<v-col cols="4" sm="4" xs="3" class="respImagesPaytm">
														<v-img src="./assets/images/UPI-icon-4x.webp" alt="Livpuresmart UPI Icon"></v-img>
													</v-col>
												</v-row>
												</label>
											</v-container>
											<form id="reviewForm" method="POST">
												<input type="hidden" :name="'data'+planid" :id="'data'+planid" :value="orderdata" />
												<input type="hidden" name="radio_button" :value="duration" checked/>


												<v-btn 
													style="display: none"
													class="primary action-btn mt-6 wallet_button" 
													id="rzp-button1"
													@click="showPayentGatewayForUpi" 
													:disabled="!checkbox">
													Authorize&nbsp;₹&nbsp;{{permonthamount}}*
												</v-btn>
											</form>
											<!-- div class="align-me-center  mb-2 flex-column">
												<p><span class="subtitle-2" style="color:#452f8a !important;">
												*₹&nbsp;{{amount}} will be charged to authorize</span></p>
											</div -->
											<!-- div class="align-me-center mb-2">
												<div class="term-conditions-checkbox">
													<v-checkbox	
														v-model="checkbox"
														color="primary" 
														class="shrink ml-2 mx-0 px-0" 
														label="" 
														hide-details dense/>
													<span class="term-conditions">I hereby agree to Livpure Smart 
														<a href="TermsCondition" target="_blank" class="term-conditions hand-cursor"><strong>Terms & Conditions</strong>and Authorize automatic charge of my payment instrument.</a>
													</span>
												</div>
											</div -->

										</v-card-actions>
									</div>
								</div>
							</div>
							<!-- UPI Section END -->
							
							<!-- Pay Button -->

							<div class="align-me-center  mb-2 flex-column">
								<v-btn 
									class="primary action-btn mt-6" 
									id="rzp-button1"
									@click="redirectPayment" 
									:disabled="!checkbox"
									>
									Pay&nbsp;₹{{newtotalamount}}
								</v-btn>
							</div>
							<div class="align-me-center mb-2">
								<div class="term-conditions-checkbox">
									<v-checkbox	
										v-model="checkbox"
										color="primary" 
										class="shrink ml-2 mx-0 px-0" 
										label="" 
										hide-details dense/>
									<span class="term-conditions">I hereby agree to Livpure Smart 
										<a href="terms" target="_blank" class="term-conditions hand-cursor"><strong>Terms & Conditions</strong>and Authorize automatic charge of my payment instrument.</a>
									</span>
								</div>
							</div>
							<!-- -->
			</div>
     		</div>
				</v-expansion-panel-content>
			</v-expansion-panel>
			</v-expansion-panels>
			<v-card-text class="flex flex-column">
				<div 
					class="address-wrapper">
					<span 
						class="mb-2 review-section-tile">Installation Address
					</span>
					<v-btn 
						href="address/edit" 
						class="edit-button" 
						primary 
						text 
						v-if="ekyc === 'N'">Edit
					</v-btn>
				</div>
				<div class="flex flex-row">
					<div 
						class="flex flex-column installation-address-wrapper">
						<span 
							class="review-address-text">{{address}}
						</span>
						<span 
							class="review-address-text">{{area}}
						</span>
						<span 
							class="review-address-text">{{city}}
						</span>
						<span 
							class="review-address-text">{{state}} - {{pincode}}
						</span>
					</div>
					<div>
						<img 
							src="./assets/images/addressPointer.svg" 
              alt="Livpuresmart Addresspointer Icon"
							width="50px"
							height="50px" 
							style="margin-right: 10px;"
						>
					</div>
				</div>
			</v-card-text>
		</div>
		<div class="trusted-bar">
				<v-row 
					class="flex flex-row mx-3">
					<v-col 
						class="trusted-wrapper" 
						cols="6">
						<div 
							class="align-me-center">
							<img src="/assets/images/trusted.svg" alt="Livpuresmart Trusted Icon">
							<span>Trusted by over 25000 customers</span>
						</div>
					</v-col>
					<v-col class="free-cancellation" cols="6">
						<div 
							class="align-me-center">
							<img src="/assets/images/cancellation.svg" alt="Livpuresmart cancellation Icon">
							<span>7 Days free cancellation</span>
						</div>
					</v-col>
				</v-row>
			</div>
	</v-card>`
	,
		props: ["planid", "amount", "name", "duration", "address","rechargetotalamount", "area","permonthamount", "permonth" ,"monthamount","quartertotalamount","city", "state", "pincode", "charges", "orderdata", "action", "ekyc", "paid",
			"dataamount",
			"dataname", 
			"datadescription",
			"dataprefillname",
			"dataprefillemail",
			"dataprefillcontact", 
			"datanotesshoppingorder",
			"datathemecolor",
			"datakey",
			"dataimage",
			"rorderid",
			"quarteramount",
			"hasreferral",
			"datanotesinstallationamount",
			"datanotesserialno",
			"datanotesproduct",
			"datanotesuserid",
			"datanotesname",
			"datanotesemail",
			"datanotescontact",
			"datanotesplanid",
			"emandcustid",
			"emandorderid",
			"cardorderid",
			"upiorderid",
			"datanotesrechargetype",
			"datanotesshoppingorder",
			"depositamount",
			"datanotesdepositamount",
			"deposit",
			"newtotalamount"


	         ],
	data() {
		return {
			panel: 0,
			panel1: 0,
			innerpanel:0,
			checkbox: true,
			subperiod:1,
			quartercalc:0,
			payableamount:this.permonth,
			totalPayableAmount:this.monthamount
			


		}
	},
	created: function () {},
	methods: {
		redirectPayment() {
			var selectedPayment = $("input[name='pay_methods']:checked").attr("data-form");
			$("button."+selectedPayment).trigger("click");
		},
		// showPayTMPaymentGateway(){
		// 	 window.location.href = `${window.baseUrl}payTMCheckout/PaytmGateway`;	
		// },
		showPaymentGatewayOrder(){
			analytics.track(this.paid === 'Y' ? 'Clicked Recharge' : 'Clicked Payment', {
			payment_method: 'Credit Card / QR Code / Wallet',
			payment_type:'Quarterly'
			});
			var options = {
			"key":this.datakey,
			"order_id":this.rorderid,
			"name": this.dataname,
			"description":this.datadescription,
			"image":this.dataimage,
			"amount":this.amount,
			"currency":"INR",
			"prefill": {
			"name": this.dataprefillname,
			"email": this.dataprefillemail,
			"contact":this.dataprefillcontact,
			},
			"notes":{
				"shopping_order_id":this.datanotesshoppingorder,
				"name": this.datanotesname,
				"email": this.datanotesemail,
				"contact":this.datanotescontact,
				"rechargeType":"3_months",
				"payment_from":"Web",
				"business_type":"subscription",
				"business":"WAAS",
				"Connectivity":"BLE",
				"serial_no":this.datanotesserialno,
				"productType":this.datanotesproduct,
				"user_id":this.datanotesuserid,
				"plan_id":this.datanotesplanid,
				"installation_amount":this.datanotesinstallationamount
				},
			"theme": {
			"color": this.datathemecolor
			},
			"handler": function(response) {
            window.location.href = `${window.baseUrl}checkout/orderProcess?
            rPayId=${btoa(response.razorpay_payment_id)}
            &rPaySign=${btoa(response.razorpay_signature)}
            &rPayOId=${btoa(response.razorpay_order_id)}`;
            }
            };
			var rzp1 = new Razorpay(options).open();
		},
		showPayentGatewayForCardUpi(){
				analytics.track(this.paid === 'Y' ? 'AC_Clicked Recharge' : 'AC_Clicked Payment', {
				payment_method: 'Credit Card / QR Code / Wallet'
			});

			var options = {
			"key":this.datakey,
			"order_id":this.cardorderid,
			"customer_id":this.emandcustid,
			"recurring": "1",
			"name": this.dataprefillname,
			"description":this.datadescription,
			"image":this.dataimage,
			"amount":this.amount,
			"currency":"INR",
			"prefill": {
			"name": this.dataprefillname,
			"email": this.dataprefillemail,
			"contact":this.dataprefillcontact,
			},
		"notes":{
			"shopping_order_id":this.datanotesshoppingorder,
			"name": this.datanotesname,
			"email": this.datanotesemail,
			"contact":this.datanotescontact,
			"rechargeType":"plan",
			"payment_from":"Web",
			"business_type":"subscription",
			"business":"WAAS",
			"Connectivity":"BLE",
			"serial_no":this.datanotesserialno,
			"productType":this.datanotesproduct,
			"user_id":this.datanotesuserid,
			"plan_id":this.datanotesplanid,
			"installation_amount":this.datanotesinstallationamount
			},
			"theme": {
			"color": this.datathemecolor
			},
			"handler": function(response) {
            window.location.href = `${window.baseUrl}checkout/processPaymentCard?
            rPayId=${btoa(response.razorpay_payment_id)}
            &rPaySign=${btoa(response.razorpay_signature)}
            &rPayOId=${btoa(response.razorpay_order_id)}`
            }
            };
			var rzp1 = new Razorpay(options).open();
		},

				showPayentGatewayForUpi(){
			analytics.track(this.paid === 'Y' ? 'AC_Clicked Recharge' : 'AC_Clicked Payment', {
			payment_method: 'Credit Card / QR Code / Wallet'
		});

		var options = {
		"key":this.apikey,
		"order_id":this.upiorderid,
		"customer_id":this.emandcustid,
		"recurring": "1",
		"name": this.dataprefillname,
		"description":this.datadescription,
		"image":this.dataimage,
		"amount":this.amount,
		"currency":"INR",
		"prefill": {
		"name": this.dataprefillname,
		"email": this.dataprefillemail,
		"contact":this.dataprefillcontact,
		},
		"notes":{
			"shopping_order_id":this.datanotesshoppingorder,
			"name": this.datanotesname,
			"email": this.datanotesemail,
			"contact":this.datanotescontact,
			"rechargeType":"plan",
			"payment_from":"Web",
			"business_type":"subscription",
			"business":"WAAS",
			"Connectivity":"BLE",
			"serial_no":this.datanotesserialno,
			"productType":this.datanotesproduct,
			"user_id":this.datanotesuserid,
			"plan_id":this.datanotesplanid,
			"installation_amount":this.datanotesinstallationamount
			},
		"theme": {
		"color": this.datathemecolor
		},
		"handler": function(response) {
		window.location.href = `${window.baseUrl}checkout/processPaymentUpi?
		rPayId=${btoa(response.razorpay_payment_id)}
		&rPaySign=${btoa(response.razorpay_signature)}
		&rPayOId=${btoa(response.razorpay_order_id)}`
		}
		};
		var rzp1 = new Razorpay(options).open();
	},
		showPayentGatewayForEmandate() {
			analytics.track(this.paid === 'Y' ? 'AC_Clicked Recharge' : 'AC_Clicked Payment', {
				payment_method: 'Credit Card / QR Code / Wallet'
			});

			var options = {
			"key":this.datakey,
			"order_id":this.emandorderid,
			"customer_id":this.emandcustid,
			"recurring": "1",
			"name": this.dataprefillname,
			"description":this.datadescription,
			"image":this.dataimage,
			"amount":this.amount,
			"currency":"INR",
			"prefill": {
			"name": this.dataprefillname,
			"email": this.dataprefillemail,
			"contact":this.dataprefillcontact,
			},
	       "notes":{
			"shopping_order_id":this.datanotesshoppingorder,
			"name": this.datanotesname,
			"email": this.datanotesemail,
			"contact":this.datanotescontact,
			"rechargeType":"plan",
			"payment_from":"Web",
			"business_type":"subscription",
			"business":"WAAS",
			"Connectivity":"BLE",
			"serial_no":this.datanotesserialno,
			"productType":this.datanotesproduct,
			"user_id":this.datanotesuserid,
			"plan_id":this.datanotesplanid,
			"installation_amount":this.datanotesinstallationamount
			},
			"theme": {
			"color": this.datathemecolor
			},
			"handler": function(response) {
            window.location.href = `${window.baseUrl}checkout/processPaymentNetBanking?
            rPayId=${btoa(response.razorpay_payment_id)}
            &rPaySign=${btoa(response.razorpay_signature)}
            &rPayOId=${btoa(response.razorpay_order_id)}`
            }
            };
			var rzp1 = new Razorpay(options).open();
		},
		onClickSubscribe(){this.payableamount = this.permonth;this.subperiod = 1;this.totalPayableAmount = this.monthamount},
		onClickQuarter() {

			this.payableamount = this.amount;
			this.subperiod =3;
			this.totalPayableAmount=this.quartertotalamount;
			
		}
	},

	watch: {}
});
