Vue.component("review-pay", {
	template: `
<v-card flat class="mx-0 px-0" style="background-color:#f2f2f2;">
<div class="row" style="display:block !important;">
 <section class="text-center align-me-center">
		<span 
		class="mb-2 container-heading" style="color:#333333;font-weight:bold;font-size: 14px; font-family:Roboto;">Review & Pay
		    </span>
     </section>
    </div>


<div class="review-payment-details">
			<v-card-text 
	class="flex flex-column review-plan-border bg-white">
	<span 
				class="mb-2 review-section-tile">Your Plan
				</span>

					<div>
						<span class="review-plan-title payment_heading">Plan Name:</span>
						<span class="alignright success--text pay-amount" style="color:#333333 !important; font-weight:600;">
						<div v-if="isLoading" class="loading-placeholder">
						<img :src="cdn + 'assets/images/loading.gif'" style="width:20px;" alt="Loading...">
						</div>
						<div v-else>
						<div v-if="name == 'Silver'">Silver</div>
						<div v-if="name == 'Gold'">Gold</div>
						<div v-if="isUnlimitedPlan">Family Plan </div>
						</div>
						</span>
</div>	
<div>

<span 
class="review-plan-title payment_heading">Monthly Rental:&nbsp;<span style="color:#000; font-weight:600">(Incl of GST)</span>
	<span 
class="alignright success--text pay-amount" style="color:#333333 !important; font-weight:600;">
	<div v-if="isLoading" class="loading-placeholder">
		<img :src="cdn + 'assets/images/loading.gif'" style="width:20px;" alt="Loading...">
		</div>
	<div v-else>
	<v-icon class="rupees-icon-pay">mdi-currency-inr</v-icon>{{pricepermonth}} </div>
						</span>
</span>

</div>
<div class="flex flex-row">
				<div 
					class="flex flex-column installation-address-wrapper">
<v-btn href="plan" 
				          class="edit-btn">Change Plan	
						</v-btn>
	</div>
					</div>
  </v-card-text>
		</div>
	<div class="review-payment-details bg-white">
				<v-card-text
				class="flex flex-column review-plan-border">
				<span 
					class="mb-2 review-section-tile">Payment Details
				</span>
				
				
	<span class="review-plan-title payment_heading">Plan Duration:
			
	<span class="alignright success--text pay-amount" style="color:#333333 !important">
		<div v-if="isLoading" class="loading-placeholder">
			<img :src="cdn + 'assets/images/loading.gif'" style="width:20px;" alt="Loading...">
		</div>
		<div v-else>
				 {{duration == 1 ? '28 Days' : duration+' Months'}}
		</div>
			</span>
			</span>
				
		

		
					<div v-if="paid !='N'">
					<span 
					class="review-plan-title payment_heading">Monthly Rental:&nbsp;<span style="color:#000; font-weight:600">(Incl of GST)</span>
						<span 
					class="alignright success--text pay-amount" style="color:#333333 !important">
					<div v-if="isLoading" class="loading-placeholder">
						<img :src="cdn + 'assets/images/loading.gif'" style="width:20px;" alt="Loading...">
					</div>
					<div v-else>
						<v-icon class="rupees-icon-pay">mdi-currency-inr</v-icon>{{pricepermonth}}
					</div>
						</span>
					</span>

                    
					<br>
					<span 
					class="review-plan-title payment_heading">Total Rental Payable:&nbsp;<span style="color:#000; font-weight:600">(Incl of GST)</span>
					<span 
						class="alignright success--text pay-amount" style="color:#333333 !important">
						<div v-if="isLoading" class="loading-placeholder">
							<img :src="cdn + 'assets/images/loading.gif'" style="width:20px;" alt="Loading...">
						</div>
						<div v-else>
						<v-icon class="rupees-icon-pay" >mdi-currency-inr</v-icon>{{amount}}
						</div>
					</span>
				</span>
				<br>

 				<div v-if="yash == 'true' " id="elemtId">
				<span class="review-plan-title" style="color: #442c8c !important">Discount ({{appliedCoupon}}):
		<span class="alignright success--text pay-amount" style="color:#d60d0d !important">
		<span style="color:#d60d0d !important">- ₹ </span>{{couponamt}}
		</span>
		</span>
		</div>

					</div>

				
				<div v-if="paid==='N'">
		
                     <span 
						class="review-plan-title payment_heading">Monthly Rental:&nbsp;<span style="color:#000; font-weight:600">(Incl of GST)</span>
						<span 
							class="alignright success--text pay-amount" style="color:#333333 !important">
							<div v-if="isLoading" class="loading-placeholder">
								<img :src="cdn + 'assets/images/loading.gif'" style="width:20px;" alt="Loading...">
							</div>
							<div v-else>
								<v-icon class="rupees-icon-pay" >mdi-currency-inr</v-icon>{{pricepermonth}}
							</div>
						</span>
					</span>
					<br>
					
					<span v-if="isrefferuser == 1">
					<span
					class="review-plan-title payment_heading">Referral Discount:&nbsp;
						<span class="alignright success--text pay-amount" style="color:#333333 !important">
						<div v-if="isLoading" class="loading-placeholder">
								<img :src="cdn + 'assets/images/loading.gif'" style="width:20px;" alt="Loading...">
						</div>
						<div v-else>
							-<v-icon class="rupees-icon-pay">mdi-currency-inr</v-icon>100
						</div>
						</span>
					</span>

					<br>
					</span>
					
					<span 
					class="review-plan-title payment_heading">Total Rental Payable:&nbsp;<span style="color:#000; font-weight:600">(Incl of GST)</span>
					<span 
						class="alignright success--text pay-amount" style="color:#333333 !important">
						<div v-if="isLoading" class="loading-placeholder">
							<img :src="cdn + 'assets/images/loading.gif'" style="width:20px;" alt="Loading...">
						</div>
						<div v-else>
							<v-icon class="rupees-icon-pay" >mdi-currency-inr</v-icon>{{amount}}
						</div>
					</span>
				</span>
				<br>
					<div v-if="yash == 'true' " id="elemtId">
					<span class="review-plan-title" style="color: #442c8c !important">Discount ({{appliedCoupon}}):
			<span class="alignright success--text pay-amount" style="color:#d60d0d !important">
			<span style="color:#d60d0d !important">- ₹ </span>{{couponamt}}
			</span>
			</span>
			</div>

    <div v-if="deposit === 'true'">
		
				
					<span class="review-plan-title payment_heading">Security Deposit:
		<span class="alignright success--text pay-amount" style="color:#333333 !important">
						<div v-if="isLoading" class="loading-placeholder">
							<img :src="cdn + 'assets/images/loading.gif'" style="width:20px;" alt="Loading...">
						</div>
						<div v-else>
							<v-icon class="rupees-icon-pay">mdi-currency-inr</v-icon>{{depositamount}}
						</div>
						</span>
					</span>
<div class="clear-both">
                <div class="security-padd">
                    <p class="alignleft plan-details-sub-section">Security Deposit is 100% Refundable</p>
                    <p class="alignright plan-details-sub-section know-more" id="know-more">Know More</p>
				</div>
</div>

</div>

<div id="howwork" class="modal">
	<div class="modal-content" style=" margin-top: 79px;">
			  <div class="modal-body">
				<span class='close1' style="margin-top: -11px;">					
					<img src="assets/images/ic_cancel.png"  alt="Livpuresmart mdi_close Icon" srcset="" style="height:30px;">
					</span>
<div class="modal-content-heading">
		<img id="securitydeposit" src="assets/images/noun_protected.png">
	<p class="modal-content-deposit">Security Deposit</p>
</div>
<div class="modal-list">
	<ul class="modal-list-items">
<li style="list-style:disc !important;">One time 100% refundable security deposit, for which receipt will be provided on payment.</li>

<li style="list-style:disc !important;">
Security deposit will be processed, within 7–10 working days. T&C Apply.
</li>
	</ul>
			</div>
			</div>
</div>
</div>   
		
			
</div>


			    
<hr class="clear-both hr-dashed">
			
	<span 
					class="review-plan-title payment_heading" style="font-weight:500;">Amount Payable:
				

				
					<span 
	class="alignright success--text pay-amount" style="color:#333333 !important">
					<div v-if="isLoading" class="loading-placeholder">
						<img :src="cdn + 'assets/images/loading.gif'" style="width:20px;" alt="Loading...">
					</div>
					<div v-else>
						<v-icon class="rupees-icon-pay">mdi-currency-inr</v-icon>{{mutatedTotal}}
					</div>
					</span>
					
					</span>

	</v-card-text>
				   </div>
	</div>


	<div class="review-payment-details" v-if="paid==='N' &&	 !(codavailable == '1' || (couponVisibilty === 'N' && isrefferuser == '1'))">
	<div v-if="yash != 'true'">
	<v-card-text 
class="flex flex-column review-plan-border bg-white" style="cursor: pointer;">
<span class="mb-2 apply-coupon" @click="Coupon()">Apply Coupon
<i class="alignright success--text arrow right" id="applycoupon"  @click="Coupon()" ></i>

</span>

</v-card-text>

</div>		

<div v-else-if="yash == 'true'">

<v-card-text 

class="flex flex-column review-plan-border bg-white">

<span class="mb-2 apply-coupon">{{appliedCoupon}}


<img src="assets/images/cancel.png"  class="alignright success--text " alt="Livpuresmart close Icon"  @click="canelCoupon()" id="applycoupon" srcset="" width="24px" height="24px">
</span>
<p class="couponoff">Flat ₹ {{couponamt}} off</p>

</v-card-text>



</div>
</div>
<div v-else-if = "paid === 'Y' && isretentioncouponapplicable == '1'">
<div v-if="yash != 'true'">
	<v-card-text 
class="flex flex-column review-plan-border bg-white" style="cursor: pointer;">
<span class="mb-2 apply-coupon" @click="Coupon()">Apply Coupon
<i class="alignright success--text arrow right" id="applycoupon"  @click="Coupon()" ></i>

</span>
</v-card-text>

</div>	
<div v-else-if="yash == 'true'">

<v-card-text 
class="flex flex-column review-plan-border bg-white">

<span class="mb-2 apply-coupon">{{appliedCoupon}}
<img src="assets/images/cancel.png"  class="alignright success--text " alt="Livpuresmart close Icon"  @click="canelCoupon()" id="applycoupon" srcset="" width="24px" height="24px">
</span>
<p class="couponoff">Flat ₹ {{couponamt}} off</p>

</v-card-text>
</div>	
</div>
<div id="couponofferpopup" class="modal">
<div class="modal-content" id="couponcontainer">

<span class="close" id="close">
				<img src="assets/images/mdi_close.svg" alt="Livpuresmart mdi_close Icon" @click="Cancelpopup()" srcset="">
								</span>
   
        <div class="fluid-container bg-color">
     

        <section class="text-center align-me-center">
            <h3 class="container-heading cuoffers" id="offers">Available Offers</h3>
        </section>
<section class="flex flex-column review-coupon bg-white">
<span 
  class="mb-2 review-coupon-title" style="font-family:'NeoSansPro-Bold';
    color: #333333;">Have a Couponcode?
		</span>
	<hr class="hr-line" />
		
<div class="flex flex-row" id="couponbox">
<input ref="coupon"  class="couponcode" name="couponcode" type="text" value="" id="couponcode" maxlength="201" v-on:keyup="keymonitor"  v-model="couponDet" 	placeholder="Enter CouponCode"/>
<v-btn class="coupon" id="couponcodeBtn"  style="color:white;background-color:#bdbdbd;margin:0px 5px;text-transform: none;" v-on:change="event =>keymonitor" @click="applyCoupon(couponDet)" >Apply</v-btn>
</div>

<div v-if="yash== 'true' " style="margin-top:09px;">

<img src="assets/images/circle.png" id = "successImg" alt="Livpuresmart mdi_close Icon" srcset="" style="width:13px; height:13px;" >

<span style="color:#49bb08 !important" id="sucesstext"> {{couponSuccessMsg}}  </span>
</div>

<div v-if="yash== 'false' " style="margin-top:09px;">

<img src="assets/images/ic_cancel_24_px.png"   id="errorImg" alt="Livpuresmart mdi_close Icon" srcset="" style="width:13px; height:13px;" >
<span style="color:#d60d0d !important" id="errortext"> {{couponErrorMsg}}  </span>
</div>


</section>

<div v-if = "isretentioncouponapplicable != '1'">
 <h3 class="coupon-text">Available coupons</h3>

 <div v-for="(coupon, i) in coupons" :key="i">

    
   <section class="flex flex-column review-coupon bg-white" id="availablecpns">
       <span> <span class="couponname">{{coupon.code}}
      
						 </span>
						 <v-btn class="couponapply" href="#offers" id="couponoffer" @click="selectCoupon(coupon.code)">Apply</v-btn></span>

             <p class="couponformonth">{{coupon.shortDescription}}</p>
						 <hr class="clear-both hr-dashed">

               <p class="coupondetails">{{coupon.description}}</p>
		</section>
		</div>
		</div>
</div>
	

</div>
    </div>
	<div id="sucesscoupon" class="modal">
	<div class="modal-content text-center align-me-center" id="couponsucesscontainer">
	
				
								<div class="circleimg text-center align-me-center" id="circleimage">
						<img src="assets/images/coupon_noun_offer.png" alt="Livpuresmart mdi_close Icon" width="54" height="54" srcset="">
						</div>
				<p class="sucessmsg" id="sucessmsg" value="">{{appliedCoupon}} Applied successfully</p>
		<div v-if="couponMsg">
				<p class="sucessmsg">{{couponMsg}}</p>
				</div>
				<div v-else>
									<p class="offeramt">₹ {{couponamt}} <span>off</span></p>
		</div>
						<p class="coupontxt">with this coupon</p>
									<div class="couponsucess">

		<v-btn class="successbtn" id="sucessbtn"  @click="closecoupon()">Okay</v-btn>
				</div>
</div>		
			</div>
		
			<div class="review-payment-details">
			<v-card-text 
	class="flex flex-column review-plan-border bg-white">
	<span 
					class="mb-2 review-section-tile">Installation Address
				</span>
	<div class="flex flex-row">
					<div 
						class="flex flex-column installation-address-wrapper">
						<span 
							class="review-address-text" style="font-weight:bold;">{{username}}
						</span>
						<span 
							class="review-address-text" style="color:gray;">{{address}},{{area}},{{city}}
						</span>
	<span 
							class="review-address-text" style="color:gray;">{{state}} - {{pincode}}
						</span>
	<v-btn href="address/edit?fromreview=${true}" 
				          class="edit-btn"
						  v-if="ekyc === 'N'">	Edit
						</v-btn>
	</div>
					</div>
  </v-card-text>
		</div>
		
			
	 <v-card-actions class="mt-4 align-me-center flex-column" style="background-color:#f2f2f2;">
			<div 
				class="align-me-center mb-2">
				<div 
					class="term-conditions-checkbox">
					<v-checkbox	
						v-model="checkbox"
						color="primary" 
						class="shrink ml-2 mx-0 px-0" 
						label="" 
						hide-details 
						dense/>
					<span 
				  class="term-conditions" id="terms">I hereby agree to Livpure Smart 
						<a 
							href="terms_and_conditions" 
							target="_blank" 
							class="term-conditions hand-cursor"><strong>Terms & Conditions</strong>
						</a>
					</span>
				</div>
			</div>

			<v-btn :disabled="!checkbox" class="cont-to-pay" v-if="paid==='N' &&  codavailable === '1'"  id="cont-to-pay" style="background: #f58220;
			padding: 10px 20px;margin-top: 10px;color: white;border-radius: 5px; width:100%;text-align: center;
			font-family: inherit;text-transform: none;">Continue to payment</v-btn>

			<div id="b_continue" class="modal" style="overflow: hidden !important;">
	<div class="modal-content" id="b_modalBottom" style=" margin-top: 79px;">
		<div class="modal-body">
			<span class='close2' style="margin-top: -11px;">
				<img src="assets/images/cross.png" alt="Livpuresmart mdi_close Icon" srcset="" style="height: 18px;
			position: absolute;top: -46px;right: 4px;cursor: pointer;">
			</span>
			<div class="modal-list">
				<h2 style="font-size: 22px;
					font-weight: bold;
					margin-bottom: 10px;">Choose Payment Mode</h2>
				<form>
					<div class="pay_flex pay_flex-new"
						style="display: flex;border: 1px solid #442c8c;border-radius: 5px;padding: 6px;">
						<input type="radio" id="b_online" value='prepaid'  :checked="paymentMethod === 'prepaid' " @change="onChangePaymentMethod($event)"  name="payment">
						<label for="b_online" style="margin-left: 12px;font-weight: bold;">Credit/Debit/ATM
							Card/UPI/Wallet <br>
							<span style="font-weight: 400;color: #ada8a8;font-size: 12px;">We don't save your details as per RBI guidelines </span>
						</label>
					</div>

					<div class="pay_flex"
						style="display: flex;margin-top: 16px;border: 1px solid #442c8c;border-radius: 5px;padding: 6px;">
						<input type="radio" id="b_COD" :checked="paymentMethod === 'cod' " value='cod' @change="onChangePaymentMethod($event)"  name="payment">
						<label for="b_COD" style="margin-left: 12px;font-weight: bold;">Cash on Delivery <br>
							<span style="font-weight: 400;color: #ada8a8;font-size: 12px;">Pay cash or online at the time of delivery</span>
						</label>
					</div>

					<v-btn  v-if="paymentMethod==='prepaid'" @click="showPayentGateway" 
					:disabled="!checkbox || !gotApiResp" class="b_pay_btn" style="background: #f58220;
					padding: 10px 20px;margin-top: 10px;color: white;border-radius: 5px; width:100%; text-transform: none;">Pay<v-icon class="pay-btn-review">mdi-currency-inr</v-icon>
					<span   v-if="paid==='N'" > {{mutatedTotal}} </span>
			         <span v-else>{{mutatedAmount}}</span></v-btn>

					<v-btn v-if="paymentMethod==='cod'" @click="showCodEkyc()" 
					:disabled="!checkbox || !gotApiResp"  class="b_pay_btn" style="background: #f58220;
					padding: 10px 20px;margin-top: 10px;color: white;border-radius: 5px; width:100%; text-transform: none;">Place Order</v-btn>
				</form>
			</div>
		</div>
	</div>
</div>

			<form 
				id="reviewForm" 
				method="POST">
				<input 
					type="hidden" 
					:name="'data'+planid" 
					:id="'data'+planid" 
					:value="orderdata"
				/>
				<input 
					type="hidden" 
					name="radio_button" 
					:value="duration" 
					checked
				/>
               
				<v-btn  v-if="paid==='Y' || codavailable != '1' "
					class="primary action-btn mt-6" 
					@click="showPayentGateway" 
				:disabled="!checkbox || !gotApiResp"
                 id="myButton"
						  style="background-color:#f58220 !important;">
						  <div v-if="isLoading" class="loading-placeholder">
						  <img :src="cdn + 'assets/images/payment.gif'" style="width:20px;" alt="Loading...">
					  </div>
					 	<div v-else>
							Pay<v-icon class="pay-btn-review">mdi-currency-inr</v-icon>
								<span   v-if="paid==='N'" > {{mutatedTotal}}</span>
								<span v-else>{{mutatedAmount}}</span>
						</div>

				</v-btn>
				
			
			</form>
		</v-card-actions>

		<div class="trusted-bar">
				<v-row 
					class="flex flex-row mx-3">
					<v-col 
						class="trusted-wrapper" 
						cols="6">
						<div 
							class="align-me-center">
							<img :src="cdn + 'assets/images/trusted.svg'" alt="Livpuresmart Trusted Icon">
							<span>Trusted by over 1Mn+ Customers</span>
						</div>
					</v-col>
					<v-col class="free-cancellation" cols="6">
						<div 
							class="align-me-center">
							<img :src="cdn + 'assets/images/cancellation.svg'" alt="Livpuresmart cancellation Icon">
							<span>7 Days free cancellation</span>
						</div>
					</v-col>
				</v-row>
			</div>
<div style="height:24px;">
</div>
		</div>
	</v-card>`
	,
	props: ["planid", "amount", "name", "duration", "address", "area", "city", "state", "depositamount", "pincode", "charges", "total", "orderdata", "action", "ekyc",
		"paid", "deposit", "issimpleligible", "redirectionurl", "repaymentredirectionurl", "pendingredirectionurl", "username", "couponflag", "couponamount",
		"datakey", "dataamount", "datacurrency", "dataname", "dataimage", "datadescription", "dataprefillname", "dataprefillemail", "dataprefillcontact",
		"datanotesrechargetype", "datanotesinstallationamount", "datanotesconnectivity", "datanotescontact", "datanotesemail", "datanotesname", "permonthamount",
		"datanotestransactionid", "datanotesbusiness", "datanotesproducttype", "datanotesplanid", "datanotesuserid", "datanotespaymentfrom", "datanotesbusinesstype",
		"datanotesserialno", "datanotesdepositamount", "dataorderid", "datanotesleadid", "datathemecolor", "pageurl", "transaction_id", "dateformat", "codavailable", "pricepermonth",
		"isrefferuser", "isretentioncouponapplicable", "userid"
	],
	data() {
		return {
			isLoading: true,
			cdn: app.cdn,
			couponVisibilty: app.couponVisibilty,
			coupons: app.coupons,
			checkbox: true,
			gotApiResp: true,
			yash: "",
			couponamt: "",
			couponDet: "",
			couponErrorMsg: "",
			couponSuccessMsg: "",
			mutatedAmount: this.amount,
			mutatedTotal: this.total,
			mutatedDataAmount: this.dataamount,
			mutatedOrderId: this.dataorderid,
			appliedCoupon: "",
			appliedCouponName: "",
			couponShortDesc: "",
			couponMsg: "",
			paymentMethod: 'prepaid'
		}
	},
	computed: {
		isDisabled: function () {
			return !this.couponDet;
		},
		isUnlimitedPlan() {
			return this.name.includes('-Unlimited');
		}
	},
	methods: {

		showPayentGateway() {
			console.log("this.couponamt: ", this.couponamt);
			userType = 'guest';
			if (this.userid != '') userType = 'signin';
			if (this.paid === 'N') {
				totalamount = this.total
			} else {
				totalamount = this.localAmount
			}

			if (this.couponamt != '') {
				totalamount = totalamount - parseInt(this.couponamt);
			}

			if (this.paid === 'N') {
				purchase_type = 'RO Subscription Started'
			} else {
				purchase_type = 'RO Subscription Recharged'
			}
			dataLayer.push({
				ecommerce: null
			});  // Clear the previous ecommerce object.
			dataLayer.push({
				'event': 'review_pay_click',
				'page_url': this.pageurl,
				'ecommerce': {
					'transaction_id': this.transaction_id,
					'affiliation': 'Livpure Smart Online Store',
					'value': totalamount,
					'tax': '0.00',
					'shipping': '0.00',
					'currency': 'INR',
					'coupon': this.couponamt,
					'payment_type': 'Credit Card / QR Code / Wallet',
					'payment_type_detail': '',
					'emi_value': this.amount,
					'emi_duration': this.duration,
					'purchase_type': purchase_type,
					'items': [{
						'item_name': 'Live Pure Smart - Bolt/Envy/premium',
						'item_id': this.planid + '_' + this.duration,
						'price': this.amount,
						'item_brand': 'Livpure Smart RO',
						'item_category': 'RO Subscription',
						'item_variant': this.name,
						'quantity': 1
					}]
				}
			});
			dataLayer.push({
				event: "set_user_id",
				user_id: this.userid,
				event_fired: "review_pay_click",
				user_type: userType
			});
			if (typeof analytics !== "undefined") {
				analytics.track(this.paid === 'Y' ? 'Clicked Recharge' : 'Clicked Payment', {
					payment_method: 'Credit Card / QR Code / Wallet',
					payment_type: 'Monthly'
				});
			}

			var options = {
				"key": this.datakey,
				"order_id": this.mutatedOrderId,
				"amount": this.mutatedDataAmount,
				"currency": this.datacurrency,
				"name": this.dataprefillname,
				"image": this.dataimage,
				"description": this.datadescription,
				"prefill": {
					"name": this.dataprefillname,
					"email": this.dataprefillemail,
					"contact": this.dataprefillcontact,
				},
				config: {
					display: {
						blocks: {
							banks: {
								name: 'Most Popular Payment Method',
								instruments: [
									{
										method: 'upi'
									},
									{
										method: 'netbanking'
									},
									{
										method: 'wallet'
									},
									{
										method: 'card'
									}
								],
							},
						},
						sequence: ['block.banks'],
						preferences: {
							show_default_blocks: true,
						},
					},
				},
				"notes": {
					"rechargeType": this.datanotesrechargetype,
					"installation_amount": this.datanotesinstallationamount,
					"Connectivity": this.datanotesconnectivity,
					"contact": this.datanotescontact,
					// "name": this.datanotesname,
					"email": this.datanotesemail,
					// "transaction_id": this.datanotestransactionid,
					"business": this.datanotesbusiness,
					"productType": this.datanotesproducttype,
					"plan_id": this.datanotesplanid,
					"user_id": this.datanotesuserid,
					"payment_from": this.datanotespaymentfrom,
					"business_type": this.datanotesbusinesstype + '|' + this.datanotesleadid,
					"serial_no": this.datanotesserialno,
					"deposit_amount": this.datanotesdepositamount,
					"coupon_amount": this.couponamt,
					"coupon_name": this.appliedCoupon



				},
				"theme": {
					"color": this.datathemecolor
				},
				"handler": function (response) {
					window.location.href = `${window.baseUrl}checkout/processPayment?
					rPayId=${btoa(response.razorpay_payment_id)}
					&rPaySign=${btoa(response.razorpay_signature)}
					&rPayOId=${btoa(response.razorpay_order_id)}
        	&userId=${btoa(options.notes.user_id)}
	&planId=${btoa(options.notes.plan_id)}`;
				}

			};

			//console.log(options)
			try {
				var options_c = options;
				options_c['device'] = 'LivpureSmart Website';
				fetch(`${window.baseUrl}review/createLogs`, {
					method: 'POST', // or 'PUT'
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify(options_c),
				})
					.then(response => response.json())
					.then(data => {
						console.log('Success:', data);
					})
					.catch((error) => {
						console.error('Error:', error);
					});
			}
			catch (err) {
				console.log(err);
			}
			var rzp1 = new Razorpay(options).open();

			$('.razorpay-payment-button').trigger('click');
		},

		initateSimplCharge() {
			window.location.href = `${window.baseUrl}checkout/chargeSimplPayment`;
		},
		callLinkPayLater() {
			window.location.href = this.redirectionurl;
		},
		pendingDues() {
			window.location.href = this.pendingredirectionurl;
		},
		payPendingBills() {
			window.location.href = this.repaymentredirectionurl;
		},
		async keymonitor() {
			couponDet = document.getElementById('couponcode').value;
			if (couponDet.length > 0) {

				document.getElementById("couponcodeBtn").style.backgroundColor = "#442c8c";
				document.getElementById("couponcode").style.backgroundColor = "#f0ebfe";
			}
			else {
				this.couponSuccessMsg = ""
				this.couponErrorMsg = "";
				this.mutatedTotal = this.total;
				this.mutatedAmount = this.amount;
				this.mutatedDataAmount = this.mutatedAmount;
				const _razorpay = await getData(`${window.baseUrl}Review/reCallRazorpay`, 'post', { 'discountedAmount': this.mutatedTotal })
				this.mutatedOrderId = _razorpay;
				document.getElementById("couponcodeBtn").style.backgroundColor = "#bdbdbd";
				document.getElementById("couponcode").style.backgroundColor = "#f0ebfe";
				if (this.yash == "true") {

					document.getElementById('elemtId').style.display = 'none';
					document.getElementById('successImg').style.display = 'none';
				}
				if (this.yash == "false") {

				}

			}

		},
		async selectCoupon(couponcode) {
			$("#couponcode").val(couponcode);

			couponDet = document.getElementById('couponcode').value;

			if (couponDet.length > 0) {
				document.getElementById("couponcodeBtn").style.backgroundColor = "#442c8c";
				document.getElementById("couponcode").style.backgroundColor = "#f0ebfe";
			}
		},
		async applyCoupon(couponDet) {
			couponDet = document.getElementById('couponcode').value;
			const data = await getData(`${window.baseUrl}Review/reteriveCouponDetails`, 'post', { 'couponCode': couponDet, 'city': this.city, 'createdFor': 'WEB' })
			let response = JSON.parse(data);
			console.log(response)
			if (response.status == 'true') {
				this.yash = "true";
				this.appliedCoupon = couponDet;
				this.couponamt = response.data.couponnDetails[0].amount;
				this.couponShortDesc = response.data.couponnDetails[0].shortDescription;
				this.couponMsg = response.data.couponnDetails[0].message;

				if (response.message.includes("Add One Rupee Recharge")) {
					this.mutatedTotal = this.total - (this.amount - 1);
					this.mutatedAmount = this.amount - response.data.couponnDetails[0].amount;
				} else {
					this.mutatedTotal = this.total - response.data.couponnDetails[0].amount;
					this.mutatedAmount = this.amount - response.data.couponnDetails[0].amount;
				}

				let localAmount = this.mutatedAmount;
				this.mutatedDataAmount = localAmount.toString();
				const razorpay = await getData(`${window.baseUrl}Review/reCallRazorpay`, 'post', { 'discountedAmount': this.mutatedTotal, "appCouponamt": this.couponamt, 'appCouponCode': couponDet })
				console.log(razorpay);
				this.mutatedOrderId = razorpay;
				this.couponSuccessMsg = "Couponcode applied successfully."
				var successImg = document.getElementById('successImg').style.display = 'inline';
				document.getElementById('sucesstext').style.display = 'inline-block';
				document.getElementById('elemtId').style.display = 'inline';
				document.getElementById("sucesscoupon").style.display = "block";
				document.getElementById("couponofferpopup").style.display = "none";

			}
			else {
				console.log(response.message);
				if (response.message.includes("Coupon Already Used")) {
					this.couponErrorMsg = `${couponDet} Coupon Already Applied`
				}
				else {
					this.couponErrorMsg = "Please enter valid a Couponcode"
				}

				this.yash = "false";
				this.mutatedTotal = this.total;
				this.mutatedAmount = this.amount;
				let _localAmount = this.mutatedAmount;
				this.mutatedDataAmount = _localAmount.toString();
				const _razorpay = await getData(`${window.baseUrl}Review/reCallRazorpay`, 'post', { 'discountedAmount': this.mutatedTotal })
				this.mutatedOrderId = _razorpay;
				var errorImg = document.getElementById('errorImg').style.display = 'inline';
				document.getElementById('errortext').style.display = 'inline-block';
				if (this.yash == "true") {
					document.getElementById('elemtId').style.display = 'none';
				}



			}
		},
		async closecoupon() {

			document.getElementById("sucesscoupon").style.display = "none";

		},
		async canelCoupon() {

			couponDet = document.getElementById('couponcode').value;
			const data = await getData(`${window.baseUrl}Review/reteriveCouponDetails`, 'post', { 'couponCode': couponDet, 'city': this.city, 'createdFor': 'WEB' })
			let response = JSON.parse(data);
			this.gotApiResp = false;
			this.yash = "false";
			this.mutatedTotal = this.total;
			this.mutatedAmount = this.amount;
			let _localAmount = this.mutatedAmount;
			this.mutatedDataAmount = _localAmount.toString();
			const _razorpay = await getData(`${window.baseUrl}Review/reCallRazorpay`, 'post', { 'discountedAmount': this.mutatedTotal })
			this.mutatedOrderId = _razorpay;
			if (this.mutatedOrderId) {
				this.gotApiResp = true
			}
			if (document.getElementById('errorImg')) {
				var errorImg = document.getElementById('errorImg').style.display = 'none';
			}
			if (this.yash == "true") {
				document.getElementById('elemtId').style.display = 'none';
			}
			this.couponamt = '';
		},
		async Coupon() {
			document.getElementById("couponofferpopup").style.display = "block";
			document.getElementById("couponofferpopup").style.overflow = "auto";
			document.getElementById('couponcode').value = '';
			if (document.getElementById('errorImg')) {
				var errorImg = document.getElementById('errorImg').style.display = 'none';
				document.getElementById('errortext').style.display = 'none';
			}
		},

		async Cancelpopup() {
			document.getElementById("couponofferpopup").style.display = "none";
		},

		async onChangePaymentMethod(event) {

			this.paymentMethod = event.target.value;
		},

		async showCodEkyc() {

			var obj = {
				"rechargeType": this.datanotesrechargetype,
				"installation_amount": this.datanotesinstallationamount,
				"Connectivity": this.datanotesconnectivity,
				"contact": this.datanotescontact,
				"email": this.datanotesemail,
				"business": this.datanotesbusiness,
				"productType": this.datanotesproducttype,
				"plan_id": this.datanotesplanid,
				"user_id": this.datanotesuserid,
				"payment_from": this.datanotespaymentfrom,
				"business_type": this.datanotesbusinesstype + '|' + this.datanotesleadid,
				"serial_no": this.datanotesserialno,
				"deposit_amount": this.datanotesdepositamount,
				"coupon_amount": this.couponamt,
				"coupon_name": this.appliedCoupon

			}

			window.location.href = `${window.baseUrl}checkout/checkoutCod?userId=${btoa(obj.user_id)}`

		},
		loadJSON(callback) {

			var xobj = new XMLHttpRequest();
			xobj.overrideMimeType("application/json");
			xobj.open('GET', app.url, true)
			xobj.onreadystatechange = function () {
				if (xobj.readyState == 4 && xobj.status == "200") {
					callback(xobj.responseText);
				}
			};
			xobj.send(null);
		},
		init() {
			let that = this
			that.loadJSON(function (response) {
				var data = JSON.parse(response);
				that.isLoading = false;
				that.name = data.selectedPlan[0].planName;
				that.amount = data.amount;
				that.total = data.installationTotalAmount;
				that.planName = data.selectedPlan[0].planName;
				that.planTotalAmount = data.selectedPlan[0].planTotalAmount;
				that.duration = data.selectedPlan[0].duration;
				that.installationCharges = data.installationCharges;
				that.depositamount = data.deposit_amount;
				that.mutatedTotal = data.installationTotalAmount;
				that.mutatedAmount = data.installationTotalAmount;
				that.pricepermonth = data.pricePerMonth;
				that.permonthamount = data.selectedPlan[0].permonthamount;
			});
		}
	},
	mounted() {
		this.init()
	},
	watch: {}
});

