<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Footers extends Component
{
    public function render()
    {
        return view('livewire.footers');
    }
}
