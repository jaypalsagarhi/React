<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Loaders extends Component
{
    public function render()
    {
        return view('livewire.loaders');
    }
}
