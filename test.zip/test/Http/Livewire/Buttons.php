<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Buttons extends Component
{
    public function render()
    {
        return view('livewire.buttons');
    }
}
