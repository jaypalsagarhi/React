<?php

namespace App\Http\Livewire;

use Livewire\Component;

class FilemanagerDetails extends Component
{
    public function render()
    {
        return view('livewire.filemanager-details');
    }
}
