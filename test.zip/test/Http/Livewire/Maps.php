<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Maps extends Component
{
    public function render()
    {
        return view('livewire.maps');
    }
}
