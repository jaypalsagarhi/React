<?php

namespace App\Http\Livewire;

use Livewire\Component;

class EmailCompose extends Component
{
    public function render()
    {
        return view('livewire.email-compose');
    }
}
