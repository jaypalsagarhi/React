<?php

namespace App\Http\Livewire;

use Livewire\Component;

class FormElements extends Component
{
    public function render()
    {
        return view('livewire.form-elements');
    }
}
