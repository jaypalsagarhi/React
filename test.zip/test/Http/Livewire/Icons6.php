<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Icons6 extends Component
{
    public function render()
    {
        return view('livewire.icons6');
    }
}
