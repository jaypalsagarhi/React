<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Icons5 extends Component
{
    public function render()
    {
        return view('livewire.icons5');
    }
}
