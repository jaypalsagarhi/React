<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

class UsersController extends Controller
{
    public function changePassword(Request $request){
        if($request){
            echo "<pre>"; print_r($request);die;
            $this->validate($request, [ 
                'oldpassword' => 'required',
                'newpassword' => 'required',
            ]);
    
            $hashedPassword = Auth::user()->password;
            if (\Hash::check($request->oldpassword , $hashedPassword)) {
                if (\Hash::check($request->newpassword , $hashedPassword)) {
    
                    $users = admin::find(Auth::user()->id);
                    $users->password = bcrypt($request->newpassword);
                    $users->save();
                    session()->flash('message','password updated successfully');
                    return redirect()->back();
                }
                else{
                    session()->flash('message','new password can not be the old password!');
                    return redirect()->back();
                } 
            }
            else{
                session()->flash('message','old password doesnt matched');
                return redirect()->back();
            }
        }else{
            return view('livewire.change-password');
        }
    }
}
