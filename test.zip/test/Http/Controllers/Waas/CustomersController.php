<?php
namespace App\Http\Controllers\Waas;

use App\Http\Controllers\Controller;
use App\Models\WaasCustomerDetail;
use App\Models\WaasRechargeDetails;
use App\Models\WaasReasonMaster;
use App\Models\WaasCancellationRequest;
use App\Models\WaasSubReasonMaster;
use App\Models\WaasTimeSlot;

use Illuminate\Http\Request;
use App\Traits\ApiTrait;
use Illuminate\Support\Facades\Http;
// use DataTables;

class CustomersController extends Controller
{
    use ApiTrait;

    function index(Request $request){
        
        $perPage = 10; 
        $search = $request->input('search');

        $query = WaasCustomerDetail::query();

        $search = [];
        if ($request->has('field_type')) {
            $field_type = $request->input('field_type');
            $field_value = $request->input('field_value');
            if($field_type == "mobile_no"){
                $this->GetWAASCustomer($field_value);
                $this->Waascustomerdetails($field_value);
                $this->WaasekyccustomerStatus($field_value);
                $this->WaasekyccustomerpaymentStatus($field_value);
                //$this->eKYC($field_value);
            }

            $search['field_type'] = $field_type;
            $search['field_value'] = $field_value;
            $query->where($field_type, 'LIKE', '%' . $field_value . '%');
            if ($request->has('status')) {
                $status = $request->input('status');
                $search['status'] = $status;
                $query->Where('status', 'LIKE', '%' . $status . '%');
            }
        }
        //die;
        $data = $query->select('id','full_name','lot_user_id', 'mobile_no','alternate_mobile_no', 'email_id','hub_name','kyc_date','order_type','delivery_type','status','ekyc_message')->get();
    //    echo '<pre>';print_r($data);
        
        return view('waas.customers', ['data' => $data, 'search' => $search]);       
    }

    function getCustomerDetails(Request $request){
        try{
            if ($request->ajax()) {
                $id = $request->input('id');
                $IotId = $request->input('IotId');
                $mobileNo = $request->input('mobileNo');
                
                $this->eKYC($mobileNo); // Call ekyc API
                $this->RefreshMachine($IotId); // Refresh Machine

                $record = WaasCustomerDetail::find($id);
                if($record){
                    $data = array(
                        'success' => true,
                        'data' => $record
                    );
                }else{
                    $data = array(
                        'success' => false,
                        'message' => 'Record not found for current request'
                    );
                }
            } else {
                $data = array(
                    'success' => false,
                    'message' => 'Unauthorized Access'
                );
            }
        }catch(\Exception $ex){
            $data = array(
                'success' => false,
                'message' => $ex->getMessage()
            );
        }
        return response()->json($data);
    }

    function getCancelRequestData(Request $request){
        try{
            if ($request->ajax()) {
                $id = $request->input('id');
                $record = WaasCustomerDetail::find($id);
                $cancellRequest = WaasCancellationRequest::where('is_active','Y')->get();
                $timeSlot = WaasTimeSlot::where('is_active', 1)->get();
                if($record){
                    $data = array(
                        'success' => true,
                        'data' => $record,
                        'cancellRequest' => $cancellRequest,
                        'timeSlot' => $timeSlot
                    );
                }else{
                    $data = array(
                        'success' => false,
                        'message' => 'Record not found for current request'
                    );
                }
            } else {
                $data = array(
                    'success' => false,
                    'message' => 'Unauthorized Access'
                );
            }
        }catch(\Exception $ex){
            $data = array(
                'success' => false,
                'message' => $ex->getMessage()
            );
        }
        return response()->json($data);
    }

    function cancelRequest(Request $request){
        try{
            if ($request->ajax()) {
                echo "<pre>"; print_r($_POST);
                // $record = array(
                //     'userId' => $request->input('userId'),
                //     'phoneNo' => $request->input('phoneNo'),
                //     'serialNo' => $request->input('serialNo'),
                //     'reason' => $request->input('reason'),
                //     'appointmentDate' => $request->input('appointmentDate'),
                //     'timeslot' => $request->input('timeslot')
                // );
            } else {
                $data = array(
                    'success' => false,
                    'message' => 'Unauthorized Access'
                );
            }
        }catch(\Exception $ex){
            $data = array(
                'success' => false,
                'message' => $ex->getMessage()
            );
        }
        return response()->json($data);
    }

    function wassDismantle(Request $request){
        try{
            if ($request->ajax()) {
                $record = array(
                    'userId' => $request->input('userId'),
                    'phoneNo' => $request->input('phoneNo'),
                    'serialNo' => $request->input('serialNo'),
                    'reason' => $request->input('reason'),
                    'appointmentDate' => $request->input('appointmentDate'),
                    'timeslot' => $request->input('timeslot')
                );
                // $this->dismantleRequest($record);

                // $record = WaasCustomerDetail::find($id);
                // $cancellRequest = WaasCancellationRequest::all();
                // if($record){
                //     $data = array(
                //         'success' => true,
                //         'data' => $record,
                //         'cancellRequest' => $cancellRequest
                //     );
                // }else{
                //     $data = array(
                //         'success' => false,
                //         'message' => 'Record not found for current request'
                //     );
                // }
            } else {
                $data = array(
                    'success' => false,
                    'message' => 'Unauthorized Access'
                );
            }
        }catch(\Exception $ex){
            $data = array(
                'success' => false,
                'message' => $ex->getMessage()
            );
        }
        return response()->json($data);
    }

    function customersData(Request $request){
        $draw = $request->input('draw');
        $start = $request->input('start');
        $length = $request->input('length');
        $search = $request->input('search.value');

        $query = WaasCustomerDetail::query();

        if (!empty($search)) {
            $query->where(function ($q) use ($search) {
                $q->where('full_name', 'LIKE', '%' . $search . '%');
            });
        }

        $totalRecords = $query->count();
        $recordsFiltered = $query->count();
        $data = $query->skip($start)->take($length)->get();

        return response()->json([
            'draw' => $draw,
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $recordsFiltered,
            'data' => $data,
        ]);
    }

    function getRequestReason(Request $request){
        try{
            if ($request->ajax()) {
                $id = $request->input('id');
                $response_type = $request->input('response_type');
                $response = '';
                if($response_type == 'sub_reason'){
                    $response = WaasSubReasonMaster::where(['reason_id' => $id, 'is_active' => 'Y'])->get();
                }else if($response_type == 'reason'){
                    $response = WaasReasonMaster::where(['request_id' => $id, 'is_active' => 1])->get();
                }else{
                    $data = array(
                        'success' => false,
                        'message' => 'Unauthorized Request'
                    );
                }

                if(isset($response) && $response != ''){
                    $data = array(
                        'success' => true,
                        'data' => $response
                    );
                }
            } else {
                $data = array(
                    'success' => false,
                    'message' => 'Unauthorized Access'
                );
            }
        }catch(\Exception $ex){
            $data = array(
                'success' => false,
                'message' => $ex->getMessage()
            );
        }
        return response()->json($data);
    }
}
