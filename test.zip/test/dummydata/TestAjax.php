<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Ajax extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('RegisterModel');
		$this->load->helper(array('form', 'url', 'datalayer_helper'));
		$this->load->model('Userlead');
		$this->redis = new \CI_Predis\Redis(['serverName' => SERVERNAME]);

	}


	public function register()
	{
		if ($this->input->method() === 'post' && $this->security->csrf_verify()) {
			// CSRF token is valid
			unset($_SESSION['formdata']);
			$removeKeys = array('nb-transaction-token', 'nb-confirmation-token', 'nb-result', 'pageName', 'cityName', 'name', 'datasource', 'terms','securitytoken');
			$via = strip_tags($this->input->post('pageName'));
			$_POST["username"] = trim(strip_tags($this->input->post('name')));
			$_POST = array_diff_key($_POST, array_flip($removeKeys));
			$_POST['referralCode'] = strtoupper(strip_tags($this->input->post('referralCode')));

			$_POST['password'] = DEFAULTPASSWORD;

			if ($_SESSION['nlp'] == true || $_SESSION['zinger'] == true || $_SESSION['dealer'] == true) {
				$_POST['source'] = 'Water jars';
			}

			$result = json_decode(CallAPI('POST', local_ip_url . api_version . '/register', $_POST));

			if ($result->statusCode == 200) {
				$this->RegisterModel->register($_POST);
				$source = strip_tags($this->input->post('source'));

				if (strip_tags($this->input->post('source')) == 'Other' && strip_tags($this->input->post('datasource')) != "" ) {
					$source = strip_tags($this->input->post('datasource'));
				}

				$refferalCode = strip_tags($this->input->post('referralCode'));
				$data = array(
					'token' => $result->data->token,
					'userId' => $result->data->userId,
					'userName' => $result->data->name,
					'email' => $result->data->email,
					'enteredReferralCode' => $refferalCode,
					// referral Code used while sign up - for analytics
					'city' => strip_tags($this->input->post('city')),
					// referral Code used while sign up - for analytics
					'phone' => $result->data->mobile,
					'water_source' => $source,
					'referralCode' => $refferalCode,
					'phoneVerification' => $result->data->phoneVerification

				);

				$_SESSION['login_data'] = $data;


				$_SESSION['token'] = $result->data->token;
				$_SESSION['status'] = 'new-2022';
				$_SESSION['registersucess'] = 'true';

				// $_SESSION['login_data']['paymentlead'] = true;

				$_SESSION['login_data']['water_source'] = $this->input->post('source');
				if ($_SESSION['login_data']['water_source'] == 'Other') {
					$_SESSION['login_data']['water_source'] = $this->input->post('datasource');
				}
				// signUpPush();
				$_SESSION['gta4_signup_event'] = "signup";
				$_SESSION['deposit'] = 'true'; // added to get deposit amount changes for all customers

				//added to capture experience for type A customer by Yashwanth on 29/04/2020
				$userId = (int) ($_SESSION['login_data']['userId']);
				$reminder = $userId % 10;

				$_SESSION['login_data']['rd_su'] = 'Y'; // to check page redirected from login su - signed up
				$_SESSION['login_data']['page_source'] = $via;
				$_SESSION['new_customer'] = "Y";

				// default false
				$_SESSION['login_data']['Ekyc'] = 'N';
				$_SESSION['login_data']['kycCompleted'] = false;
				$_SESSION['login_data']['paymentCompleted'] = false;
				$_SESSION['login_data']['paid'] = false;

				$this->setUserDetails();

				// to insert and update the lead details to the api
				if ($_SESSION['nlppage'] == true) {
					$source_of_Enquiry = 'ro_nlp';
				} else if ($_SESSION['purifier'] == true) {
					$source_of_Enquiry = 'ro-Purifier';
				} else if ($_SESSION['unlimited'] == true) {
					$source_of_Enquiry = 'ro-unlimited';
				} else if ($_SESSION['zinger'] == true) {
					$source_of_Enquiry = 'zinger';
				} else if ($_SESSION['dealer'] == true) {
					$source_of_Enquiry = 'dealer_page';
				} else {
					$source_of_Enquiry = 'website';
				}
				$phone = $result->data->mobile;
				$updatelead = array(
					'user_id' => $userId,
					'username' => $_SESSION['login_data']['userName'],
					'phone' => $result->data->mobile,
					'alt_phone' => " ",
					'referral_code' => $refferalCode,
					'referral_phone' => $_SESSION['realRefPhone'],
					'referral_name' => $_SESSION['realRefName'],
					'email' => $_SESSION['login_data']['email'],
					'city' => $this->input->post('city'),
					'district' => '',
					'state' => '',
					'pincode' => '',
					'address' => '',
					'source_of_enquiry' => $source_of_Enquiry,
					'utm_source' => $_SESSION['utm_source'],
					'utm_medium' => $_SESSION['utm_medium'],
					'current_source_of_water' => $_SESSION['login_data']['water_source'],
					'current_plan_selected' => '',
					'lead_created_page' => "",
					'current_lead_page' => "Registration_page",
					'business_id' => "1"
				);
				//end
				$this->Userlead->addLead($userId);
				$this->Userlead->updateLeadData($updatelead, $phone);
				$result->csrf_token = $this->security->get_csrf_hash();
				// return $result;
				$response = json_encode($result);
				echo $response;
				exit;


			} else {

				// Call LMS API on failed register
				$updatelead = array(
					'username' => $this->input->post('name'),
					'phone' => $this->input->post('phone'),
					'email' => $this->input->post('email'),
					'city' => $this->input->post('city'),
					'source_of_enquiry' => 'Registration_page',
					'current_source_of_water' => $this->input->post('source'),
					'current_lead_page' => "Registration_page",
					'business_id' => "1"
				);
				$this->Userlead->updateLeadData($updatelead, $this->input->post('phone'));
				// Call LMS API
				$result->csrf_token = $this->security->get_csrf_hash();
				$response = json_encode($result);
				echo $response;
				exit;


			}
		} else {
			echo 'Invalid CSRF token or form submission method.';
		}
	}

	public function sendLoginotp()
	{
		if (!$this->input->is_ajax_request()) {
            exit ('No direct script access allowed.');
		}

		if ($this->input->post())
		{
			//start only use loginotp
			if(($_REQUEST['resend_otp'] != 'login') && $_SESSION['phone_not_register'] == trim($_REQUEST['phone'])){
				echo $response = json_encode(["status"=>1, "statusCode"=>400, "message"=>"User not found!","csrf_token"=>$this->security->get_csrf_hash()]);
				die;
			}
			//end only use loginotp
			if ($this->checkRateLimit(trim($_REQUEST['phone'])))
			{
				if ( ($_REQUEST['phone']) !== "" && ($_REQUEST['phone']) !== null) {
					$phone = $_REQUEST['phone'];
				}
				if(isset($_SESSION['login_data']['phone']) && !empty($_SESSION['login_data']['phone'])) {
					$phone = $_SESSION['login_data']['phone'];
				}
				
				$url = local_ip_url . api_version . '/sendloginotp';
				$data = array("phone" => $phone);
				$loginresponse = json_decode(CallAPI('POST', $url, $data));
				$loginresponse->csrf_token = $this->security->get_csrf_hash();
				//start only use loginotp
				if($loginresponse->statusCode == 400 ){
					$_SESSION['phone_not_register'] = trim($_REQUEST['phone']);
				}
				//end only use loginotp
				$response = json_encode($loginresponse);
				echo $response;
			}else{
				$response = json_encode(["status"=>1, "statusCode"=>201, "message"=>"You have crossed the limit to send your OTP, please wait for 5 minutes.","csrf_token"=>$this->security->get_csrf_hash()]);
				echo $response;
			}
		}else{
			$response = json_encode(["status"=>1, "statusCode"=>201, "message"=>"Invalid CSRF token or form submission method.","csrf_token"=>$this->security->regenerate_csrf_hash()]);
			echo $response;
		}
	}

	// Function to check rate limit
	private function checkRateLimit($phone_number) {
		$max_attempts = OTP_MAX_ATTEMPTS;
		$time_frame = OTP_TIME_FRAME;
		$block_time_frame = OTP_BLOCK_TIME_FRAME;
		$session_key = session_id() . $phone_number;
		$current_time = time();
	
		if ($this->session->has_userdata($session_key)) {
			$attempts = $this->session->userdata($session_key);
			$checkCountTime = $current_time - $attempts['timestamp'];
			if ($attempts['count'] < $max_attempts && $checkCountTime <= $time_frame) {
				$attempts['count']++;
				$this->session->set_userdata($session_key, ['count' => $attempts['count'], 'timestamp' => time()]);
				return true;
			} else if ($attempts['count'] < $max_attempts && $time_frame <= $checkCountTime) {
				$attempts['count']++;
				$this->session->set_userdata($session_key, ['count' => $attempts['count'], 'timestamp' => time()]);
				return true;
			} else if ( $checkCountTime >= $block_time_frame) {
				$this->session->unset_userdata($session_key);
				$this->session->sess_regenerate();
				$_SESSION['after_block_time_frame_set'] = 2;
				$this->session->set_userdata($session_key, ['count' => $_SESSION['after_block_time_frame_set'], 'timestamp' => time()]);
				return true;
			}else {
				// Check if it's time to unblock the number
				if ($block_time_frame <= $checkCountTime) {
					$this->session->unset_userdata($session_key);
					$this->session->sess_regenerate();
				}
				return false;
			}
		} else {
			$count = !empty($_SESSION['after_block_time_frame_set']) ? $_SESSION['after_block_time_frame_set'] : 1;
			$this->session->set_userdata($session_key, array('count' => $count, 'timestamp' => time()));
			return true;
		}
	}

	private function setUserDetails()
	{
		$_POST['userId'] = $_SESSION['login_data']['userId'];
		$url = local_ip_url . api_version . '/getReferralShortLink';
		$refUrl = json_decode(CallAPI('POST', $url, $_POST));
		if (!empty($refUrl) && $refUrl->sucess == true) {
			$_SESSION['refshoorturl'] = $refUrl->data->refShortLink;
		} else {
			$_SESSION['refshoorturl'] = '';
		}

		$Data['email'] = $_SESSION['login_data']['email'];
		$url = local_ip_url . 'getUserDetailsWeb';
		$userResult = json_decode(CallAPI('POST', $url, $Data));
		$userDetails = $userResult->userDetails[0];
		$_SESSION['login_data']['registerDate'] = $userDetails->registerDate;
		$_SESSION['login_data']['userName'] = $userDetails->username;
		$_SESSION['emailVerification'] = $userDetails->emailVerification;
		$_SESSION['phoneVerification'] = $userDetails->phoneVerification;

		if (isset($userDetails->ro_recharge[0]) && is_array($userDetails->ro_recharge[0]) && count($userDetails->ro_recharge[0]) >= 1) {
			$_SESSION['DeviceRechargeStatus'] = $userDetails->ro_recharge[0]->DeviceRechargeStatus;
		} else {
			$_SESSION['DeviceRechargeStatus'] = '';
		}
		if (isset($userDetails->lastName)) {
			$_SESSION['login_data']['fullName'] = $_SESSION['login_data']['userName'] . ' ' . $userDetails->lastName;
		} else {
			$_SESSION['login_data']['fullName'] = $_SESSION['login_data']['userName'];
		}

		$fullName = explode(" ", $_SESSION['login_data']['fullName'], 2);

		$_SESSION['login_data']['firstName'] = $fullName[0];
		$_SESSION['login_data']['lastName'] = count($fullName) == 1 ? "" : $fullName[1];

		$_SESSION['login_data']['phone'] = (isset($userDetails->phone) && !empty($userDetails->phone)) ? $userDetails->phone : $_SESSION['login_data']['phone'];
		$_SESSION['login_data']['productType'] = $userDetails->productType;
		$_SESSION['login_data']['userreferralCode'] = $userDetails->referralCode;
		$_SESSION['login_data']['referralCode'] = $userDetails->referredBy->referralCode;

		$_SESSION['login_data']['planName'] = isset($userDetails->planName) ? $userDetails->planName : "";
		$_SESSION['login_data']['premiumPlanName'] = isset($userDetails->planName) ? $userDetails->planName : "";
		$_SESSION['login_data']['referred_by'] = !empty($userResult->userDetails[0]->user_address[0]->referredBy);
	}

	public function editNumber()
	{
		// $this->session->sess_destroy(); // Destroy the session
		echo json_encode(['message' => 'Session destroyed']);
	}



	public function sendPhoneOtp()
	{
		if (($_REQUEST['phone']) !== "" && ($_REQUEST['phone']) !== null) {
			$phone = $_REQUEST['phone'];
		}
		if ($this->checkRateLimit($_REQUEST['phone']))
		{
			$_POST['mobile'] = $phone;
			$post = json_encode($_POST);
			$ch = curl_init(local_ip_url . api_version . '/sendOtpToDevice');
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(
				'Content-Type: application/json'
			)
			);
			$loginresponse = json_decode(curl_exec($ch));
			$otpresponse = json_encode($loginresponse);
			echo $otpresponse;
		}else{
			$this->session->set_flashdata('wrongotpmessage', 'आपने अपनी ओटीपी सीमा पार कर ली है, कृपया 5 मिनट तक प्रतीक्षा करें।');
			// $response = json_encode(["status"=>1, "statusCode"=>201, "message"=>"You have exceeded your otp limit, Please wait for 5 minutes.","csrf_token"=>$this->security->get_csrf_hash()]);
			// echo $response;
		}


	}



	public function sendEmailOtp()
	{

		if (($_REQUEST['email']) !== "" && ($_REQUEST['email']) !== null) {

			$email = $_REQUEST['email'];
		}

		if (($_REQUEST['userId']) !== "" && ($_REQUEST['userId']) !== null) {

			$userId = $_REQUEST['userId'];
		}

		$_POST['email'] = $email;
		$_POST['userId'] = $userId;


		$post = json_encode($_POST);


		$ch = curl_init(local_ip_url . api_version . '/sendEmailOtp');
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json'

		)

		);

		$emailotp = json_decode(curl_exec($ch));

		$response = json_encode($emailotp);
		echo $response;


	}

	public function sendregistrationotp(){
		$post['phone'] = $this->input->post('phone');
		$post['userId'] = $this->input->post('userId');

		$result  = json_decode(callAPI('POST', local_ip_url . api_version . '/sendPhoneOtp', $post));
		$result->csrf_token = $this->security->get_csrf_hash();
		$response = json_encode($result);
		echo $response;
	}

}
