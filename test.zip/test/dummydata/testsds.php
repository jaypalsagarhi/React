<!DOCTYPE html>
<html lang="en" class="landing-html">


<head>
<meta name="viewport" content="initial-scale=1, minimum-scale=1, maximum-scale=1, width=device-width">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <style>
        .advisory-message-sticky{padding:12px 0px!important}.bolt-details,.envy-details{margin-top:-60px!important}@media only screen and (max-width:767px){.buttongroup1,.buttongroup2{width:144px;height:35px;font-weight:700;border:1px solid #452f8a}.buttongroup1::before{content:"";width:0;height:0;border:.8em solid transparent;position:absolute;border-top:16px solid #452f8a}.buttongroup1{color:#fff;background-color:#452f8a}.buttongroup2{color:#452f8a;background-color:#fff}.Delivery-text{font-size:15px;color:#494949}.heading{font-size:18px;color:#452f8a;font-weight:20px;font-family:NeoSansPro-Medium;text-align:center}.bolt-details,.envy-details{margin-top:0!important} .envy_boltheading{font-size: 18px;margin: 34px 0px 14px 0px;padding:9px;}}.heading{font-size:32px;color:#452f8a;font-weight:500;font-family:NeoSansPro-Medium}.hide{display:none!important}.city-heading{font-size:17px;color:#442c8c;font-weight:600}.city-search{margin:0 10px}.city-container{max-height:250px;overflow-y:scroll}.city-search input{border:none;box-shadow:none!important}.modal-dialog-city{position:absolute!important;top:50%;left:50%;transform:translate(-50%,-50%)!important;max-width:580px!important}.modal-dialog-city .modal-content{background:#f6f8fa;border-radius:10px;padding:0!important;width:100%!important;max-width:580px!important;min-height:360px!important}.row-flex{justify-content:flex-start;align-items:center;margin-right:0!important;margin-left:0!important}.row-flex .col-sm-4{padding:0!important}.city-check{display:flex;align-items:center;justify-content:center}.city-check [type=radio]:checked,.city-check [type=radio]:not(:checked){position:absolute;left:-9999px}.city-check [type=radio]:checked+label,.city-check [type=radio]:not(:checked)+label{position:relative;line-height:20px;display:inline-block;padding:5px 30px 5px 40px;margin:10px;min-width:155px;font-size:14px;background:#ebf2fa;cursor:pointer}.city-check [type=radio]:checked+label{color:#442c8c;border:1px solid #442c8c;border-radius:5px}.city-check [type=radio]:not(:checked)+label{color:#000;border:1px solid #8592a6;border-radius:5px}.city-check [type=radio]:checked+label:before{content:'';position:absolute;left:10px;top:5px;width:18px;height:18px;border:1px solid #442c8c;border-radius:100%;background:#fff}.city-check [type=radio]:not(:checked)+label:before{content:'';position:absolute;left:10px;top:5px;width:18px;height:18px;border:1px solid #ddd;border-radius:100%;background:#fff}.city-check [type=radio]:checked+label:after{content:'';width:14px;height:14px;background:#442c8c;position:absolute;top:7px;left:12px;border-radius:100%;-webkit-transition:.2s;transition:.2s}.city-check [type=radio]:not(:checked)+label:after{content:'';width:12px;height:12px;background:#f87da9;position:absolute;top:8px;left:13px;border-radius:100%;-webkit-transition:.2s;transition:.2s;opacity:0;-webkit-transform:scale(0);transform:scale(0)}.city-check [type=radio]:checked+label:after{opacity:1;-webkit-transform:scale(1);transform:scale(1)}.body-alert-message-city{display:flex;justify-content:space-between;align-items:center}.show-more-city{margin-top:10px;background:#fff;text-align:center;padding:5px 10px;border-radius:10px}.show-more-city p{margin-bottom:0;color:#8592a6;display:flex;justify-content:center;align-items:center;cursor:pointer}.show-more-city img{width:15px;margin-left:5px}.modal{background-color:rgba(0,0,0,.8)!important}.bestpremium,.bestpremiumphone{background-color:#ffeca2!important;z-index:1}@media (max-width:767px){.row-flex .col-sm-4{width:33.33%}.modal-dialog-city .modal-body{padding:15px 0!important}.modal-dialog-city{position:relative;top:50%;left:50%;transform:translate(-50%,-50%)!important;max-width:100%!important;width:100%!important;margin:0!important}.city-check [type=radio]:checked+label,.city-check [type=radio]:not(:checked)+label{width:82px;min-width:auto;padding:5px 10px 5px 22px;font-size:9px}.city-check [type=radio]:checked+label:before,.city-check [type=radio]:not(:checked)+label:before{width:14px;height:14px;left:4px;top:8px}.city-check [type=radio]:checked+label:after{top:10px;left:6px;width:10px;height:10px}}@media only screen and (max-width:640px){.v-responsive{width:100%!important;margin-top:0!important;margin-left:0!important}}@media only screen and (max-width:1300px){.v-responsive{width:100%!important;margin-top:0!important;margin-left:0!important}}.newLook_planPro .newImgboth{padding:10% 0}@media only screen and (max-width:767px){.newLook_planPro .heading{font-size:20px;line-height:normal}}.productdeatils{font-weight:1000!important}.premiumprdct{font-size:12px;text-transform:none}.bestpremiumphone{height:16px!important;min-width:8px!important;width:67px;top:18px;transform:translateX(-26%)}.bestpremium{height:20px!important;min-width:56px!important;position:absolute;transform:translateX(119%);top:-9px}@media only screen and (max-width:1024px){.bestpremium{height:20px!important;min-width:56px!important;background-color:#ffeca2!important;position:absolute;transform:translateX(137%);top:4px;z-index:1}}@media only screen and (max-width:768px){.bestpremium{height:20px!important;min-width:56px!important;background-color:#ffeca2!important;position:absolute;transform:translateX(95%);top:4px;z-index:1}}.newtag{font-size:12px;font-family:'Source Sans Pro';color:#fff;padding-left:8px;padding-right:8px;line-height:13px;text-indent:28px;top:-12px;font-weight:100;padding-bottom:2px;background-color:#d60d0d;border-radius:3px}.close-city-icon i{color:#9b9797;font-size:22px;padding-right:30px;cursor:pointer}.envy_boltheading{font-size:20px;font-family: 'NeoSansPro-Medium';color: #452f8a;padding: 9px; }.productimg{margin:0px !important;}#noplan{font-size:19px;}
   
body.plan.chrome.modal-open {
    padding: 0 !important;
}
.v-application p{
        margin-bottom: 0 !important;
    }
    .row-flex .col-sm.col-sm-4:nth-child(n+13) {
    display: none;
}

.navbar-nav>li {
    float: none;
}
li#water-purifier-dropdown {
    position: relative;
    /* display: inline-block; */
}

    div#mediaicon ul li {
        text-align: center;
    }
    .stlthImg{
        height: 435px !important;
    }
    .bnavbar-nav>li {
    line-height: 23.48px;
}
  
   </style>
<?php $this->load->view('common/css'); ?>
</head>

<body>
    <?php $this->load->view('common/header'); ?>
    <?php // $this->load->view('common/notification_bar'); ?> 
    <link rel="stylesheet" type="text/css" href="<?php echo CDN ?>assets/css/planv1.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CDN ?>assets/css/premiumplan.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CDN ?>assets/css/mystyle.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CDN ?>assets/css/premium.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CDN ?>assets/css/newplan.css">
    <div class="header-spacing"></div>
    <main id="main-wrapper">  
        <?php

        $_SESSION['oldcity'] = false;
        foreach($oldcitylist as $citylist){
            if( $citylist == $_SESSION['user_plan_city']){
                $_SESSION['oldcity'] = true;
            }
        }
        ?>
        <?php if(isset($_SESSION['login_data']) && $_SESSION['login_data']){
            $disbalebuttons=true;
        }else{
            $disbalebuttons=false;
        } ?>

        <div style="padding: 0px 0; background: white;">
            <?php if(isset($_SESSION['login_data']['token']) && !empty($_SESSION['login_data']['token'])){?>
                <section style="margin-bottom: 25px;" v-if="type === '1'">
                    <ol class="progtrckr" data-progtrckr-steps="5">
                        <li class="progtrckr-done"><span>Registeration</span></li>
                        <li class="progtrckr-todo"><span>Select Plan</span></li>
                        <li class="progtrckr-pending"><span>Add Address</span></li>
                        <li class="progtrckr-pending"><span>Payment</span></li>
                        <li class="progtrckr-pending"><span>eKYC</span></li>
                    </ol>
		        </section>
            <?php } else {?>
            <div class="align-me-center">
                <span class="select-plan-duration-title white--text"  id="duration-title">Select Plan</span>
            </div>
            <?php } ?>
            <div class="zero-offers">
                <div class="row d-flex align-items-center" style="justify-content: center;">   
                    <div class="d-flex align-items-center machine-cost">
                        <div class="column">
                            <img src="assets/images/checkmark_circle.png" class="checkmarkcircle" alt="checkmark">
                        </div>
                        <div class="plan-point-description1">
                            <p class="productdtls">Zero</p>
                            <p class="productdtls">&nbsp;Machine Cost</p>
                        </div>
                    </div>
                <div class="d-flex align-items-center maintenance">
                    <div class="column">
                        <img src="assets/images/checkmark_circle.png"  class="checkmarkcircle" alt="checkmark">
                    </div>
                    <div class="plan-point-description1">
                        <p class="productdtls">Zero</p>
                        <p class="productdtls">&nbsp;Maintenance</p>
                    </div>
                </div>
                <div class="d-flex align-items-center relocation">
                    <div class="column">
                        <img src="assets/images/checkmark_circle.png"  class="checkmarkcircle" alt="checkmark">
                    </div>
                    <div class="plan-point-description2">
                        <p class="productdtls">Zero</p>
                        <p class="productdtls">&nbsp;Relocation Cost</p>
                    </div>
                </div>
            </div>
        </div>


        <!-- new plan page starts -->
        <section class="plan-section  plan-desk planV1 ">
            <div id="selectPlan" data-current-tier="silver" class="align-me-center flex-column">
                <v-app id="plans" class="all-plans" v-show="loaded">
                    <plans
                        :kycdone="alreadySubscribed"
                        :userplanid="userPlanId"
                        :userplanmodel="userPlanModel"
                        :producttype="productType"
                        :productimage="productImage"
                        :error="error"
                        :forceshow="forceShow"
                        :deposit="deposit"
                        :logindata="logindata"
                        :disbalebuttons="disbalebuttons"
                        :dynamicdepositamt = "dynamicDepositAmt"
                        :premiumstatus= "premiumstatus"
                        :premiumamount= "premiumamount"
                        :premiumdepositamount = "premiumdepositamount"
                        :premiumplanduration = "premiumplanduration"
                        :premiumplanid="premiumplanid"
                        :premiumplanname="premiumplanname"
                        :fromropremium="fromropremium"
                        :pageurl="page_url"
                        :currentplanname="currentplanName"
                          :selectedcity="selectedcity"
                        :envyboltplan="envyboltplan"
                        :premiumplan="$vuetify.breakpoint.xs ? 'tab'+premiumPlan.toLowerCase() : premiumPlan.toLowerCase()"
                        :currentplan="$vuetify.breakpoint.xs ? 'tab'+planName.toLowerCase() : planName.toLowerCase()"/>
                </v-app>
            </div>
            
            
        </section>
        <!-- tab -->
        
        <!-- new plan page end -->

        <!-- new plan page starts -->
        <section class="b_tabPannel plan_webView">
            <div class="container">
                <div class="panel panel-default" style=" border: none;box-shadow: none;background: white;">
                    <div class="panel-heading panel-heading-nav" style="width: 48%;margin: auto;">
                        <ul class="nav nav-tabs" style="border: none;display:flex;">
                            <li role="presentation" class="active b_tab" id="b_tabProduct">
                            <a class="b_tabList arrow-bottom" id="b_tabName" href="#p_contentone" aria-controls="p_contentone" role="tab" data-toggle="tab">Bolt Mineralizer Details</a>
                            </li>
                            <li role="presentation" class="b_tab" id="b_tabFAQ">
                            <a class="b_tabList arrow-bottom" href="#p_contenttwo" aria-controls="p_contenttwo" role="tab" data-toggle="tab" style="margin-left: 15px;">FAQs</a>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body" style="width: 100%;margin: auto;">
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active" id="p_contentone">
                                <figure class="image banner-web" id="stealth_product">
                                    <img class="b_productImage stlthImg" src="assets/images/stealth_bg.webp" alt="background">
                                    <figcaption class="zinger_figcaption">
                                        <h2>Get clean and healthy drinking water with Under The Sink (RO+UV+Copper), with advanced UV sterilization and added copper benefits.</h2>
                                        <ul>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">6-Stage Advanced Purification</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Copper 29 infuses goodness of natural copper into water.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Under the sink installation</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">UTS Faucet for Sink</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Integrated HN tank</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">In-line UV Sterilization</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Total Dissolved Solids (TDS) Levels:Upto 1500 ppm</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Upto 15 litres/hours Purification Capacity</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Input Voltage: 14-300 V AC/ 50 HZ</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Dimensions (cm): 25(W)x34(H)x35(D)</li>
                                        </ul>
                                    </figcaption>
                                </figure>
                                <figure class="image banner-web" id="bolt_product">
                                    <img class="b_productImage" src="assets/images/banner-new-ro-subs-dektop.png" alt="background">
                                    <figcaption class="bolt_figcaption">
                                        <h2>Get clean and healthy drinking water with Bolt (RO+UV+ Mineralizer+Taste Enhancer), with advanced UV Sterilization and added essential minerals.</h2>
                                        <ul>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">6-Stage Advanced Purification</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">7 Ltrs Water Storage Capacity</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">LED indications like tank full and fault in the water purifier</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Effective mineralizer, which helps preserve key minerals in the
                                                water during the purification process</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">In-Tank UV Sterilization</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Wall Mount Option</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Total Dissolved Solids (TDS) Levels: Up to 2,000 ppm</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Upto 12 litres/hour Purification Capacity</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Input Voltage: 14-300 V AC/ 50 HZ</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Dimensions (cm): L 29.5 X W 27.5 X H 50.5</li>
                                            
                                        </ul>
                                    </figcaption>
                                </figure>
                                <figure class="image banner-web" id="zingerCopper_product">
                                    <img class="b_productImage" src="../ro-subscription/assets/assets/images/RO_bgImage.png" alt="background">
                                    <figcaption class="copper_figcaption">
                                        <h2>Introducing, World's 1st RO that saves 20,000 litres of water every year thereby contributing in a big way in conserving water.</h2>
                                        <ul>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">6-Stage Advanced Purification</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">6.5 Litres Water Storage Capacity</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Copper 29 infuses goodness of natural copper into water</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Get Hot, Warm and Ambient Water as per your Need</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">In-Tank UV Sterilization</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Wall Mount Option</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Total Dissolved Solids (TDS) Levels:Upto 2,000 ppm</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Upto 15 liters/hours Purification Capacity</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Input Voltage: 14-300 V AC/ 50 HZ</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Dimensions (cm): L 34.5 X W 23 X H 49.5</li>
                                        </ul>
                                    </figcaption>
                                </figure>
                                <figure class="image banner-web" id="alkaline_product">
                                    <img class="b_productImage" src="../ro-subscription/assets/assets/images/RO_hydroBG.png" alt="background" style="height: 460px;">
                                    <figcaption class="copper_figcaption">
                                        <h2>Livpure Smart HydroBoost Water is the perfect companion for your hydration needs, providing safe, purified, and refreshing water enriched with antioxidants.</h2>
                                        <ul>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check"> Self-cleaning system for maintenance and pure water.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check"> Twin safety function protects against low input flow</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">High-capacity water cleaning cartridge for consistent purification.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Beep and lamp indication for cartridge replacement.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check"> Eight-cell multiple tank electrolysis system for optimal ionization.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Melody sound adjustment for customizing volume.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Surge absorber protection for longevity.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check"> Smart connectivity with IoT-enabled features.</li>                                        
                                        </ul>
                                    </figcaption>
                                </figure>
                                <figure class="image banner-web" id="copper_product">
                                    <img class="b_productImage" src="assets/images/banner-new-ro-subs-dektop.png" alt="background">
                                    <figcaption class="bolt_figcaption">
                                        <h2>Get clean and healthy drinking water with Bolt (RO+UV+ Mineralizer+Taste Enhancer), with advanced UV Sterilization and added essential minerals.</h2>
                                        <ul>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">6-Stage Advanced Purification</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">7 Ltrs Water Storage Capacity</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Copper 29 infuses goodness of natural copper into water</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">LED indications like tank full and fault in the water purifier</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Effective mineralizer, which helps preserve key minerals in the
                                                water during the purification process</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">In-Tank UV Sterilization</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Wall Mount Option</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Total Dissolved Solids (TDS) Levels: Up to 2,000 ppm</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Upto 12 litres/hour Purification Capacity</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Input Voltage: 14-300 V AC/ 50 HZ</li>                                            
                                        </ul>
                                    </figcaption>
                                </figure>
                            </div>

                            <div role="tabpanel" class="tab-pane fade" id="p_contenttwo">
                                <div class="container question__answere">
                                <div class="faqBx">

                                    <div class="accordionSet active">
                                        <div class="accordionHeading">1.Does this need any security deposit?</div>
                                        <div class="accordionContent">
                                        We provide top-class machines with a sleek design that provide a 6-stage water purification
                                        process. In the market, these machines cost between 15 and 30K INR. We deliver, install,
                                        and take care of the maintenance part throughout the subscription period. Hence, a
                                        negligible security amount is mandatory which is 100% refundable once you decide to stop
                                        the services.
                                        </div>
                                    </div>
                                    <!--accordionSet-->

                                    <div class="accordionSet">
                                        <div class="accordionHeading">2.When will this security deposit be refunded to me?</div>
                                        <div class="accordionContent">
                                            Once the customer cancels the subscription, our team will recover the machine. After the product clears the Q.C process, the security deposit amount will be refunded. Amount gets credited to your bank/credit card account within 7 business days.
                                        </div>
                                    </div>
                                    <!--accordionSet-->

                                    <div class="accordionSet">
                                        <div class="accordionHeading">3.What’s the number of free days trial included in this?</div>
                                        <div class="accordionContent">
                                            You get 7 days of free trial. If you are not satisfied with our subscription services you may choose to cancel it any time during the first 7 days. 
                                        </div>
                                </div>
                                <!--accordionSet-->

                                        <div class="accordionSet">
                                        <div class="accordionHeading">4.Does it have any lock-in period?</div>
                                        <div class="accordionContent">
                                            Yes, there is a 3-month lock-in period. However, we provide a 7-day free trial option that allows you to explore our services at no cost. During this trial period, you can cancel without any charges. After the trial, if you choose to continue, the 3-month lock-in period will be in effect.
                                        </div>
                                        </div>
                                        <!--accordionSet-->

                                        <div class="accordionSet">
                                        <div class="accordionHeading">5.What types of plans are available?</div>
                                        <div class="accordionContent">
                                        Discover the flexibility and tailored options with Livpure Smart subscription plans. Our plans are designed to suit diverse needs, ensuring there's a perfect 
                                        fit for every family. Whether you're considering limited consumption options or a comprehensive family plan, the choice is yours based on the model that best aligns with your requirements.
                                        </div>
                                        </div>
                                        <!--accordionSet-->

                                        <div class="accordionSet">
                                        <div class="accordionHeading">6.Which services are included?</div>
                                        <div class="accordionContent">
                                        All of our RO maintenance services can be availed by the customer free of cost during the subscription period. The customer has to raise the service request via app. Once the request is registered, the technician is expected to schedule and visit within 24-48 hours to resolve the issue.
                                        </div>
                                        </div>

                                        </div>
                                <!--faqBx-->
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- new plan page end -->

        <!-- tab -->
        <section class="b_tabPannel plan_mob_view">
            <div class="container">
                <div class="panel panel-default" style=" border: none;box-shadow: none;background: white;">
                    <div class="panel-heading panel-heading-nav" style="width: 48%;margin: auto;">
                        <ul class="nav nav-tabs nav-tabs-planefaq" style="border: none;display: flex;">
                            <li role="presentation" class="b_tab" id="b_tabProduct-mob">
                            <a class="b_tabList arrow-bottom" id="b_tabName-mob" href="#prodct_det" aria-controls="prodct_det" role="tab" data-toggle="tab">Product Details</a>
                            </li>
                            <li role="presentation" class="active b_tab" id="b_tabFAQ-mob">
                            <a class="b_tabList arrow-bottom" href="#prodct_faq" aria-controls="prodct_faq" role="tab" data-toggle="tab" style="margin-left: 15px;">FAQs</a>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body" style="width: 100%;margin: auto;">
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane fade" id="prodct_det">
                                <figure class="image banner-mob b_uts-mob" id="uts_product-mob" style="display:none">
                                    <img class="b_productImage" src="../ro-subscription/assets/assets/images/RO_bgImage.png" alt="background">
                                    <figcaption class="zinger_figcaption">
                                        <h2>Get clean and healthy drinking water with UTS (RO+UV+Copper), with advanced UV sterilization and added copper benefits.</h2>
                                        <ul>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">6-Stage Advanced Purification</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Copper 29 infuses goodness of natural copper into water.</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Under the sink installation</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">UTS Faucet for Sink</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Integrated HN tank</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">In-line UV Sterilization</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Total Dissolved Solids (TDS) Levels:Upto 1500 ppm</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Upto 15 liters/hours Purification Capacity</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Input Voltage: 14-300 V AC/ 50 HZ</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Dimensions (cm): 25(W)x34(H)x35(D) </li>

                                            
                                        </ul>
                                    </figcaption>
                                </figure>
                                <figure class="image banner-mob b_boltProduct-mob" id="bolt_product-mob61" style="display:none">
                                    <img class="b_productImage" src="assets/images/banner-new-ro-subs-dektop.png" alt="background">
                                    <figcaption class="bolt_figcaption">
                                        <h2>Get clean and healthy drinking water with Bolt (RO+UV+ Mineralizer+Taste Enhancer), with advanced UV Sterilization and added essential minerals.</h2>
                                        <ul>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">6-Stage Advanced Purification</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">7 Ltrs Water Storage Capacity</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">LED indications like tank full and fault in the water purifier</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Effective mineralizer, which helps preserve key minerals in the
                                                water during the purification process</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">In-Tank UV Sterilization</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Wall Mount Option</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Total Dissolved Solids (TDS) Levels: Up to 2,000 ppm</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Upto 12 litres/hour Purification Capacity</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Input Voltage: 14-300 V AC/ 50 HZ</li>
                                        </ul>
                                    </figcaption>
                                </figure>
                                <figure class="image banner-mob b_boltProduct-mob74" id="b_boltProduct-mob74" style="display:none">
                                    <img class="b_productImage" src="assets/images/banner-new-ro-subs-dektop.png" alt="background">
                                    <figcaption class="bolt_figcaption">
                                        <h2>Get clean and healthy drinking water with Bolt (RO+UV+ Mineralizer+Taste Enhancer), with advanced UV Sterilization and added essential minerals.</h2>
                                        <ul>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">6-Stage Advanced Purification</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">7 Ltrs Water Storage Capacity</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Copper 29 infuses goodness of natural copper into water</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">LED indications like tank full and fault in the water purifier</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Effective mineralizer, which helps preserve key minerals in the
                                                water during the purification process</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">In-Tank UV Sterilization</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Wall Mount Option</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Total Dissolved Solids (TDS) Levels: Up to 2,000 ppm</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Upto 12 litres/hour Purification Capacity</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Input Voltage: 14-300 V AC/ 50 HZ</li>                                            
                                        </ul>
                                    </figcaption>
                                </figure>
                                <figure class="image banner-mob b_zingerCopper-mob" id="zingerCopper_product-mob" style="display:none">
                                    <img class="b_productImage" src="assets/images/banner_zinger_ro_subs_dektop.png" alt="background">
                                    <figcaption class="copper_figcaption">
                                        <h2>Introducing, World's 1st RO that saves 20,000 litres of water every year thereby contributing in a big way in conserving water.</h2>
                                        <ul>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">6-Stage Advanced Purification</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">6.5 Litres Water Storage Capacity</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Copper 29 infuses goodness of natural copper into water</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Get Hot, Warm and Ambient Water as per your Need</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">In-Tank UV Sterilization</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Wall Mount Option</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Total Dissolved Solids (TDS) Levels:Upto 2,000 ppm</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Upto 15 liters/hours Purification Capacity</li>
                                            <li><img src="../ro-subscription/assets/images/checkmark_circle.png" alt="img">Input Voltage: 14-300 V AC/ 50 HZ</li>
                                        </ul>
                                    </figcaption>
                                </figure>
                                <figure class="image banner-mob alkaline_planProduct" id="alkaline_product-mob" style="display:none">
                                    <img class="b_productImage" src="assets/images/banner_zinger_ro_subs_dektop.png" alt="background">
                                    <figcaption class="copper_figcaption">
                                        <h2>Livpure Smart HydroBoost Water is the perfect companion for your hydration needs, providing safe, purified, and refreshing water enriched with antioxidants. </h2>
                                        <ul>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check"> Self-cleaning system for maintenance and pure water.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check"> Twin safety function protects against low input flow</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">High-capacity water cleaning cartridge for consistent purification.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Beep and lamp indication for cartridge replacement.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check"> Eight-cell multiple tank electrolysis system for optimal ionization.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Melody sound adjustment for customizing volume.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check">Surge absorber protection for longevity.</li>
                                            <li><img src="assets/assets/images/bg_correct.png" alt="check"> Smart connectivity with IoT-enabled features.</li>   
                                        </ul>
                                    </figcaption>
                                </figure>
                            </div>

                            <div role="tabpanel" class="tab-pane fade in active" id="b_tabFAQ-mb">
                                <div class="container question__answere">
                                <div class="faqBx">

                                    <div class="accordionSet active">
                                        <div class="accordionHeading">1.Why does this need any security deposit?</div>
                                        <div class="accordionContent">
                                        We provide top-class machines with a sleek design that provide a 6-stage water purification
                                        process. In the market, these machines cost between 15 and 30K INR. We deliver, install,
                                        and take care of the maintenance part throughout the subscription period. Hence, a
                                        negligible security amount is mandatory which is 100% refundable once you decide to stop
                                        the services.
                                        </div>
                                    </div>
                                    <!--accordionSet-->

                                    <div class="accordionSet">
                                        <div class="accordionHeading">2.When will this security deposit be refunded to me?</div>
                                        <div class="accordionContent">
                                            Once the customer cancels the subscription, our team will recover the machine. After the product clears the Q.C process, the security deposit amount will be refunded. Amount gets credited to your bank/credit card account within 7 business days.
                                        </div>
                                    </div>
                                    <!--accordionSet-->

                                    <div class="accordionSet">
                                        <div class="accordionHeading">3.What’s the number of free days trial included in this?</div>
                                        <div class="accordionContent">
                                            You get 7 days of free trial. If you are not satisfied with our subscription services you may choose to cancel it any time during the first 7 days. 
                                        </div>
                                </div>
                                <!--accordionSet-->

                                        <div class="accordionSet">
                                        <div class="accordionHeading">4.Does it have any lock-in period?</div>
                                        <div class="accordionContent">
                                            Yes, there is a 3-month lock-in period. However, we provide a 7-day free trial option that allows you to explore our services at no cost. During this trial period, you can cancel without any charges. After the trial, if you choose to continue, the 3-month lock-in period will be in effect.
                                        </div>
                                        </div>
                                        <!--accordionSet-->

                                        <div class="accordionSet">
                                        <div class="accordionHeading">5.What types of plans are available?</div>
                                        <div class="accordionContent">
                                        Discover the flexibility and tailored options with Livpure Smart subscription plans. Our plans are designed to suit diverse needs, ensuring there's a perfect 
                                        fit for every family. Whether you're considering limited consumption options or a comprehensive family plan, the choice is yours based on the model that best aligns with your requirements.
                                        </div>
                                        </div>
                                        <!--accordionSet-->

                                        <div class="accordionSet">
                                        <div class="accordionHeading">6.Which services are free of charge?</div>
                                        <div class="accordionContent">
                                        All of our RO maintenance services can be availed by the customer free of cost during the subscription period. The customer has to raise the service request via app. Once the request is registered, the technician is expected to schedule and visit within 24-48 hours to resolve the issue.
                                        </div>
                                        </div>

                                        </div>
                                <!--faqBx-->
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- new plan page end -->
    </main>
    <!-- data-backdrop="static" data-keyboard="false" -->
    <div class="modal fade modal-filter" id="modal-city-select" role="dialog" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-dialog-city">
            <div class="modal-content">
            <div class="modal-body">
                <div class="body-header black-gradient-background ">
                    <div class="main-header-side white-color">
                        <div class="city-heading">Select your city</div>
                        <div></div>
                    </div>
                </div>
                <div class="city-search">
                    <div class="form-group has-search">
                        <span class="fa fa-search form-control-feedback"></span>
                        <input type="text" class="form-control" placeholder="Search your city">
                    </div>
                </div>
                <div class="city-container city-container-header">
                    <div class="body-alert-message body-alert-message-city">
                        <div class="row row-flex">
                            <?php foreach($oldcitylist as $oldcities){?>
                                <div class="col-sm col-sm-4">
                                    <div class="city-check" data-plan-id="planpopup<?= str_replace(' ', '' ,$oldcities)?>">
                                        <input type="radio" class="popup" id="planpopup<?= str_replace(' ', '' ,$oldcities)?>" name="radio-group" value="<?=$oldcities ?>">
                                        <label  for="<?=$oldcities ?>"><?= $oldcities ?></label>
                                    </div>
                                </div>
                            <?php } ?>
                            <?php foreach ($newCityList as $newcities){?>
                                <div class="col-sm col-sm-4">
                                    <div class="city-check" data-newplan-id="newcityplanpopup<?= str_replace(' ', '' ,$newcities)?>">
                                        <input type="radio" id="newcityplanpopup<?=$newcities ?>" name="radio-group" value="<?=$newcities?>">
                                        <label for="<?= $newcities ?>"><?=$newcities ?></label>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="show-more-city">
                    <p class="show-more">See More <span><img src="<?= CDN ?>assets/images/see_more_down.svg" ></span></p>
                </div>
            </div>
            </div>
        </div>
    </div> 
    <!-- main-wrapper close -->

   
    <?php $this->load->view('common/footer');
        $appURL =  site_url('plan/index/1');
        if($this->input->get('city')){
            $URLParams = $this->input->get('city');
            $allCitylist = cityList();
            if(in_array(base64_decode($URLParams), $allCitylist)){
                $appURL = site_url('plan/index/1?city='.$URLParams);
            }
        }
        
    ?>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
                                    
    <script>
        app.plans = [];
        app.url = "<?php echo $appURL ?>";
        app.unlimitedPlans = [];
        app.boltMinilizer = [];
        app.zingertankPlans = [];
        app.stealthPlans = [];
        app.alkalinePlans = [];
        app.boltCopperPlan = [];
        app.oldcitylist = <?= json_encode($oldcitylist) ?>;
        app.cdn = "<?php echo CDN ?>";
        app.type = "<?= isset($_SESSION['login_data']['token']) ? true : false ?>";
        app.threemonthvisibility = "<?php echo THREEMONTHPLANVISIBILITY ;?>";
        const selectPlan = new Vue({
            el: '#selectPlan',
            vuetify: customVuetify,
            data() {
                return {
                    loaded: false,
                    forceShow: false,
                    error:"<?php echo $planError  ?>",
                    title: "Select model and duration",
                    productImage: "<?= $imageURL ?>",
                    productType: "<?= $productType ?>",
                    planName: "<?= isset($_SESSION['login_data']['planName']) && $_SESSION['login_data']['planName'] != '' ? $_SESSION['login_data']['planName'] : $planName ?>",
                    premiumPlan: "<?= isset($_SESSION['login_data']['premiumPlanName']) && $_SESSION['login_data']['premiumPlanName'] != '' ? $_SESSION['login_data']['premiumPlanName'] : $unlimitedplanName ?>",
                    alreadySubscribed:  "<?= isset($_SESSION['login_data']['paymentCompleted']) && $_SESSION['login_data']['paymentCompleted'] == true ? 1 : 0 ?>",
                    userPlanId :  "<?php echo isset($_SESSION['login_data']['planId']) ? $_SESSION['login_data']['planId'] : json_decode($plans)[0]->planId; ?>",
                    userPlanModel :  "<?php echo isset($_SESSION['login_data']['userPlanModel']) ? $_SESSION['login_data']['userPlanModel'] : '' ?>",
                    logindata: "<?php isset($_SESSION['login_data']) ? true : false ?>",
                    disbalebuttons:"<?= $disbalebuttons ?>",
                    dynamicDepositAmt:"<?php echo isset($_SESSION['deposit_amount']) ? $_SESSION['deposit_amount']: $_SESSION['deposit_amount']?>",
                    deposit:"<?php echo isset($_SESSION['deposit']) ? $_SESSION['deposit'] : $_SESSION['deposit'] ?>",
                    premiumstatus:"<?php echo $_SESSION['premium_status'] ?>",
                    premiumamount:"<?php echo $_SESSION['premium_amount'] ?>",
                    premiumdepositamount:" <?php echo $_SESSION['premium_deposit_amount']?>",
                    premiumplanduration:"<?php echo $_SESSION['duration'] ?>",
                    premiumplanid:"<?php echo $_SESSION['premium_planid'] ?>",
                    premiumplanname:"<?php echo $_SESSION['premium_planname'] ?>",
                    fromropremium:"<?php echo $_SESSION['from_ro_premium'] ?>",           
                    page_url:"<?php echo  $_SERVER['REQUEST_URI'] ?>",
                    currentplanName:"<?php echo  $_SESSION['currentplanname'] ?>",
                     envyboltplan : "<?php echo  $_SESSION['oldcity'] ?>",
                    selectedcity:"<?php  echo $_SESSION['user_plan_city'] ?>"
                };
            },
            methods: {
                destroy() {
                    this.$destroy();
                }
            },
            mounted(){
                this.loaded = true;
            }
        });
        $(".radio-month input[name='radio']").click(function(){
            if($('input:radio[name=radio1]:checked')){
                $(".flex-item").removeClass("active");
                $(this).closest(".flex-item").addClass("active");
            }
        });
        $(".radio-month input[name='radio1']").click(function(){
            if($('input:radio[name=radio1]:checked')){
                $(".flex-item").removeClass("active");
                $(this).closest(".flex-item").addClass("active");
            }
        });
        $(".radio-month input[name='radio2']").click(function(){
            if($('input:radio[name=radio2]:checked')){
                $(".flex-item").removeClass("active");
                $(this).closest(".flex-item").addClass("active");
            }
        });
        $(".radio-month input[name='radio3']").click(function(){
            if($('input:radio[name=radio3]:checked')){
                $(".flex-item").removeClass("active");
                $(this).closest(".flex-item").addClass("active");
            }
        });
        $(".radio-month input[name='radio4']").click(function(){
            if($('input:radio[name=radio4]:checked')){
                $(".flex-item").removeClass("active");
                $(this).closest(".flex-item").addClass("active");
            }
        });
        $("input[name='radio'][type='radio'][data-toggle='collapse']").click(function(){
            $(this).each(function(){
                if($(this).prop("checked")){       
                    $(".panel-collapse.collapse").closest(".panel-default").css("border", "");
                    $(".panel-heading").css("background", "");
                    $(this).closest(".panel-default").css("border", "");
                    $(this).closest(".panel-heading").css("background", "");
                }
                else if(!$(this).prop("checked")){
                    $(this).closest(".panel-default").css("border", "");
                }
            });
        });
        $(document).ready(function(){
    //         setTimeout(function() {
    //     $('.plan_product.prod_card.active').click();
    // }, 500); // 5000 milliseconds = 5 seconds
            var userAgent = navigator.userAgent.toLowerCase(); 
            if (userAgent .indexOf('safari')!=-1){ 
            if(userAgent .indexOf('chrome')  > -1){
            $("body").addClass("chrome");
                //browser is chrome
            }else if((userAgent .indexOf('opera')  > -1)||(userAgent .indexOf('opr')  > -1)){
                //browser is opera 
                $("body").addClass("opera");
            }else{
                //browser is safari, add css
                $("body").addClass("safari");
            }
            }
            $("#boltModelBtn").click(function(){
                document.getElementById('newbolt-details').style.display = 'none'
                $("#roSubPlan").show();
                $("#premium").hide();

                $("#zingerCuHotModel").hide();
                $("#boltModel").show();
                $("#zingerDownArrow").hide();
                $("#zingerCuHotModelBtn").removeClass("active");
                $(this).addClass("active");
            });

            $("#zingerCuHotModelBtn").click(function(){
                $("#roSubPlan").hide();
                $("#premium").show();
                document.getElementById('newbolt-details').style.display = 'block';
                $("#zingerCuHotModel").show();
                $("#boltModel").hide();
                $("#boltDownArrow").hide();
                $("#boltModelBtn").removeClass("active");
                $(this).addClass("active");
            });
            // faq script
            $(document).on('click', '.accordionSet > .accordionHeading', function() {
                $(this).next().slideToggle();
                $(this).parent().siblings().find('.accordionContent').slideUp();
                $(".accordionSet").removeClass('active');
                $(this).parent().addClass('active');

            });

            $(document).on('click', '.accordionSet.active > .accordionHeading', function() {
                $(this).parent().removeClass('active');
            });
            // end
        });

        $(".depotooltip").click(function(){
            $(this).parents('div.dptext').find('.deposit-tooltiptext').removeClass('d-none').addClass('d-block');
        });
        $(".depoclose1").click(function(){
            var tooltip_modal=$(this).parents('.deposit-tooltiptext');
            $(this).parents('.deposit-tooltiptext').removeClass('d-block').addClass('d-none');
        });
    
        // zingertank 
        $(document).on("click", "#b_zingerProduct_chnage", function () {  
            $("#b_tabName,#b_tabName-mob").text("Zinger SS Tank Details"); //text replace
        });
        // plans Bolt Mineralizer
        $(document).on("click", "#b_boltProduct61,#b_boltProduct-mob61", function () {
            $("#b_tabName, #b_tabName-mob").text("Bolt Mineralizer Details");  //text replace
            $(".banner-web,.banner-mob").hide();
            if ($(".banner-web[id*='bolt']").length > 0) {
                // .banner-web element with id containing "zinger" exists
                $(".banner-web[id*='bolt']").show();
            }
            if ($(".banner-mob[id*='mob61']").length > 0) {
                // $(".b_tab.active").removeClass('active');
                // .banner-web element with id containing "zinger" exists
                $("#b_tabName-mob").trigger('click');
                $(".banner-mob[id*='mob61']").show();
            }
        });
        $(document).on("click", "#b_boltProduct74,#b_boltProduct-mob74", function () {
            $("#b_tabName, #b_tabName-mob").text("Bolt Copper Mineralizer Details");  //text replace
            $(".banner-web,.banner-mob").hide();
            if ($(".banner-web[id*='copper']").length > 0) {
                // .banner-web element with id containing "zinger" exists
                $(".banner-web[id*='copper']").show();
            }
            if ($(".banner-mob[id*='mob74']").length > 0) {
                // $(".b_tab.active").removeClass('active');
                // .banner-web element with id containing "zinger" exists
                $("#b_tabName-mob").trigger('click');
                // .banner-web element with id containing "zinger" exists
                $(".banner-mob[id*='mob74']").show();
            }
        });
        // unlimitedPlans zingerTankPlans
        $(document).on("click", "#b_zingerProduct,#b_zingerCopper-mob", function () {
            $(".banner-web,.banner-mob").hide();
            $("#b_tabName,#b_tabName-mob").text("Zinger Copper Details");  //text replace
            if ($(".banner-web[id*='zinger']").length > 0) {
                // .banner-web element with id containing "zinger" exists
                $(".banner-web[id*='zinger']").show();
            }
            if ($(".banner-mob[id*='zinger']").length > 0) {
                // .banner-web element with id containing "zinger" exists
                $(".banner-mob[id*='zinger']").show();
            }
        });
        // Stealth Under The Sink 
        $(document).on("click", "#b_stealthProduct,#b_uts-mob", function () {
            $("#b_tabName,#b_tabName-mob").text("Stealth Under The Sink");  //text replace
            $(".banner-web,.banner-mob").hide();
            if ($(".banner-web[id*='stealth']").length > 0) {
                // .banner-web element with id containing "zinger" exists
                $(".banner-web[id*='stealth']").show();
            }
            if ($(".banner-mob[id*='uts_product']").length > 0) {
                // .banner-web element with id containing "zinger" exists
                $(".banner-mob[id*='uts_product']").show();
            }
        });
        // Alkaline alkalinePlans
       
        $(document).on("click", "#b_alkalineProduct,#alkaline_mob", function () {
            $("#b_tabName,#b_tabName-mob").text("HydroBoost Details");  //text replace
            $(".banner-web,.banner-mob").hide();
            if ($(".banner-web[id*='alkaline']").length > 0) {
                // .banner-web element with id containing "zinger" exists
                $(".banner-web[id*='alkaline']").show();
            }
            if ($(".banner-mob[id*='alkaline']").length > 0) {
                // .banner-web element with id containing "zinger" exists
                $(".banner-mob[id*='alkaline']").show();
            }
        });

        // add and remove active class
        $(document).on("click",'.plan_product',function(){
            $('.plan_product.active').removeClass('active');
            //  $("#b_tabProduct").addClass('active');
            $(this).addClass("active");
        });
        

    
    $(document).on('click', '#b_tabFAQ-mob', function() {
        $("#b_tabFAQ-mb").addClass("active in");
        $("#prodct_det").removeClass("active in");
    });
    $(document).on("click",'.b_newFlex-mob',function(){

        $('.b_newFlex-mob').removeClass('active');
        $('.plan_mob_view .plan_product').hide();
        $('.b_newFlex-mob').show();
        $(this).hide();
        $(this).siblings('.plan_product').addClass('active').show();
    });
    
    $('#basicModal').on('shown.bs.modal', function (e) {
        $(this).css({"z-index":"99999999"});
        if(!$("#tabContent > li.b_tab.active").length){
            $("#tabContent > li.b_tab:nth-child(1)").addClass("active");
            $('#basicModal .b_plans>div:nth-child(1)').addClass("active");
        }    
    });
    $(document).on("click",'.b_selectButton',function(){
        // Remove 'active' class from the currently active element
        $('.b_selectButton.active').removeClass('active');    
        // Add 'active' class to the clicked element
        $(this).addClass('active');
        // Check the radio button inside the clicked .b_selectButton div
        $(this).find('input[type="radio"]').prop('checked', true);
    });
</script>
</body>
</html>

