<!DOCTYPE html>
<html lang="hi" class="landing-html">

<head>
    <title>
        <?php echo isset($meta_title) ? $meta_title : 'Livpure Smart'; ?>
    </title>
    <meta charset="UTF-8">
    <meta name="robots" content="noindex, follow" />
    <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="theme-color" content="#442c8c" />
    <meta name="description" content="<?php echo isset($meta_description) ? $meta_description : ''; ?>">
    <link rel="shortcut icon" href="<?php echo CDN ?>assets/images/favicon.png" type="image/x-icon">
    <link href="<?php echo CDN ?>assets/css/noHead.css" rel="stylesheet">

    <style>
        label.error {
            color: red;
        }

        .register_btn {
            cursor: pointer;
        }
        .loginerror {
            color: #eb5757;
            font-size: 12px;
            padding: 8px 0 0;
            font-weight: 500;
            font-family: 'kohinoor-regular;';
            position: absolute;
            top: -34px;
            left: 9%;
        }
        #otp{
            position: relative;
        }
        .loginsuccess {
            color: #25d366;
            font-size: 14px;
            padding: 8px 0 0;
            font-weight: 500;
            font-family: 'kohinoor-regular;';
            position: absolute;
            top: -20px;
            left: 18%;
        }
        .otp-input-fields{
            margin-top:24px;
        }
    </style>
    <script>
        function validateCheckbox() {
            var checkbox = document.getElementById('terms');
            if (!checkbox.checked) {
                checkbox.setCustomValidity('कृपया नियम एवं शर्तें चुनें');
                return false; // Prevent form submission
            } else {
                checkbox.setCustomValidity(''); // Reset custom validity message
                return true;
            } // Allow form submission
        }
    </script>
    <?php
    if (ENV == 'PROD') {
        $this->load->view('/common/analytics.php');
    }
    ?>
</head>

<body>
<?php if (ENV == 'PROD') { ?>
<script type="text/javascript" src="https://cdn.moengage.com/webpush/moe_webSdk.min.latest.js"></script>
    <script type="text/javascript">
        Moengage = moe({ app_id: "GVH6KZUQXZH0GYP8C95HOEWO" });       
    </script>
    <noscript>
      <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL4V4BH" height="0" width="0"
          style="display:none;visibility:hidden"></iframe>
  </noscript>
  <?php } ?>
    <?php
    if (ENV == 'PROD') {

        $decodedData = json_decode(CallAPI('GET', neverbounce, ''), true);
        if ($decodedData['credits_info']['paid_credits_remaining'] > 0 && ($page == 'nlp_hindi' || $page == 'nlp_Hindi')) { ?>
            <script>

                var neverbounce = '<?php echo neverbouncekey ?>';
                var dcryptneverbounce = atob(neverbounce);
                document.addEventListener("DOMContentLoaded", function (event) {
                    var emailFieldId = 'email';
                    var emailFieldTarget = document.getElementById(emailFieldId);
                    emailFieldTarget.setAttribute('data-nb', '');
                });
                _NBSettings = {
                    apiKey: dcryptneverbounce
                };
            </script>
            <script type="text/javascript" src="https://cdn.neverbounce.com/widget/dist/NeverBounce.js" defer></script>
            <script>
                document.querySelector('body').addEventListener('nb:registered', function (event) {
                    // Get field using id from registered event
                    let field = document.querySelector('[data-nb-id="' + event.detail.id + '"]');
                    // Handle results (API call has succeeded)
                    field.addEventListener('nb:result', function (e) {
                        if (e.detail.result.is(_nb.settings.getAcceptedStatusCodes())) {
                            // Do stuff for good email                       
                        } else {
                            // Do stuff for bad email
                        }
                        // }
                    });
                });
            </script>
        <?php }
    } ?>
    <main>
        <section class="nlp_head">
            <div class="logo">
                <a href='<?php echo LOGO_URL_PATH ?>'
                    class="navbar-brand logo  <?= !isset($_SESSION['login_data']) ? 'pre-login' : '' ?> align-mob-logo">
                    <img src='<?php echo CDN; ?>assets/images/newlogo.svg'
                        data-src='<?php echo CDN; ?>assets/images/newlogo.svg' alt="Water Purifier on Rent"
                        title="Livpure Smart Water Purifier on Subscription" class="lazyload" loading="lazy"
                        width="100" height="50" style="width: 100%;">
                </a>
            </div>
        </section>
        <section class="lang_Hindi hindi_Banner">
            <div class="section_container">
                <p class="ro_Content">
                    <img src="<?= CDN ?>assets/images/people_icon.webp" alt="people" width="52" height="50">
                    <span>2.2 + करोड़ ग्राहक</span> Livpure RO को इस्तेमाल कर रहे हैं।
                </p>
                <div class="main_flex">
                    <div class="leftFlex">
                        <img loading="eager" src="<?= CDN ?>assets/images/hindiBanner.webp"
                            alt="Rent A RO Water Purifier | LivpureSmart" class="home-banner " height="630" width="590">
                        <img loading="eager" class="mobile-home-banner active"
                            src="<?= CDN ?>assets/images/hindMob.webp" alt="Rent A RO Water Purifier | LivpureSmart"
                            class="home-banner ">
                    </div>
                    <div class="rightFlex">
                        <p class="b_rightP">यह कोई <span>EMI योजना नहीं है,</span> Livpure RO मासिक सब्सक्रिप्शन के साथ
                            आता है जिसे आप कभी भी समाप्त कर सकते हैं।</p>
                        <?php 
                         if ($_SESSION['registersucess'] != true) { ?>
                            <form class="hindi_tab" id="signupTab" method="POST"
                                action="<?php echo base_url('nlp/register'); ?>" onsubmit="return this.checkValidity()">
                                <h3 class="h3">रजिस्टर करें और पाएं 7 दिनों का <br> निःशुल्क ट्रायल</h3>
                                <?php if ($this->session->flashdata('success')): ?>
                                    <div class="alert alert-success alert-dismissible fade in">
                                        <?= $this->session->flashdata('success'); ?>
                                    </div>
                                <?php endif;
                                ?>
                                <?php if ($this->session->flashdata('error')): ?>
                                    <div class="alert alert-warning alert-dismissible fade in"
                                        style="color: red; margin-bottom: 10px; opacity: 1;">
                                        <?= $this->session->flashdata('error'); ?>
                                    </div>
                                <?php endif;
                                ?>

                                <input type="hidden" name="id" value="<?= $id ?>">
                                <input type="hidden" name="pageName" value="Landing">
                                <input type="hidden" name="usertype" value="nlp_hindi">

                                <div class="form-group">
                                    <input name="name" tabindex="2" id="name" type="text" minlength="3" maxlength="30"
                                        required aria-required="true" placeholder="पूरा नाम"
                                        onkeyup="this.value = this.value.replace(/[^\sa-zA-Z]/g,'')"
                                        oninvalid="this.setCustomValidity('कृपया नाम भरें।')"
                                        oninput="this.setCustomValidity('')">
                                </div>
                                <label for="input_33">Mobile Number</label>

                                <div class="input-wrapper">
                                    <input name="phone" <?= (ENV === "PROD") ? "pattern='[6-9]{1}[0-9]{9}'" : "pattern='[1-9]{1}[0-9]{9}'" ?> id="input_33" type="text" maxlength="10"
                                        minlength="10" placeholder="मोबाइल नंबर" required="" aria-required="true" value=""
                                        oninvalid="this.setCustomValidity('कृपया सही मोबाइल नंबर दर्ज करें।')"
                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');validatePhoneInput(this);">
                                </div>

                                <div class="form-group">
                                    <input name="email" tabindex="2" id="email" type="email" maxlength="30" required=""
                                        aria-required="true" placeholder="ईमेल आईडी" value=""
                                        oninvalid="this.setCustomValidity('कृपया ईमेल आईडी दर्ज करें।')"
                                        oninput="this.setCustomValidity('')">
                                </div>


                                <div class="form-group">
                                    <input name="pincode" id="pincode" type="text" minlength="6" maxlength="6"
                                        pattern="[0-9]{6}" placeholder="पिनकोड" aria-required="true" data-errmsg='कृपया वैध पिनकोड दर्ज करें |'
                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');"
                                        oninvalid="this.setCustomValidity(this.dataset.errmsg)" required>
                                </div>



                                <div class="form-group">
                                    <input readonly name="city" id="city" type="text" maxlength="60" minlength="1"
                                        placeholder="शहर" aria-required="true" required
                                        oninvalid="this.setCustomValidity('कृपया वैध पिनकोड दर्ज करें |')">
                                </div>
                                <div class="b_checkbox">
                                    <input checked required type="checkbox" name="terms"
                                        oninvalid="this.setCustomValidity('कृपया नियम एवं शर्तें चुनें')"
                                        onchange="this.setCustomValidity('')" />
                                    <span class="b_bldCondition"> LivpureSmart <a
                                            href="<?php echo base_url('terms_of_use') ?>">पर रजिस्टर होकर, आप हमारी उपयोग की
                                            शर्तों से सहमत होते
                                            हैं। </a>
                                    </span>
                                </div>
                                <input type="hidden" id="servicepincode" name="servicepincode" value="">

                                <button type="submit" class="register_btn" id="sign_upBtn" name="submit">रजिस्टर
                                    करें</button>
                            </form>
                        <?php } else {


                            ?>
                            <div id="signupOtp_tab">
                                <div class="enter_Otp" style="text-align: center;">
                                    <img class="otpImg" src="<?= CDN ?>assets/images/otplogo.webp" alt="logo"
                                        style="width: 100px;">
                                    <p>नीचे दिए गए नंबर पर भेजा गया <span>4-अंकीय OTP</span> को डालें।</p>
                                    <p class="numberOtp">+91-
                                        <?= $_SESSION['login_data']['phone'] ?>
                                        <input type="hidden" id="otpphoneno" name="otpphoneno" value="">
                                    </p>
                                    <form class="formverify" method="POST" id="otp"
                                        action="<?php echo base_url('nlp/phoneOtp'); ?>">
                                        <?php
                                        if (!empty($this->session->flashdata('message1'))) {
                                            echo '<i class="fa fa-exclamation-circle errormsg" aria-hidden="true" style="color:red">' . '</i>' .
                                                '<i class="errormsg" style="color:red; font-family:NeoSansPro-Regular;">' . $this->session->flashdata('message1') . '</i>';
                                        } 
                                        if (!empty($this->session->flashdata('wrongotpmessage'))) {
                                            echo ' <i class="fa fa-exclamation-circle errormsg" aria-hidden="true" style="color:red;">' .
                                                $this->session->flashdata('wrongotpmessage') . '</i>';
                                        } ?>

                                        <div class="loginsuccess"></div>
                                        <div class="loginerror"></div>
                                        <div class="otp-input-fields" id="otp_submitBtnHindi">
                                            <input type="hidden" name="otp_page" value="nlp_hindi">
                                            <input type="tel" class="Box productkey1" id="digit-1" name="first"
                                                placeholder="-" maxlength="1" pattern="\d*"
                                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required>
                                            <input type="tel" class="Box productkey1" id="digit-2" name="second"
                                                placeholder="-" maxlength="1" pattern="\d*"
                                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required>
                                            <input type="tel" class="Box productkey1" id="digit-3" name="third"
                                                placeholder="-" maxlength="1" pattern="\d*"
                                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required>
                                            <input type="tel" class="Box productkey1" id="digit-4" name="fourth"
                                                placeholder="-" maxlength="1" pattern="\d*"
                                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required>
                                        </div>
                                </div>
                                <input type="submit" class="register_btn otp_submitBtn" id="otp_submitBtn"
                                    value="सबमिट करें"></input>




                                <div class="timer_work" id="timerWork">
                                    <span id="timer">00:30</span> सेकंड में OTP पुनः
                                    भेजें
                                </div>
                                </form>
                                <button style="cursor: pointer;" id="resendButton"
                                    onclick="resendOtp('<?= $_SESSION['login_data']['phone'] ?>','<?= $_SESSION['login_data']['userId'] ?>')">OTP
                                    पुनः भेजें</button>
                            </div>

                        <?php } ?>

                    </div>
                </div>
            </div>
        </section>
        <!-- comparision of products start -->
        <section class="lang_Hindi section NewLP_Con great-choice-section active choiceSection">
            <div class="section_container">
                <h2 class="heading compare_purifier">Livpure Smart RO क्यों चुनें ?</h2>
                <div class="flex_content background-color">
                    <div class="flex_item">

                    </div>
                    <div class="flex_item">
                        <img class="zinger_img" loading="lazy" src="<?= CDN ?>assets/images/bolt_blue_z_inger_hot.webp"
                            alt="App">
                        <div class="caption">
                            <p class="purifier_livpure">Livpure वॉटर <br> प्यूरीफायर</p>
                        </div>
                    </div>
                    <div class="flex_item">
                        <img class="prime_image" loading="lazy" src="<?= CDN ?>assets/images/drinkprime_5.webp"
                            alt="App">
                        <div class="caption">
                            <p class="purifier_ro">अन्य वॉटर <br> प्यूरीफायर</p>
                        </div>
                    </div>
                    <div class="flex_item">
                        <img class="jar_image" loading="lazy" src="<?= CDN ?>assets/images/water_jar.webp" alt="App">
                        <div class="caption">
                            <p class="purifier_jar">पानी की <br> कैन</p>
                        </div>
                    </div>
                </div>
                <div class="table_data">
                    <table class="bordered mobile-devices new_brdred">
                        <tr>
                            <td style="border-left:0; border-top:0;">लागत</td>
                            <td><span>केवल ₹399 प्रति माह</span><img class="check_circle" loading="lazy"
                                    src="<?= CDN ?>assets/images/noun_check_154213.webp" alt="App"></td>
                            <td><span>₹10-15 हजार + ऐन्यूअल मेंटेनेंस</span><img class="up_arrow_circle" loading="lazy"
                                    src="<?= CDN ?>assets/images/ic_arrow_drop_down_circle_24_px_copy_2.webp" alt="App">
                            </td>
                            <td style="border-top:0;"><span>₹600-900 प्रति माह</span><img class="up_arrow_circle"
                                    loading="lazy"
                                    src="<?= CDN ?>assets/images/ic_arrow_drop_down_circle_24_px_copy_2.webp" alt="App">
                            </td>
                        </tr>
                        <tr>
                            <td style="border-left:0;">वार्षिक मेंटेनेंस</td>
                            <td><span>निःशुल्क</span><img class="check_circle" loading="lazy"
                                    src="<?= CDN ?>assets/images/noun_check_154213.webp" alt="App"></td>
                            <td><span>₹4 -5 हजार</span><img class="up_arrow_circle" loading="lazy"
                                    src="<?= CDN ?>assets/images/ic_arrow_drop_down_circle_24_px_copy_2.webp" alt="App">
                            </td>
                            <td><span>लागू नहीं</span><img class="cancle_circle" loading="lazy"
                                    src="<?= CDN ?>assets/images/ic_cancel_24_px_copy_5.webp" alt="App"></td>
                        </tr>
                        <tr>
                            <td style="border-left:0;">पानी की गुणवत्ता ट्रैकिंग</td>
                            <td><span>स्मार्ट ऐप के जरिए ट्रैकिंग</span><img class="check_circle" loading="lazy"
                                    src="<?= CDN ?>assets/images/noun_check_154213.webp" alt="App"></td>
                            <td><span>संभव नहीं</span><img class="up_arrow_circle" loading="lazy"
                                    src="<?= CDN ?>assets/images/ic_cancel_24_px_copy_5.webp" alt="App"></td>
                            <td><span>संभव नहीं</span><img class="cancle_circle" loading="lazy"
                                    src="<?= CDN ?>assets/images/ic_cancel_24_px_copy_5.webp" alt="App"></td>
                        </tr>

                    </table>
                </div>
                <div class="clear"></div>
            </div>
        </section>
    </main>
    
    <!-- GA4 signed_up Event -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <script src="<?php echo CDN ?>assets/js/jquery.validate.min.js" defer></script>
    
    <?php if (isset($_SESSION['gta4_nlp_hindiEnglish_signup_event'])) { ?>
        <script>

            window.dataLayer = window.dataLayer || [];
            dataLayer.push({
                'event': 'signed_up',
                'userId': '<?= $_SESSION['login_data']['userId'] ?>',
                'city': '<?= $_SESSION['login_data']['city'] ?>',
                'userName': '<?= $_SESSION['login_data']['userName']; ?>',
                'userEmail': '<?= $_SESSION['login_data']['email']; ?>',
                'mobileNumber': '<?= $_SESSION['login_data']['phone']; ?>',
                'pincode': '<?= $_SESSION['pincode']; ?>'
            });
            dataLayer.push({
                'event': 'set_user_id',
                'user_id': '<?= $_SESSION['login_data']['userId'] ?>',
                'event_fired': 'signed_up',
                'user_type': 'signin'
            });
            //console.log("dataLayer_push:-- ",dataLayer.push);
            console.log('Data pushed to dataLayer:', dataLayer);
        </script>
        <?php unset($_SESSION['gta4_nlp_hindiEnglish_signup_event']);
    } ?>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            var inputField = document.getElementById("name");
            var emailInput = document.getElementById("email");
            var pincodeInput = document.getElementById("pincode");

            if (inputField) {
                inputField.addEventListener("input", function (event) {
                    var inputValue = event.target.value.trim(); // Remove leading and trailing spaces
                    var inputValueLength = inputValue.replace(/\s+/g, '').length; // Count characters excluding spaces                  
                    if (inputValueLength == 0) {
                        inputField.setCustomValidity("नाम आवश्यक है।");
                    } else if (inputValueLength < 3) {
                        inputField.setCustomValidity("नाम कम से कम 3 अक्षर लंबा होना चाहिए।");
                    } else if (inputValueLength > 30) {
                        inputField.setCustomValidity("नाम अधिकतम 30 अक्षर लंबा होना चाहिए।");
                    } else {
                        inputField.setCustomValidity("");
                    }
                });
            }
            if (emailInput) {
                emailInput.addEventListener('input', function (event) {
                    var emailInput = event.target;
                    if (emailInput.validity.valid) {
                        emailInput.setCustomValidity('');
                    } else {
                        emailInput.setCustomValidity("कृपया ईमेल आईडी दर्ज करें।");
                    }
                });
            }
            if (pincodeInput) {
                pincodeInput.addEventListener("input", function (event) {
                    var inputValueLength = event.target.value.length;
                    console.log("pincodeInput value length:", inputValueLength);
                    if (inputValueLength == 0) {
                        pincodeInput.setCustomValidity("पिनकोड आवश्यक है।");
                    } else if (inputValueLength > 0 && inputValueLength < 6) {
                        pincodeInput.setCustomValidity("पिनकोड कम से कम 6 अक्षर लंबा होना चाहिए|");
                    } else if (inputValueLength > 6) {
                        pincodeInput.setCustomValidity("पिनकोड अधिकतम 6 अक्षर लंबा होना चाहिए|");
                    } else {
                        pincodeInput.setCustomValidity("");
                    }
                });
            }
        });
        function validatePhoneInput(input) {
            var inputValue = input.value;
            var pattern = ("<?php echo ENV ?>" === "PROD") ? /[6-9]{1}[0-9]{9}/ : /[1-9]{1}[0-9]{9}/;
            if (!pattern.test(inputValue)) {
                input.setCustomValidity('कृपया सही मोबाइल नंबर दर्ज करें।');
            } else {
                input.setCustomValidity('');
            }
        }

        document.addEventListener('DOMContentLoaded', function () {
            var boxes = document.querySelectorAll('.Box');
            var otpBtn = document.getElementById('otp_submitBtn');

            boxes.forEach(function (box) {
                box.addEventListener('keyup', function (e) {
                    //const val = e.which;  
                    console.log("ggggggg---", e.which);
                    var input = this;
                    if (input.value.length == 0 && e.which == 8) {
                        input.classList.toggle("productkey2");
                        input.classList.toggle("productkey1");
                        input.previousElementSibling.focus();
                    } else if (input.value.length >= parseInt(input.getAttribute("maxlength"), 10)) {
                        input.classList.toggle("productkey1");
                        input.classList.toggle("productkey2");
                        if (input.nextElementSibling !== null) {
                            input.nextElementSibling.focus();
                        }
                    }


                });
            });
        });
        document.addEventListener("DOMContentLoaded", function () {

            function checkInputValue() {

                var inputValue = document.getElementById("digit-4").value;
                var submitBtn = document.getElementById("otp_submitBtn");
                if (inputValue.trim() !== "") {

                } else {
                    submitBtn.style.backgroundColor = "#bdbdbd";
                    document.getElementById('otp_submitBtn').disabled = true;
                }
            }
            var digit_4Tag = document.getElementById('digit-4');
            if (digit_4Tag !== null) {
                checkInputValue();


                var otpField = document.getElementById("digit-4");
                otpField.addEventListener("keyup", checkInputValue);



            }
        });

        var signupOtpTab = document.getElementById('signupOtp_tab');
        if (signupOtpTab !== null) {
            document.getElementById('signupOtp_tab').style.display = 'block';
        }
        let countdown;

        function startTimer() {
            let seconds = 30;
            document.getElementById('resendButton').disabled = true;


            countdown = setInterval(function () {
                seconds--;
                document.getElementById('timer').innerText = '00: ' + seconds;
                document.getElementById('resendButton').style.display = "none";
                document.getElementById('timerWork').style.display = "block";
                if (seconds <= 0) {
                    clearInterval(countdown);
                    document.getElementById('timer').innerText = '00:30';
                    document.getElementById('resendButton').disabled = false;
                    document.getElementById('timerWork').style.display = "none";
                    document.getElementById('resendButton').style.display = "block";
                }
            }, 1000);
        }
    </script>
    <!-- script for dynamic content start -->

    <script>
        $(document).ready(function () {

            $('.Box').on('input', function () {
                $('.errormsg').css('display', 'none');
                var otpLength = 0;
                $('.Box').each(function () {
                    otpLength += $(this).val().length;
                });

                // Enable or disable submit button based on total OTP length
                if (otpLength === 4) {
                    $('#otp_submitBtn').prop('disabled', false);
                    $('#otp_submitBtn').css('background-color', '#f58220');
                    console.log('otp_submitBtn enable');
                } else {
                    console.log('otp_submitBtn disabled');
                    $('#otp_submitBtn').prop('disabled', true);
                    $('#otp_submitBtn').css('background-color', '#bdbdbd');
                }
            });

            var popup = <?= $_SESSION['pincodepopup'] == true ? $_SESSION['pincodepopup'] : 'false' ?>;

            if (popup == true) {
                document.getElementById('pincodepopup').style.display = 'block';
                <?= $_SESSION['pincodepopup'] = 'false' ?>
            }
        })
        //Change water jar to purifier
        //Active Class compare watar jar && purifier
        var searchRequest = null;
        var isValid = false;
        $(function () {
            // Add a custom validation method
            jQuery.validator.addMethod("servicablePincodeValidation", function (value, element, params) {
                return isValid;
            }, "क्षमा करना! यह क्षेत्र सेवा योग्य नहीं है");
            var minlength = 6;
            // $(document).on("keyup change blur keypress click", "#pincode", function () {
            $("#pincode").keyup(function () {
                var that = this,
                    value = $(this).val();
                url = "<?php echo site_url('address/fetchLocation') ?>";
                if (value.length == minlength) {
                    var form = document.getElementById("signupTab");
                    if (!form.checkValidity()) {
                        // If the form is not valid, show error messages
                        form.reportValidity();
                        // If the form is not valid, prevent form submission
                        event.preventDefault();
                    }
                    if (searchRequest != null)
                        searchRequest.abort();
                    isValid = false;
                    searchRequest = $.ajax({
                        type: "POST",
                        url: url,
                        data: {
                            'pincode': value
                        },
                        async: false,
                        success: function (response) {
                            console.log("respone", response);
                            // $('#city').prop('readonly', true);
                            if (response.success == true) {
                                console.log('success');
                                $('#city').children('option').remove();
                                var cityoptions = '';
                                cityoptions += response.pincode[0].city;

                                $('#city').val(cityoptions);
                                $('#pincode')[0].setCustomValidity('');
                                $('#sign_upBtn').attr("disabled", false);
                            } else {
                                console.log('failed');
                                $('#city').val('');
                                var pincodeInput = document.getElementById("pincode");
                                pincodeInput.setAttribute('data-errmsg','माफ़ कीजिए! इस क्षेत्र में अभी हमारी सेवा नहीं है।'); 
                                pincodeInput.setCustomValidity('माफ़ कीजिए! इस क्षेत्र में अभी हमारी सेवा नहीं है।');
                                pincodeInput.reportValidity();
                                //pincodeInput.setCustomValidity("कृपया सही पिनकोड दर्ज करें।");
                            }
                        },
                        error: function (xhr, textStatus, errorThrown) {
                            var errorMessage = xhr.responseText;
                            console.log("success-errorMessage", errorMessage);
                        }
                    });

                }

            });
        });
    </script>

    <script>
        function resendOtp(phone, userId) {
            // $('.validation').css('display', 'none')
            $('#resendButton').prop('disabled', true);
            var url = `<?php echo base_url(); ?>ajax/sendLoginotp`;
            $.ajax({
                type: "POST",
                url:url,
                data: {
                    'phone': phone,
                    // 'language_type': "hindi"
                },
                success: function (response) {
                    resendphone = JSON.parse(response);
                    $('.errormsg').css("display", "none");
                    $('#resendButton').prop('disabled', false);
                    if (resendphone.status == true && resendphone.statusCode == 200) {
                        var sendPhoneOtp = true;
                        $('.loginerror').hide();
                        messageShowHide('loginsuccess',"ओटीपी सफलतापूर्वक भेज दिया गया है");
                    }else if(resendphone.statusCode == '201'){
                        var sendPhoneOtp = false;
                        $('.loginsuccess').hide();
                        messageShowHide('loginerror',"आप अपना ओटीपी भेजने की सीमा पार कर चुके हैं, कृपया 5 मिनट तक प्रतीक्षा करें।");
                    }else{
                        var sendPhoneOtp = false;
                        $(".loginerror").text(resendphone.message).show();
                    }
                    if (sendPhoneOtp == true) {
                        startTimer();
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    alert(xhr.status);
                }


            });
            return false;
        }
        function messageShowHide(error_or_success, message){
            $('.'+error_or_success).text(message).show();
            setTimeout(function() {
                $("."+error_or_success).hide();
            }, 5000);
        }
        
        const inputs = document.getElementById("otpbox");
        if (inputs) {
            inputs.addEventListener("input", function (e) {
                const target = e.target;
                const val = target.value;
                if (isNaN(val)) {
                    target.value = "";
                    return;
                }

                if (val != "") {
                    $('.errormsg').css("display", "none");
                    const next = target.nextElementSibling;
                    if (next) {
                        next.focus();
                    }
                }
            });

            inputs.addEventListener("keyup", function (e) {
                const target = e.target;
                const key = e.key.toLowerCase();

                if (key == "backspace" || key == "delete") {
                    target.value = "";
                    const prev = target.previousElementSibling;
                    if (prev) {
                        prev.focus();
                    }
                    return;
                }
            });
        }
    </script>
    <!-- script for dynamic content end -->
</body>

<!--Script as per New UI -->



</html>