<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nlp extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url', 'common_helper'));
		$this->load->model('RegisterModel');
		$this->load->model('Userlead');
	}

	public function index()
	{


		$data['citylist'] = cityList();

		$data['meta_title'] = "Get Best RO Water Purifier On Rent For Home Online Starting @ ₹399/m";
		$data['meta_description'] = "Looking for an affordable & hassle-free water purifier? Get your Livpure Smart RO water purifier on subscription @ ₹399/month. Choose the best water purifier online today!";
		$data['meta_keywords'] = 'ro on rent in delhi, water purifier on rent in India, ro water purifier on rent in India, rent water purifier in delhi ncr, water purifier, ro purifier on rent, rent water purifier, best water purifier in India';

		$_SESSION['nlppage'] = true;
		$_SESSION['nlp'] = true;


		if ($_SESSION['registersucess'] == true && $_SESSION['phoneotp'] == false) {

			$_POST['phone'] = $_SESSION['login_data']['phone'];
			$_POST['userId'] = $_SESSION['login_data']['userId'];

			$post = json_encode($_POST);

			$ch = curl_init(local_ip_url . api_version . '/sendPhoneOtp');
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt(
				$ch,
				CURLOPT_HTTPHEADER,
				array(
					'Content-Type: application/json'

				)

			);

			$phoneotpresponse = json_decode(curl_exec($ch));
			$_SESSION['phoneotp'] = $phoneotpresponse->status;
		}

		if ($_REQUEST['rcode'] != "" && !isset($_SESSION['requestrefferalcode'])) {
			$_SESSION['requestrefferalcode'] = $_REQUEST['rcode'];
		}

		$id = '';
		if (isset($_REQUEST['id']) != '') {
			$id = base64_decode($_REQUEST['id']);
		} else {
			$id = 0;
		}
		$data['id'] = $id;
		$planName = array("Silver", "Gold", "Platinum", "Titanium");
		$data['planname'] = $planName;
		$data['page'] = 'nlp';
		$this->load->view('nlp', $data);
	}
	public function register()
	{
		
		$source = 'Water jars';
		$post['username'] = $this->input->post('name');
		$post['phone'] = $this->input->post('phone');
		$post['email'] = $this->input->post('email');
		$post['city'] = $this->input->post('city');
		$post['usertype'] = $this->input->post('usertype');
		$post['referralCode'] = (isset($_POST['referralCode']) and !empty($_POST['referralCode'])) ? trim($_POST['referralCode']) : '';
		$cloned_post = $post;
		$result = json_decode(CallAPI('POST', local_ip_url . "v4" . '/register', $cloned_post));

		if ($result->statusCode == '200') {
			$c_post = $post;
			unset($c_post['usertype']);
			$this->RegisterModel->register($c_post);
			// $this->RegisterModel->register(json_decode($post, true));
			$data = array(
				'token' => $result->data->token,
				'userId' => $result->data->userId,
				'userName' => $result->data->name,
				'email' => $result->data->email,
				'enteredReferralCode' => $cloned_post['referralCode'],
				// referral Code used while sign up - for analytics
				'city' => $result->data->city,
				// referral Code used while sign up - for analytics
				'pincode' => $result->data->pincode,
				'phone' => $result->data->mobile,
				'water_source' => $source,
				'referralCode' => $cloned_post['referralCode'],
				'city' => $cloned_post['city'],
				'phoneVerification' => $result->data->phoneVerification
			);

			$_SESSION['login_data'] = $data;
			//$_SESSION['realRefCode'] = $_POST['referralCode'];
			$_SESSION['login_data']['realRefCode'] = $cloned_post['referralCode'];

			$_SESSION['token'] = $result->data->token;
			$_SESSION['status'] = 'new-2022';
			$_SESSION['pincode'] = $_POST['pincode'];
			// $_SESSION['login_data']['paymentlead'] = true;
			$_SESSION['login_data']['water_source'] = $source;
			//$_SESSION['login_data']['nlp_hindi'] = true;
			if ($this->input->post('usertype') == 'nlp_hindi' || $this->input->post('usertype') == 'nlp_english') {
				$_SESSION['gta4_nlp_hindiEnglish_signup_event'] = "gta4_nlp_hindiEnglish_signup_event";
			}
			
			//  signUpPush();

			$_SESSION['deposit'] = 'true';

			$_SESSION['gta4_signup_event'] = "signup";
			
			$_SESSION['login_data']['rd_su'] = 'Y'; // to check page redirected from login su - signed up
			$_SESSION['login_data']['page_source'] = '';
			$_SESSION['new_customer'] = "Y";
			// default false
			$_SESSION['login_data']['Ekyc'] = 'N';
			$_SESSION['login_data']['kycCompleted'] = false;
			$_SESSION['login_data']['paymentCompleted'] = false;
			$_SESSION['login_data']['paid'] = false;
			$this->setUserDetails();
			$phone = $result->data->mobile;
			$userId = $_SESSION['login_data']['userId'];
			
			/* if($usertype == 'nlp_hindi'){
										$source_of_enquiry = 'nlp_hindi';
									}
									else if($usertype == 'commercial'){
										$source_of_enquiry = 'commercial';
									}
									else{
										$source_of_enquiry = 'ro_nlp';
									} */
			//die;
			//echo  'session-utm'.$_SESSION['utm_source'];die;
			$updatelead = array(
				'user_id' => $userId,
				'username' => $_SESSION['login_data']['userName'],
				'phone' => $result->data->mobile,
				'alt_phone' => " ",
				'referral_code' => $cloned_post['referralCode'],
				'referral_phone' => $_SESSION['realRefPhone'],
				'referral_name' => $_SESSION['realRefName'],
				'email' => $_SESSION['login_data']['email'],
				'city' => $cloned_post['city'],
				'district' => '',
				'state' => '',
				'pincode' => $_SESSION['pincode'],
				'address' => '',
				'source_of_enquiry' => (isset($post['usertype']) && ($post['usertype'] == 'commercial')) ? 'commercial' : (($post['usertype'] == 'nlp_hindi') ? 'nlp_hindi' : (($post['usertype'] == 'nlp_english') ? 'nlp_english' : 'ro_nlp')),

				'utm_source' => $_SESSION['utm_source'],
				'utm_medium' => $_SESSION['utm_medium'],

				

				'current_source_of_water' => $source,
				'current_plan_selected' => '',
				'lead_created_page' => "",
				'current_lead_page' => "Registration_page",
				'business_id' => "1"
			);
			
			$this->Userlead->addLead($userId);
			$this->Userlead->updateLeadData($updatelead, $phone);
			//echo  'session-utm'.$_SESSION['utm_source'];die;
			$_SESSION['registersucess'] = true;
			if ($post['usertype'] == 'commercial') {
				redirect(base_url() . 'commercial');
			} else if ($post['usertype'] == 'nlp_hindi') {
				redirect(base_url() . 'nlp_hindi');
			} else if ($post['usertype'] == 'nlp_english') {
				redirect(base_url() . 'nlp_english');
			} else {
				redirect(base_url() . 'nlp');
			}

		} else {

			$_SESSION['registersucess'] = false;
			$message = $result->message;
			//echo '------msg-----'.$message;die;
			//"Phone number in use" /*"Email in use"*/
			//$message = 'This mobile number is already registered with us. Please sign up with a new mobile number.';
			if (strpos($message, 'Email and Phone number are in use') !== false) {
				$message = 'This mobile and email number are already registered with us. Please login or sign up with a new mobile number and email address.';
			}
			if (strpos($message, 'Phone number in use') !== false) {
				$message = 'This mobile number is already registered with us. Please login or sign up with a new mobile number.';
			}
			if (strpos($message, 'Email in use') !== false) {
				$message = 'This email address is already registered with us. Please login or sign up with a new email address.';
			}
			$this->session->set_flashdata('error', $message);

			if ($post['usertype'] == 'commercial') {
				redirect(base_url() . 'commercial');
			} else if ($post['usertype'] == 'nlp_english') {
				redirect(base_url() . 'nlp_english');
			} else if ($post['usertype'] == 'nlp_hindi') {
				//echo $result->message;die;
				//$message = 'यह मोबाइल और ईमेल नंबर हमारे पास पहले से ही पंजीकृत है। कृपया नए मोबाइल नंबर और ईमेल पते के साथ लॉगिन या साइन अप करें।';
				if (strpos($result->message, 'Phone number in use') !== false) {
					$message = 'यह मोबाइल नंबर हमारे पास पहले से ही पंजीकृत है। कृपया नए मोबाइल नंबर से लॉगिन करें या साइन अप करें।';
				}
				if (strpos($result->message, 'in use') !== false) {
					$message = 'यह मोबाइल और ईमेल नंबर हमारे पास पहले से ही पंजीकृत है। कृपया नए मोबाइल नंबर और ईमेल पते के साथ लॉगिन या साइन अप करें।';
				}
				$this->session->set_flashdata('error', $message);
				redirect(base_url() . 'nlp_hindi');
			} else {
				redirect(base_url() . 'nlp');
			}

		}
	}

	public function register_old()
	{
		$_POST['address'] = $_POST['address'] . ' ' . $_POST['area'];
		$post = json_encode($_POST);
		$id = $_POST['id'];
		/* echo "<pre>";
											 print_r($_POST);
											 echo "</pre>";
											 die(); */
		//$ch = curl_init('https://api-dev.rpsapi.in/userRegistration');
		$ch = curl_init(local_ip_url . 'userRegistration');
		//$ch = curl_init('http://localhost:8080/login');
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$ch,
			CURLOPT_HTTPHEADER,
			array(
				'Content-Type: application/json'
			)
		);
		$result = json_decode(curl_exec($ch));

		/* echo "<pre>";
											print_r($result);
											echo "</pre>";
											die(); */

		if ($result->status->success === true) {

			$message = $result->status->info;
			$this->session->set_flashdata('success', $message);
			//$return = $this->RegisterModel->register($_POST);
			if ($id > 0) {
				$this->session->set_flashdata('message', "Successfully Registered");
				// redirect(base_url().'login');
				$this->register_login();
				redirect(base_url() . 'Plan??r=true&id=' . base64_encode($id));
			} else {
				$this->session->set_flashdata('message', "Successfully Registered");
				// redirect(base_url().'login');
				$this->register_login();
				redirect(base_url() . 'Plan??r=true&id=' . base64_encode($id));
			}
		} else {
			$message = $result->status->info;
			$this->session->set_flashdata('error', $message);
			redirect(base_url() . 'nlp');
		}
	}

	public function register_login()
	{
		//        $_POST = json_decode(file_get_contents('php://input'), true);
		$post = json_encode($_POST);
		//print_r($post);
		//die();
		$id = $_POST['id'];
		//$ch = curl_init('https://api-dev.rpsapi.in/userLogin');
		$ch = curl_init(local_ip_url . 'userLogin');
		//        $ch = curl_init('http://localhost:8080/login');
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$ch,
			CURLOPT_HTTPHEADER,
			array(
				'Content-Type: application/json'
			)
		);

		$result = json_decode(curl_exec($ch));
		if (isset($result->token) != '' && isset($result->status->success) == 1) {

			$data = array(
				'token' => $result->token,
				'userId' => $result->userId,
				'userType' => $result->userType,
				'userName' => $result->userName,
				'email' => $result->email,
				'Ekyc' => $result->Ekyc,
				'planId' => $result->planId,
				'referralCode' => $result->referralCode,
				'paid' => $result->paid,
				'sessionKey' => $result->sessionKey,
				'userReferralCode' => $this->input->post('referralCode'),
				// referral Code used while sign up - for analytics
				'phone' => $this->input->post('phone'),
				'lastName' => $this->input->post('lastName'),
				'state' => $this->input->post('state'),
				'city' => $this->input->post('city'),
				'pincode' => $this->input->post('pincode'),
				'phoneVerification' => $result->phoneVerification
			);

			$_SESSION['login_data'] = $data;

			$_SESSION['login_data']['rd_su'] = 'Y'; // to check page redirected from login su - signed up
			//Check whether the customer has recharged or not before;
			$Data['userId'] = $_SESSION['login_data']['userId'];
			$url = local_ip_url . 'getRechargeHistory';
			$ReturnData = json_decode(CallAPI('POST', $url, $Data));
			if (isset($ReturnData->success) and $ReturnData->success == "false") {
				$_SESSION['new_customer'] = "Y";
			} else {
				$_SESSION['new_customer'] = "N";
			}


			/* echo "<pre>";
														 print_r($_SESSION);
														 print_r($ReturnData);
														 echo "</pre>"; */
			/* die(); */
		} else {
			$message = "Invalid username and password";
			$this->session->set_flashdata('login_error', $message);
			redirect(base_url() . 'login');
		}
	}
	private function setUserDetails()
	{
		$_POST['userId'] = $_SESSION['login_data']['userId'];
		$url = local_ip_url . api_version . '/getReferralShortLink';
		$refUrl = json_decode(CallAPI('POST', $url, $_POST));
		if (!empty($refUrl) && $refUrl->sucess == true) {
			$_SESSION['refshoorturl'] = $refUrl->data->refShortLink;
		} else {
			$_SESSION['refshoorturl'] = '';
		}

		$Data['email'] = $_SESSION['login_data']['email'];
		$url = local_ip_url . 'getUserDetailsWeb';
		$userResult = json_decode(CallAPI('POST', $url, $Data));
		$userDetails = $userResult->userDetails[0];
		$_SESSION['login_data']['registerDate'] = $userDetails->registerDate;
		$_SESSION['login_data']['userName'] = $userDetails->username;
		$_SESSION['emailVerification'] = $userDetails->emailVerification;
		$_SESSION['phoneVerification'] = $userDetails->phoneVerification;

		if (isset($userDetails->ro_recharge[0]) && is_array($userDetails->ro_recharge[0]) && count($userDetails->ro_recharge[0]) >= 1) {
			$_SESSION['DeviceRechargeStatus'] = $userDetails->ro_recharge[0]->DeviceRechargeStatus;
		} else {
			$_SESSION['DeviceRechargeStatus'] = '';
		}
		if (isset($userDetails->lastName)) {
			$_SESSION['login_data']['fullName'] = $_SESSION['login_data']['userName'] . ' ' . $userDetails->lastName;
		} else {
			$_SESSION['login_data']['fullName'] = $_SESSION['login_data']['userName'];
		}

		$fullName = explode(" ", $_SESSION['login_data']['fullName'], 2);

		$_SESSION['login_data']['firstName'] = $fullName[0];
		$_SESSION['login_data']['lastName'] = count($fullName) == 1 ? "" : $fullName[1];

		$_SESSION['login_data']['phone'] = (isset($userDetails->phone) && !empty($userDetails->phone)) ? $userDetails->phone : $_SESSION['login_data']['phone'];
		$_SESSION['login_data']['productType'] = $userDetails->productType;
		$_SESSION['login_data']['userreferralCode'] = $userDetails->referralCode;
		$_SESSION['login_data']['referralCode'] = $userDetails->referredBy->referralCode;

		$_SESSION['login_data']['planName'] = isset($userDetails->planName) ? $userDetails->planName : "";
		$_SESSION['login_data']['premiumPlanName'] = isset($userDetails->planName) ? $userDetails->planName : "";
		$_SESSION['login_data']['referred_by'] = !empty($userResult->userDetails[0]->user_address[0]->referredBy);
	}


	function phoneOtp()
	{

		///echo '<pre>';print_r($_SESSION);//die;
		//print_r($_POST);die;
		$otpvalue = $_POST['first'] . $_POST['second'] . $_POST['third'] . $_POST['fourth'];

		if (strlen($otpvalue) < '4') {

			$msg = 'please enter proper otp';
			$data['page'] = 'nlp';
			$this->session->set_flashdata('message1', 'please enter proper otp');
			if ($_POST['otp_page'] == 'nlp_hindi') {
				redirect(base_url() . 'nlp_hindi');
			}
			if ($_POST['otp_page'] == 'nlp_english') {
				redirect(base_url() . 'nlp_english');
			} else {
				redirect(base_url() . 'nlp');
			}

		} else {

			$post['phoneOtp'] = $otpvalue;
			$post['userId'] = $_SESSION['login_data']["userId"];

			$post = json_encode($post);



			$ch = curl_init(local_ip_url . api_version . '/verifyOtp');
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt(
				$ch,
				CURLOPT_HTTPHEADER,
				array(
					'Content-Type: application/json'

				)

			);

			$otpverify = json_decode(curl_exec($ch));

			if ($otpverify->statusCode == '200') {


				$_SESSION['sucessmessage'] = 'sucess';
				$_SESSION['registersucess'] = false;
				$_SESSION['phoneVerification'] = $otpverify->data->phoneVerification;

				$_SESSION['phoneVerified'] = $otpverify->data->phoneVerification;
				$_SESSION['login_data']['phoneVerification'] = $otpverify->data->phoneVerification;


				$updatelead = array(
					'username' => $_SESSION['login_data']['userName'],
					'phone' => $_SESSION['login_data']['phone'],
					'email' => $_SESSION['login_data']['email'],
					'city' => $_SESSION['login_data']['city'],
					'current_source_of_water' => $_SESSION['login_data']['water_source'],
					'current_lead_page' => "nlp",
					'business_id' => "1",
					'phone_verified' => true
				);
				$this->Userlead->updateLeadData($updatelead, $_SESSION['login_data']['phone']);


				redirect(base_url() . 'plan');

				$this->session->set_flashdata('wrongotpmessage', 'otp verify succesfull');

			} else

				if ($otpverify->message != 'sucess' && $otpverify->statusCode != '200') {
					$msg = 'Wrong OTP entered';
					$data['page'] = 'nlp';
					if ($_POST['otp_page'] == 'nlp_hindi') {
						$this->session->set_flashdata('wrongotpmessage', 'गलत ओटीपी दर्ज हुआ');
					}
					else{
					$this->session->set_flashdata('wrongotpmessage', 'Wrong OTP entered');
					}
					if ($_POST['otp_page'] == 'nlp_hindi') {
						redirect(base_url() . 'nlp_hindi');
					} else if ($_POST['otp_page'] == 'nlp_english') {
						redirect(base_url() . 'nlp_english');
					} else {
						redirect(base_url() . 'nlp');
					}

				}
		}
	}
	public function nlp_Hindi()
	{

		
		$data['citylist'] = cityList();
		$data['meta_title'] = "Livpure Smart सेवाओं को प्राप्त करने के लिए साइन अप करें मात्र 399 प्रति माह से शुरू";
		$data['meta_description'] = "Rent करें एक water purifier, plans शुरू होते हैं सिर्फ ₹399/month से। Livpure Smart देता है dependable RO water purifiers subscription के जरिए, आपके घर के लिए स्वच्छ और स्वस्थ पीने का पानी guarantee करता है। Sign up करें आज ही, हमसे call back पाएं।";
		//$_SESSION['nlp_hindi_page'] = true;
		$_SESSION['nlp_hindi'] = true;
		$_SESSION['utm_source'] = $_REQUEST['utm_source'];
		$_SESSION['utm_medium'] = $_REQUEST['utm_medium'];

		if ($_SESSION['registersucess'] == true && $_SESSION['phoneotp'] == false) {
			$_POST['phone'] = $_SESSION['login_data']['phone'];
			$_POST['userId'] = $_SESSION['login_data']['userId'];
			$post = json_encode($_POST);
			$ch = curl_init(local_ip_url . api_version . '/sendPhoneOtp');
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt(
				$ch,
				CURLOPT_HTTPHEADER,
				array(
					'Content-Type: application/json'
				)
			);
			$phoneotpresponse = json_decode(curl_exec($ch));
			$_SESSION['phoneotp'] = $phoneotpresponse->status;
		}
		if ($_REQUEST['rcode'] != "" && !isset($_SESSION['requestrefferalcode'])) {
			$_SESSION['requestrefferalcode'] = $_REQUEST['rcode'];
		}
		$id = '';
		if (isset($_REQUEST['id']) != '') {
			$id = base64_decode($_REQUEST['id']);
		} else {
			$id = 0;
		}
		$data['id'] = $id;
		$data['page'] = 'nlp_Hindi';
		$this->load->view('nlp_Hindi', $data);
	}
	public function nlp_English()
	{

		$data['citylist'] = cityList();
		$data['meta_title'] = "Subscribe to Livpure smart RO services starting @ ₹399/month";
		$data['meta_description'] = "Get a water purifier on rent with plans starting at just ₹399/month. Livpure Smart offers reliable RO water purifiers through subscription, ensuring clean and healthy drinking water for your home. Register today for a callback from us";
		//$_SESSION['nlp_hindi_page'] = true;
		$_SESSION['nlp_English'] = true;
		$_SESSION['utm_source'] = $_REQUEST['utm_source'];
		$_SESSION['utm_medium'] = $_REQUEST['utm_medium'];
		if ($_SESSION['registersucess'] == true && $_SESSION['phoneotp'] == false) {
			$_POST['phone'] = $_SESSION['login_data']['phone'];
			$_POST['userId'] = $_SESSION['login_data']['userId'];
			$post = json_encode($_POST);
			$ch = curl_init(local_ip_url . api_version . '/sendPhoneOtp');
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt(
				$ch,
				CURLOPT_HTTPHEADER,
				array(
					'Content-Type: application/json'
				)
			);
			$phoneotpresponse = json_decode(curl_exec($ch));
			$_SESSION['phoneotp'] = $phoneotpresponse->status;
		}
		if ($_REQUEST['rcode'] != "" && !isset($_SESSION['requestrefferalcode'])) {
			$_SESSION['requestrefferalcode'] = $_REQUEST['rcode'];
		}
		$id = '';
		if (isset($_REQUEST['id']) != '') {
			$id = base64_decode($_REQUEST['id']);
		} else {
			$id = 0;
		}
		$data['id'] = $id;

		$data['page'] = 'nlp_English';

		$this->load->view('nlp_English', $data);
	}
}