<script type="text/javascript">
	<?php if (isset($_SESSION['login_data']) && isset($_SESSION['login_data']['rd_su']) && $_SESSION['login_data']['rd_su'] === 'Y'  && ENV=='PROD') {
		$_SESSION['login_data']['rd_su'] = ''; ?>
	/*Sign up Event*/
	analytics.alias("<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>");

	analytics.identify("<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>", {
		"user_id": "<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>",
		"username": "<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>",
		"email": "<?= isset($_SESSION['login_data']['email']) ? $_SESSION['login_data']['email'] : '' ?>",
		"mobile": "<?= isset($_SESSION['login_data']['phone']) ? $_SESSION['login_data']['phone'] : '' ?>",
		"phone": "<?= isset($_SESSION['login_data']['phone']) ? $_SESSION['login_data']['phone'] : '' ?>",
		"firstName": "<?= isset($_SESSION['login_data']['firstName']) ? $_SESSION['login_data']['firstName'] : '' ?>",
		"lastName": "<?= isset($_SESSION['login_data']['lastName']) ? $_SESSION['login_data']['lastName'] : '' ?>",
		"referral_code": "<?= isset($_SESSION['login_data']['enteredReferralCode']) ? $_SESSION['login_data']['enteredReferralCode'] : '' ?>",
		"createdAt": "<?= isset($_SESSION['login_data']['registerDate']) ? $_SESSION['login_data']['registerDate'] : (new DateTime('UTC'))->format('Y-m-d\TH:i:s\Z')?>",
		"experience": "<?= isset($_SESSION['login_data']['experience']) ? $_SESSION['login_data']['experience'] : '' ?>",
		"signup_source": "web",
		"signup_method": "Regular",
		"has_paid": false,
		"uploaded_kyc": false
	});

	analytics.track('Signed Up', {
		"username": "<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>",
		"email": "<?= isset($_SESSION['login_data']['email']) ? $_SESSION['login_data']['email'] : '' ?>",
		"referral_code": "<?= isset($_SESSION['login_data']['enteredReferralCode']) ? $_SESSION['login_data']['enteredReferralCode'] : '' ?>",
		"firstName": "<?= isset($_SESSION['login_data']['firstName']) ? $_SESSION['login_data']['firstName'] : '' ?>",
		"lastName": "<?= isset($_SESSION['login_data']['lastName']) ? $_SESSION['login_data']['lastName'] : '' ?>",
		"phone": "<?= isset($_SESSION['login_data']['phone']) ? $_SESSION['login_data']['phone'] : '' ?>",
		"mobile": "<?= isset($_SESSION['login_data']['phone']) ? $_SESSION['login_data']['phone'] : '' ?>",
		"city": "<?= isset($_SESSION['login_data']['city']) ? $_SESSION['login_data']['city'] : '' ?>",
		"source": "<?= isset($_SESSION['login_data']['page_source']) ? $_SESSION['login_data']['page_source'] : '' ?>",
		"signup_method": "Regular",
		"experience": "<?= isset($_SESSION['login_data']['experience']) ? $_SESSION['login_data']['experience'] : '' ?>",
	});

	dataLayer.push({
		'event': 'formSubmitted',
		'formName': 'Sign Up Form - <?= $_SESSION['login_data']['page_source'] ?> Page'
	});
	<?php } 
	if (isset($_SESSION['login_data']) && isset($_SESSION['login_data']['rd_si']) && $_SESSION['login_data']['rd_si'] === 'Y') {
		$_SESSION['login_data']['rd_si'] = ''; ?>
		/*Sign in Event*/
		 if(typeof analytics != "undefined"){
			
		analytics.identify("<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>", {
			"user_id": "<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>",
			"email": "<?= isset($_SESSION['login_data']['email']) ? $_SESSION['login_data']['email'] : '' ?>",
			"username": "<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>",
			"has_paid": "<?= $_SESSION['login_data']['paymentCompleted'] == 1 ? "true" : "false" ?>",
			"uploaded_kyc": "<?= !!$_SESSION['login_data']['kycCompleted'] == 1 ? "true" : "false"  ?>",
			"experience": "<?= isset($_SESSION['login_data']['experience']) ? $_SESSION['login_data']['experience'] : '' ?>",
		});

		analytics.track('Signed In', {
			"username": "<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>",
			"type": "<?= isset($_SESSION['login_data']['loginType']) ? $_SESSION['login_data']['loginType'] : '' ?>",
			"experience": "<?= isset($_SESSION['login_data']['experience']) ? $_SESSION['login_data']['experience'] : '' ?>"

		});
	 }
	<?php } 
	if (isset($_SESSION['plan_order_data']) && isset($_SESSION['login_data']) && isset($_SESSION['login_data']['plan_subscribed']) && $_SESSION['login_data']['plan_subscribed'] === 'Y') 
	{
	$_SESSION['login_data']['plan_subscribed'] = ''; ?>
	/*Plan Subscribed*/
	if(typeof analytics != "undefined"){
	analytics.identify("<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>", {
		"plan_tier": "<?= isset($_SESSION['plan_order_data']['plan_name']) ? $_SESSION['plan_order_data']['plan_name'] : '' ?>",
		"plan_id": "<?= isset($_SESSION['plan_order_data']['plan_id']) ? $_SESSION['plan_order_data']['plan_id'] : '' ?>",
		"plan_duration": "<?= isset($_SESSION['plan_order_data']['plan_duration']) ? $_SESSION['plan_order_data']['plan_duration'] : '' ?>",
		"product_type": "<?= isset($_SESSION['login_data']['productType']) ? explode("-", $_SESSION['login_data']['productType'], 2)[0] : '' ?>",
		"subscribed_on": "<?= (new DateTime('UTC'))->format('Y-m-d\TH:i:s\Z') ?>"
	});
	
	analytics.track('Subscription Started', {
		"plan_tier": "<?= isset($_SESSION['plan_order_data']['plan_name']) ? $_SESSION['plan_order_data']['plan_name'] : '' ?>",
		"plan_id": "<?= isset($_SESSION['plan_order_data']['plan_id']) ? $_SESSION['plan_order_data']['plan_id'] : '' ?>",
		"plan_duration": "<?= isset($_SESSION['plan_order_data']['plan_duration']) ? $_SESSION['plan_order_data']['plan_duration'] : '' ?>",
		"order_id": "<?= isset($_SESSION['plan_order_data']['plan_order_id']) ? $_SESSION['plan_order_data']['plan_order_id'] : '' ?>",
		"orderId": "<?= isset($_SESSION['plan_order_data']['plan_order_id']) ? $_SESSION['plan_order_data']['plan_order_id'] : '' ?>",
		"litres": "<?= isset($_SESSION['plan_order_data']['plan_litres']) ? $_SESSION['plan_order_data']['plan_litres'] : '' ?>",
		"subscription_amount": "<?= isset($_SESSION['plan_order_data']['plan_amount_paid']) ? $_SESSION['plan_order_data']['plan_amount_paid'] : '' ?>",
		"product_type": "<?= isset($_SESSION['login_data']['productType']) ? explode("-", $_SESSION['login_data']['productType'], 2)[0] : '' ?>",
		"payment_method": 'Credit Card / QR Code / Wallet',
		"payment_type": "<?= isset($_SESSION['plan_order_data']['payment_type']) ? $_SESSION['plan_order_data']['payment_type'] : '' ?>"
	});
}

	<?php unset($_SESSION['plan_order_data']); } 
	if (isset($_SESSION['plan_order_data']) && isset($_SESSION['login_data']) && isset($_SESSION['login_data']['plan_recharged']) && $_SESSION['login_data']['plan_recharged'] === 'Y') {
	$_SESSION['login_data']['plan_recharged'] = ''; ?>
	/*Plan Recharged*/
	analytics.identify("<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>", {
		"plan_tier": "<?= isset($_SESSION['plan_order_data']['plan_name']) ? $_SESSION['plan_order_data']['plan_name'] : '' ?>",
		"plan_id": "<?= isset($_SESSION['plan_order_data']['plan_id']) ? $_SESSION['plan_order_data']['plan_id'] : '' ?>",
		"plan_duration": "<?= isset($_SESSION['plan_order_data']['plan_duration']) ? $_SESSION['plan_order_data']['plan_duration'] : ''  ?>",
		"last_recharge_made": "<?= (new DateTime('UTC'))->format('Y-m-d\TH:i:s\Z') ?>"
	});

	analytics.track('Subscription Recharged', {
		"plan_tier": "<?=isset($_SESSION['plan_order_data']['plan_name']) ? $_SESSION['plan_order_data']['plan_name'] : '' ?>",
		"plan_id": "<?=isset($_SESSION['plan_order_data']['plan_id']) ? $_SESSION['plan_order_data']['plan_id'] : '' ?>",
		"plan_duration": "<?= isset($_SESSION['plan_order_data']['plan_duration']) ? $_SESSION['plan_order_data']['plan_duration'] : ''  ?>",
		"order_id": "<?=isset($_SESSION['plan_order_data']['plan_order_id']) ? $_SESSION['plan_order_data']['plan_order_id'] : ''  ?>",
		"orderId": "<?=isset($_SESSION['plan_order_data']['plan_order_id']) ? $_SESSION['plan_order_data']['plan_order_id'] : '' ?>",
		"litres": "<?= isset($_SESSION['plan_order_data']['plan_litres']) ? $_SESSION['plan_order_data']['plan_litres'] : '' ?>",
		"recharge_amount": "<?=isset($_SESSION['plan_order_data']['plan_amount_paid']) ? $_SESSION['plan_order_data']['plan_amount_paid'] : '' ?>",
		"payment_method": 'Credit Card / QR Code / Wallet'
	});
	<?php unset($_SESSION['plan_order_data']); }
	if (isset($_SESSION['plan_order_data']) && isset($_SESSION['login_data']) && isset($_SESSION['login_data']['plan_upgraded']) && $_SESSION['login_data']['plan_upgraded'] === 'Y') {
	$_SESSION['login_data']['plan_upgraded'] = ''; ?>
	/*Plan Upgraded*/
	analytics.identify("<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>", {
		"plan_tier": "<?= isset($_SESSION['plan_order_data']['plan_name']) ? $_SESSION['plan_order_data']['plan_name'] : '' ?>",
		"plan_id": "<?= isset($_SESSION['plan_order_data']['plan_id']) ? $_SESSION['plan_order_data']['plan_id'] : '' ?>",
		"plan_duration": "<?= isset($_SESSION['plan_order_data']['plan_duration']) ? $_SESSION['plan_order_data']['plan_duration'] : '' ?>",
		"last_recharge_made": "<?= (new DateTime('UTC'))->format('Y-m-d\TH:i:s\Z') ?>"
	});

	analytics.track('Subscription Upgraded', {
		"plan_tier": "<?= isset($_SESSION['plan_order_data']['plan_name']) ? $_SESSION['plan_order_data']['plan_name'] : '' ?>",
		"plan_id": "<?= isset($_SESSION['plan_order_data']['plan_id']) ? $_SESSION['plan_order_data']['plan_id'] : '' ?>",
		"plan_duration": "<?= isset($_SESSION['plan_order_data']['plan_duration']) ? $_SESSION['plan_order_data']['plan_duration'] : '' ?>",
		"order_id": "<?= isset($_SESSION['plan_order_data']['plan_order_id']) ? $_SESSION['plan_order_data']['plan_order_id'] : '' ?>",
		"orderId": "<?= isset($_SESSION['plan_order_data']['plan_order_id']) ? $_SESSION['plan_order_data']['plan_order_id'] : '' ?>",
		"litres": "<?= isset($_SESSION['plan_order_data']['plan_litres']) ? $_SESSION['plan_order_data']['plan_litres'] : '' ?>",
		"recharge_amount": "<?= isset($_SESSION['plan_order_data']['plan_amount_paid']) ? $_SESSION['plan_order_data']['plan_amount_paid'] : '' ?>",
		"previous_plan_tier": "<?= isset($_SESSION['plan_order_data']['old_plan_name']) ? $_SESSION['plan_order_data']['old_plan_name'] : '' ?>",
		"previous_plan_id": "<?= isset($_SESSION['plan_order_data']['old_plan_id']) ? $_SESSION['plan_order_data']['old_plan_id'] : '' ?>",
		"payment_method": 'Credit Card / QR Code / Wallet'
	});
	<?php unset($_SESSION['plan_order_data']); }
	if (isset($_SESSION['plan_order_data']) && isset($_SESSION['login_data']) && isset($_SESSION['login_data']['plan_downgraded']) && $_SESSION['login_data']['plan_downgraded'] === 'Y') {
		$_SESSION['login_data']['plan_downgraded'] = ''; ?>
	/*Plan downgraded*/
	analytics.identify("<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>", {
		"plan_tier": "<?= isset($_SESSION['plan_order_data']['plan_name']) ? $_SESSION['plan_order_data']['plan_name'] : '' ?>",
		"plan_id": "<?= isset($_SESSION['plan_order_data']['plan_id']) ? $_SESSION['plan_order_data']['plan_id'] : '' ?>",
		"plan_duration": "<?= isset($_SESSION['plan_order_data']['plan_duration']) ? $_SESSION['plan_order_data']['plan_duration'] : '' ?>",
		"last_recharge_made": "<?= (new DateTime('UTC'))->format('Y-m-d\TH:i:s\Z') ?>"
	});

	analytics.track('Subscription Downgraded', {
		"plan_tier": "<?= isset($_SESSION['plan_order_data']['plan_name']) ? $_SESSION['plan_order_data']['plan_name'] : '' ?>",
		"plan_id": "<?= isset($_SESSION['plan_order_data']['plan_id']) ? $_SESSION['plan_order_data']['plan_id'] : '' ?>",
		"plan_duration": "<?= isset($_SESSION['plan_order_data']['plan_duration']) ? $_SESSION['plan_order_data']['plan_duration'] : '' ?>",
		"order_id": "<?= isset($_SESSION['plan_order_data']['plan_order_id']) ? $_SESSION['plan_order_data']['plan_order_id'] : '' ?>",
		"orderId": "<?= isset($_SESSION['plan_order_data']['plan_order_id']) ? $_SESSION['plan_order_data']['plan_order_id'] : '' ?>",
		"litres": "<?= isset($_SESSION['plan_order_data']['plan_litres']) ? $_SESSION['plan_order_data']['plan_litres'] : '' ?>",
		"recharge_amount": "<?= isset($_SESSION['plan_order_data']['plan_amount_paid']) ? $_SESSION['plan_order_data']['plan_amount_paid'] : '' ?>",
		"previous_plan_tier": "<?= isset($_SESSION['plan_order_data']['old_plan_name']) ? $_SESSION['plan_order_data']['old_plan_name'] : '' ?>",
		"previous_plan_id": "<?= isset($_SESSION['plan_order_data']['old_plan_id']) ? $_SESSION['plan_order_data']['old_plan_id'] : '' ?>",
		"payment_method": 'Credit Card / QR Code / Wallet'
	});
	<?php unset($_SESSION['plan_order_data']); } 
	if (isset($_SESSION['plan_order_data']) && isset($_SESSION['login_data']) && isset($_SESSION['login_data']['added_litres']) && $_SESSION['login_data']['added_litres'] === 'Y') {
	$_SESSION['login_data']['added_litres'] = ''; ?>
	/*Added litres*/
	analytics.track('Added Litres', {
		"order_id": "<?= isset($_SESSION['plan_order_data']['plan_order_id']) ? $_SESSION['plan_order_data']['plan_order_id'] : '' ?>",
		"orderId": "<?= isset($_SESSION['plan_order_data']['plan_order_id']) ? $_SESSION['plan_order_data']['plan_order_id'] : '' ?>",
		"litres": "<?= isset($_SESSION['plan_order_data']['added_litres']) ? $_SESSION['plan_order_data']['added_litres'] : '' ?>",
		"recharge_amount": "<?= isset($_SESSION['plan_order_data']['recharge_amount']) ? $_SESSION['plan_order_data']['recharge_amount'] : '' ?>",
		"payment_method": 'Credit Card / QR Code / Wallet'
	});

	<?php unset($_SESSION['plan_order_data']); } 
	if(ENV=='PROD'){?>
	analytics.identify("<?= isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>", {
		"recharge_due_date": "<?= isset($_SESSION['login_data']['validityTill']) ? $_SESSION['login_data']['validityTill'] : '' ?>"
	});
	<?php } ?>
	$(document).ready(function () {
		$(".page-hash-link").on('click', function (event) {
			(event.currentTarget.getAttribute('data-scroll') === '#how-works') ? analytics.track('Clicked How it Works') : analytics.track('Clicked Plans');
		});
	});
</script>
