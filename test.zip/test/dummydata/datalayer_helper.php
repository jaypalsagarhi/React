<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
//customer Function

 function signUpPush()
	{
 
        $datauserid=$_SESSION['login_data']['userId'];

        $dataname=base64_encode($_SESSION['login_data']['userName']);

        $dataemail=base64_encode($_SESSION['login_data']['email']);
        $datacity=$_SESSION['login_data']['city'];
        $dataphone =base64_encode($_SESSION['login_data']['phone']);
        $datareferalcode =  $_SESSION['login_data']['referralCode'];

      echo "<script language=\"javascript\">
  
      window.dataLayer = window.dataLayer || [];
  
      dataLayer.push({
          'event': 'signed_up',
          'userId':  '$datauserid',
          'userName': '$dataname',   
          'userEmail': '$dataemail',
          'city': '$datacity',
          'mobileNumber': '$dataphone',  
          'referralCode':'$datareferalcode'
        });
        
    
      </script>";

      return true;

    
	}

    function loginPush(){
  
        $datauserid=$_SESSION['login_data']['userId'];
        $dataemail=base64_encode($_SESSION['login_data']['email']);

    
        if($_SESSION['username'] ==  $_SESSION['login_data']['email']){
          $username='Email';
        }else{

          $username='Phone';
        }

        echo "<script language=\"javascript\">
  
        window.dataLayer = window.dataLayer || [];
    
        dataLayer.push({
            'event': 'logged_in',
            'userId': '$datauserid',
            'userEmail': '$dataemail',          
            'loginType': '$username'
          });
          
        
        
        </script>";
  
        return true;

    }

function ekycPush(){

  $pageurl=$_SERVER['REQUEST_URI'];
  $transaction_id=substr(time(), 2, 8);
  $pricepermonth=$_SESSION['selected_plan']["selectedPlanId"].'_'.$_SESSION['selected_plan']["selectedPlanDuration"];
  $userId = ($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '';

  if ($_SESSION['login_data']['paymentCompleted'] == false) { 
    if($_SESSION['selected_plan']["selectedPlanDuration"]=="1"){
      $amount =$_SESSION['Recharge_installation_amount'];
    }
  }else{
    $amount = $_SESSION['Recharge_amount'];
  }
  $planname=$_SESSION['selected_plan']["selectedPlanName"];
  $Recharge_amount = $_SESSION['Recharge_amount'];
  $userType = isset($_SESSION['login_data']) ? 'signin' : 'guest';
  $purchase_type = ($_SESSION['check_first_payment'] == 'new') ? "New Subscription":"Subscription Renewal";//'RO Subscription Started',

  echo "<script language=\"javascript\">
    window.dataLayer = window.dataLayer || [];    
    dataLayer.push({
      ecommerce: null
    }); 
    // Clear the previous ecommerce object.

    dataLayer.push({
      'event': 'purchase',
      'page_url':' $pageurl',
      'ecommerce': {
        'transaction_id': '$transaction_id',
        'affiliation': 'Livpure Smart Online Store',
        'value': '$amount',
        'tax': '0.00',
        'shipping': '0.00',
        'currency': 'INR',
        'coupon': 'DISCOUNT_SALE',
        'payment_type':'Credit Card / QR Code / Wallet',
        'payment_type_detail':'',
        'emi_value':'',
        'emi_duration':'',
        'purchase_type':'$purchase_type',
        'items': [{
          'item_name': 'Live Pure Smart - Bolt/Envy/premium',
          'item_id': '$pricepermonth', 
          'price': $Recharge_amount,
          'item_brand': 'Livpure Smart RO',
          'item_category': 'RO Subscription',
          'item_variant': '$planname',
          'quantity': 1
        }]
      }
    });
    dataLayer.push({
      event: 'set_user_id',
      user_id: $userId,
      event_fired: 'purchase',
      user_type: '$userType'
    });
  </script>"; 
  return true;
}

function reviewPush(){
  $pageurl=$_SERVER['REQUEST_URI'];
  $planname=$_SESSION['selected_plan']["selectedPlanName"];
  $selectedPlanDuration = $_SESSION['selected_plan']["selectedPlanDuration"];
  $pricepermonth=$_SESSION['selected_plan']["selectedPlanId"].'_'.$selectedPlanDuration;
  $selectedPlanBaseAmount = $_SESSION['selected_plan']["selectedPlanBaseAmount"];
  if ($_SESSION['login_data']['paymentCompleted'] == false){ 
    $amount =$_SESSION['Recharge_installation_amount'];
  }else{
    $amount = $_SESSION['Recharge_amount'];
  }
  $Recharge_amount = $_SESSION['Recharge_amount'];
  $userId = ($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '';
  $userType = isset($_SESSION['login_data']) ? 'signin' : 'guest';

  echo "<script language=\"javascript\">
    window.dataLayer = window.dataLayer || [];  
    dataLayer.push({
     ecommerce: null
    });  // Clear the previous ecommerce object.

    dataLayer.push({
      'event': 'order_review',
      'page_url': '$pageurl',
      'value':  $amount,
      'emi_duration': $selectedPlanDuration,
      'ecommerce': {
        'items': [{
          'item_name': 'Live Pure Smart - Bolt/Envy',
          'item_id': '$pricepermonth', 
          'price':$Recharge_amount,
          'item_brand': 'Livpure Smart RO',
          'item_category': 'RO Subscription',
          'item_variant': '$planname',
          'quantity': '1'
        }]
      }
    });
    dataLayer.push({
      event: 'set_user_id',
      user_id: $userId,
      event_fired: 'order_review',
      user_type: '$userType'
    });
  </script>"; 
  return true;
}

function addressPush(){

  $userId = ($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '';
  $pageurl=$_SERVER['REQUEST_URI'];
  $planname=$_SESSION['selected_plan']["selectedPlanName"];
  $selectedPlanDuration = $_SESSION['selected_plan']["selectedPlanDuration"];
  $pricepermonth=$_SESSION['selected_plan']["selectedPlanId"].'_'.$selectedPlanDuration;
  if ($_SESSION['login_data']['paymentCompleted'] == false){ 
    $amount = $_SESSION["selected_plan"]["amount"]+'1499';
  }else{
    $amount =  $_SESSION["selected_plan"]["amount"];
  }
  $price = $_SESSION["selected_plan"]["amount"];
  $userType = isset($_SESSION['login_data']) ? 'signin' : 'guest';

  echo "<script language=\"javascript\">
    window.dataLayer = window.dataLayer || [];  
    /**
    * A function to handle a click on a checkout button.
    */
    dataLayer.push({ 
      ecommerce: null
    });  // Clear the previous ecommerce object.

    dataLayer.push({
      'event': 'begin_checkout',
      'value':  $amount,
      'emi_duration':$selectedPlanDuration,
      'currency': 'INR',
      'page_url':'$pageurl',
      'ecommerce': {
        'items': [{
          'item_name': 'Live Pure Smart - Bolt/Envy',
          'item_id': '$pricepermonth', 
          'price': $price,
          'item_brand': 'Livpure Smart RO',
          'item_category': 'RO Subscription',
          'item_variant': '$planname',
          'quantity': '1'
        }]
      }
    });
    dataLayer.push({
      event: 'set_user_id',
      user_id: $userId,
      event_fired: 'begin_checkout',
      user_type: '$userType'
    });
  </script>"; 
return true;
}

?>
