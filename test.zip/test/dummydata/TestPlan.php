<?php defined('BASEPATH') or exit ('No direct script access allowed');
class Plan extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('userlead'); //lms changes added on 08/06/2020
		$this->redis = new \CI_Predis\Redis(['serverName' => SERVERNAME]);
		$this->load->helper('crypto_helper');
	}

	public function index($returntype = false)
	{
		$continue_plan = false;

		if (isset ($_SERVER['HTTP_REFERER']) && !empty ($_SERVER['HTTP_REFERER'])) {
			$serverpath = explode('/', str_replace('?' . parse_url($_SERVER['HTTP_REFERER'])['query'], '', $_SERVER['HTTP_REFERER']));
			if (is_array($serverpath) && array_intersect(['nlp', 'newnlp', 'nlp_newcity', 'plan', 'review', 'thanks', 'premium', 'userplan', 'dashboard', 'updateuser', 'History'], $serverpath)) {
				$continue_plan = true;
			}
		}

		if (!$returntype && ((isset ($_SESSION['login_data']) && !((int) $_SESSION['login_data']['phoneVerification'])) && !$continue_plan)) {
			redirect(base_url('auth'));
		}

		if ($this->uri->segment(1) == 'unltd') {
			$data['meta_title'] = "Unlimited Water Purifier Monthly Subscription Plans | Livpure";
			$data['meta_description'] = "Unlimited Subscription - Enjoy limitless RO water convenience.";
			$data['meta_keywords'] = 'water purifier online price,ro price,ro purifier price,water purifier cost,water ro price,water purifier price,ro water purifier price';

		} else {
			$data['meta_title'] = "Water Purifier Subscription Plan Prices of Livpure Smart";
			$data['meta_description'] = "RO Subscription Plans - Enjoy clean water affordably with Livpure Smart's subscription.";
			$data['meta_keywords'] = 'water purifier online price,ro price,ro purifier price,water purifier cost,water ro price,water purifier price,ro water purifier price';
		}
		$data['oldcitylist'] = oldCityList();
		$data['newCityList'] = newCityList();
		$all_cities = array_merge($data['oldcitylist'], $data['newCityList']);
		$getCity = ($this->input->get('city')) ? base64_decode(trim($this->input->get('city'))) : null;
		if ($getCity && in_array($getCity, $all_cities) && (isset ($_SESSION['login_data']) && !empty ($_SESSION['login_data']))) {
			cityChangeApi(local_ip_url . 'v4/changeCity', ['city' => $getCity]);
			$_SESSION['login_data']['city'] = $getCity;
		}
		if (isset ($_SESSION['login_data']['stoppedService']) && $_SESSION['login_data']['stoppedService'] == 1) {
			cityChangeApi(local_ip_url . 'v4/changeCity', ['city' => $getCity]);
			$_SESSION['login_data']['city'] = $getCity;
		}
		if (isset ($_SESSION['login_data']) && !empty ($_SESSION['login_data'])) {
			if (isset ($_SESSION['login_data']['city']) && empty ($_SESSION['login_data']['city'])) {
				$getCity = 'Delhi NCR';
				cityChangeApi(local_ip_url . 'v4/changeCity', ['city' => $getCity]);
				$_SESSION['login_data']['city'] = $getCity;
			}
			$getCity = $_SESSION['login_data']['city'];
		}

		$_SESSION['deposit'] = 'true';
		if (isset ($_REQUEST['planname']) != '') {
			$planname = base64_decode($_REQUEST['planname']);
		}
		$_SESSION['planname'] = $planname;
		$id = 0;
		if (isset ($_REQUEST['id']) != '') {
			$id = base64_decode($_REQUEST['id']);
		}
		$data['id'] = $id;
		if ((isset ($_SESSION['login_data']['paymentCompleted']) && $_SESSION['login_data']['paymentCompleted'] == "true")) {
			$requestParams = array(
				'city' => $_SESSION['login_data']['city'],
				'Authorization' => $_SESSION['token']
			);
			//echo 'beforeapi call';
			$url = local_ip_url . api_version . '/cityPlanDetails';
			$result = json_decode(CallAPI('GET', $url, $requestParams));
			$depositdetails = $result->data->activeplan;
			$_SESSION['login_data']['userPlanModel'] = $result->data->modelType;
			$data['deposit'] = array();
			if (isset ($depositdetails) && count((array) $depositdetails)) {
				$data['deposit'] = $result->data->activeplan;
			} else {
				$data['deposit'] = [];
			}

			foreach ($data['deposit'] as $row) {
				$_SESSION['deposit_amount'] = $row->depositAmount;
			}
			$newplanresult = array();
			if ($result->statusCode == 200) {
				$data['planError'] = "";
				//$newplanresult = $result->data->boltPlans;
				$planResult = [];
				$alkalinePlans = [];
				$stealthPlans = [];
				if (!isset ($result->data->allBoltPlans)) {
					$result->data->allBoltPlans = [];
				}
				if (!isset ($result->data->boltPlans)) {
					$result->data->boltPlans = [];
				}
				foreach ($result->data->allBoltPlans as $t_key1 => $t_planResult1) {
					if (!array_key_exists($t_planResult1->_id, $planResult)) {
						$t_planResult1->dpAmount = deposit($t_planResult1->depositAmount);
						array_map('encryptprice', $t_planResult1->price);
						$planResult[$t_planResult1->_id] = $t_planResult1;
					}
				}
				foreach ($result->data->boltPlans as $t_key => $t_planResult) {
					if (!array_key_exists($t_planResult1->_id, $planResult)) {
						$t_planResult1->dpAmount = deposit($t_planResult1->depositAmount);
						array_map('encryptprice', $t_planResult->price);
						$planResult[$t_planResult->_id] = $t_planResult;
					}
				}
				foreach ($result->data->alkalinePlans as $t_key1 => $alkalinePlan) {
					if (!array_key_exists($alkalinePlan->_id, $alkalinePlans)) {
						$alkalinePlan->dpAmount = deposit($alkalinePlan->depositAmount);
						array_map('encryptprice', $alkalinePlan->price);
						$alkalinePlans[$alkalinePlan->_id] = $alkalinePlan;
					}
				}
				foreach ($result->data->stealthPlans as $t_key1 => $stealthPlan) {
					if (!array_key_exists($stealthPlan->_id, $stealthPlans)) {
						$stealthPlan->dpAmount = deposit($stealthPlan->depositAmount);
						array_map('encryptprice', $stealthPlan->price);
						$stealthPlans[$stealthPlan->_id] = $stealthPlan;
					}
				}
				// pr($result->data->boltCopperPlan);
				foreach ($result->data->boltCopperPlan as $t_key1 => $boltCopperPlan) {
					if (!array_key_exists($boltCopperPlan->_id, $boltCopperPlan)) {
						$boltCopperPlan->dpAmount = deposit($boltCopperPlan->depositAmount);
						array_map('encryptprice', $boltCopperPlan->price);
						$boltCopperPlans[$boltCopperPlan->_id] = $boltCopperPlan;
					}
				}
				$newplanresult = array_values($planResult);
				$alkalinePlans = array_values($alkalinePlans);
				$stealthPlans = array_values($stealthPlans);
				$data['boltMinilizer'] = array_values($planResult); /// popup data for bolt after pay done
				$data['boltCopperPlan'] = array_values($boltCopperPlans);

				//echo '<pre>--------';print_r($stealthPlans);die;
			} else {
				$newplanresult[] = array();
				$planResult = array();
				$alkalinePlans = array();
				$stealthPlans = array();
				$data['planError'] = "There is some issue while processing this request. Please try later.";
				$this->session->set_flashdata('plans_error', $data['planError']);
			}
			$zingerplanResult = [];
			$zingertankResult = [];

			if ($result->data->modelType == 'Zinger' && $result->data->activeplan->active != 'no') {
				$zingerplanResult[] = $result->data->activeplan;
			}
			if ($result->data->modelType == 'Zinger' && $result->data->activeplan->active == 'no') {
				$zingerplanResult = $result->data->zingerPlan;
			}
			/* added for after login zinger popup data start  06-December-2023 */
			if ($result->data->modelType == 'all' && $result->data->activeplan->productType == 'ZINGERHOTWAAS') {
				$zingerplanResult[] = $result->data->activeplan;
			}
			/* added for after login zinger popup data end */
			if ($result->data->modelType == 'Zinger_tank') {
				$zingertankPlans[] = $result->data->activeplan;
			} else {
				$zingertankPlans = $result->data->zingerTankPlan;
			}

			$data['alkalinePlans'] = json_encode($alkalinePlans);
			$data['stealthPlans'] = json_encode($stealthPlans);
			$data['zingertankPlans'] = json_encode($zingertankPlans);
			$data['unlimitedPlans'] = json_encode($zingerplanResult);
			$data['plans'] = json_encode($newplanresult);

			if (isset ($result->data->activeplan) && !empty ($result->data->activeplan)) {
				$data['plans'] = json_encode($result->data->activeplan);
				$planResult = [];
				$planResult[$result->data->activeplan->_id] = $result->data->activeplan;
			}

		} else {
			$url = local_ip_url . api_version . '/cityPlanDetails';
			if (isset ($_SESSION['login_data']) && !empty ($_SESSION['login_data'])) {
				$header = array(
					'Content-Type: application/json',
					'Authorization: ' . $_SESSION['login_data']['token']
				);

			} else if ($getCity) {
				$url = local_ip_url . api_version . '/cityPlanDetails?city=' . rawurlencode($getCity);
				$header = array("Content-Type: application/json");
			}
			$result = json_decode(GETPLANAPI($url, $header));
			$depositdetails = $result->data->boltPlans;
			$data['deposit'] = array();

			if (isset ($depositdetails)) {
				if (count($depositdetails) > 0) {
					$data['deposit'] = $result->data->allBoltPlans;
				} else {
					$data['deposit'] = [];
				}
			}
			foreach ($data['deposit'] as $row) {
				$_SESSION['deposit_amount'] = $row->depositAmount;
			}

			$_SESSION['installation_amount'] = $result->data->boltPlans[0]->price[3]->installation_amount;
			if ($result->statusCode == 200) {
				$data['planError'] = "";
				$planResult = [];
				$alkalinePlans = [];
				$stealthPlans = [];
				if (!isset ($result->data->allBoltPlans)) {
					$result->data->allBoltPlans = [];
				}
				if (!isset ($result->data->boltPlans)) {
					$result->data->boltPlans = [];
				}
				foreach ($result->data->allBoltPlans as $t_key2 => $t_planResult2) {
					if (!array_key_exists($t_planResult2->_id, $planResult)) {
						$t_planResult2->dpAmount = deposit($t_planResult2->depositAmount);
						array_map('encryptprice', $t_planResult2->price);
						$planResult[$t_planResult2->_id] = $t_planResult2;
						$planResult[$t_planResult2->_id]->show = 'N';
						if ($t_planResult2->planName == 'Silver') {
							$planResult[$t_planResult2->_id]->show = 'Y';
						}
					}
				}
				if (empty ($planResult)) {
					foreach ($result->data->boltPlans as $t_key2 => $t_planResult2) {
						if (!array_key_exists($t_planResult2->_id, $planResult)) {
							$t_planResult2->dpAmount = deposit($t_planResult2->depositAmount);
							array_map('encryptprice', $t_planResult2->price);
							$planResult[$t_planResult2->_id] = $t_planResult2;
							$planResult[$t_planResult2->_id]->show = 'N';
							if ($t_planResult2->planName == 'Silver') {
								$planResult[$t_planResult2->_id]->show = 'Y';
							}
						}
					}
				}
				$data['boltMinilizer'] = array_values($planResult);
				
				if (BOLTCUWAAS) {
					foreach ($result->data->boltCopperPlan as $t_key2 => $boltCopperPlan) {
						if (!array_key_exists($boltCopperPlan->_id, $planResult)) {
							$boltCopperPlan->dpAmount = deposit($boltCopperPlan->depositAmount);
							array_map('encryptprice', $boltCopperPlan->price);
							$planResult[$boltCopperPlan->_id] = $boltCopperPlan;
							$planResult[$boltCopperPlan->_id]->show = 'N';
							if ($boltCopperPlan->planName == 'Silver') {
								$planResult[$boltCopperPlan->_id]->show = 'Y';
							}
						}
					}
				}
				$data['boltCopperPlan'] = !empty ($result->data->boltCopperPlan) ? array_values($result->data->boltCopperPlan) : array();

				if (ALKALINE) {
					foreach ($result->data->alkalinePlans as $t_key1 => $alkalinePlan) {
						if (!array_key_exists($alkalinePlan->_id, $planResult)) {
							$alkalinePlan->dpAmount = deposit($alkalinePlan->depositAmount);
							array_map('encryptprice', $alkalinePlan->price);
							$planResult[$alkalinePlan->_id] = $alkalinePlan;
							$planResult[$alkalinePlan->_id]->show = 'Y';
						}
					}
				}

				if (UTS) {
					foreach ($result->data->stealthPlans as $t_key1 => $stealthPlan) {
						if (!array_key_exists($stealthPlan->_id, $planResult)) {
							$stealthPlan->dpAmount = deposit($stealthPlan->depositAmount);
							array_map('encryptprice', $stealthPlan->price);
							$planResult[$stealthPlan->_id] = $stealthPlan;
							$planResult[$stealthPlan->_id]->show = 'Y';
						}
					}
				}

				foreach ($result->data->zingerPlan as $t_key1 => $zingerPlan) {
					if (!array_key_exists($zingerPlan->_id, $planResult)) {
						$zingerPlan->dpAmount = deposit($zingerPlan->depositAmount);
						array_map('encryptprice', $zingerPlan->price);
						$planResult[$zingerPlan->_id] = $zingerPlan;
						$planResult[$zingerPlan->_id]->show = 'Y';
					}
				}

				$deposit = array_column($planResult, 'depositAmount');

				array_multisort($deposit, $planResult);
				$zingerplanResult = $result->data->zingerPlan;
				$zingertankResult = $result->data->zingerTankPlans;
				$stealthPlans = $result->data->stealthPlans;  /// sepeate
				$alkalinePlans = $result->data->alkalinePlans;

				$planResultNew['data'] = $result->data->boltPlans;
			} else {
				$planResult = array();
				$zingerplanResult = array();
				$zingertankResult = array();
				$data['planError'] = "There is some issue while processing this request. Please try later.";
				$this->session->set_flashdata('plans_error', $data['planError']);
			}
			$data['unlimitedPlans'] = json_encode($zingerplanResult);
			$data['zingertankPlans'] = json_encode($zingertankResult);
			$data['alkalinePlans'] = json_encode(array_values($alkalinePlans));
			$data['stealthPlans'] = json_encode(array_values($stealthPlans));

			$data['plans'] = json_encode(array_values($planResult));
			$boldCoperData = !empty ((array) $boltCopperPlan) ? array_values((array) $boltCopperPlan) : array();
			$data['boltCopper'] = json_encode($boldCoperData);

		}
		// pr($data['boltCopper'],1);
		$data['selected_city'] = $getCity;
		$_SESSION['user_plan_city'] = $getCity;
		$data['page'] = 'plan';
		// $this->load->view('plan', $data);
		if (!$returntype) {
			$this->load->view('plan', $data);
		} else {
			echo json_encode(['plans' => array_values($planResult), 'boltMinilizer' => $data['boltMinilizer'], 'unlimitedPlans' => $zingerplanResult, 'alkalinePlans' => $alkalinePlans, 'stealthPlans' => $stealthPlans, 'zingertankPlans' => $zingertankResult, 'boltCopperPlan' => $data['boltCopperPlan']]);
		}
	}

	public function installationAddress()
	{
		$userId = (int) ($_SESSION['login_data']['userId']);
		$reminder = substr($userId, -1);

		//added by yashwanth to check subscription active or not on 15/05/2020;
		$subData['subscriptionDetails'] = array();
		$url = local_ip_url . 'getRechargeHistory';
		if ($userId > 0) {
			$Data1['userId'] = $_SESSION['login_data']['userId'];
			$subscriptionDetails = json_decode(CallAPI('POST', $url, $Data1));
		}

		if (isset ($subscriptionDetails->rechargeDetails)) {
			if (count($subscriptionDetails->rechargeDetails) > 0) {
				$subData['subscriptionDetails'] = $subscriptionDetails->rechargeDetails;
			} else {
				$subData['subscriptionDetails'] = [];
			}
		}
		if (
			!empty ($subData['subscriptionDetails'][0]->subscription) &&
			$subData['subscriptionDetails'][0]->subscription == true &&
			array_key_exists(
				"subscriptionId",
				$subData['subscriptionDetails'][0]
			)
		) {
			$_SESSION['subscriptionActive'] = true;
			$_SESSION['emandate'] = false;
			$_SESSION['subscriptionActiveId'] = $subData['subscriptionDetails'][0]->subscriptionId;
		} else if (
			!empty ($subData['subscriptionDetails'][0]->emandate) &&
			$subData['subscriptionDetails'][0]->emandate == true &&
			array_key_exists(
				"emandateId",
				$subData['subscriptionDetails'][0]
			)
		) {
			$_SESSION['subscriptionActive'] = true;
			$_SESSION['emandate'] = true;
			$_SESSION['subscriptionActiveId'] = $subData['subscriptionDetails'][0]->emandateId;
			$_SESSION['emandateCustId'] = $subData['subscriptionDetails'][0]->emandateCustId;
		} //added by yashwanth on 08/10/2020
		else {
			$_SESSION['subscriptionActive'] = false;
			$_SESSION['emandate'] = false;
			$_SESSION['subscriptionActiveId'] = '';
		}
		//end

		if (isset ($_SESSION['login_data'])) {
			//Update lead to master
			$addLead = $this->userlead->addLead($userId); //lms changes added on 08/06/2020;
			if (isset ($_SESSION['login_data']['pincode'])) {
				$_SESSION['topupFlag'] = "N";
				if ($_SESSION['subscriptionActive'] == 1) {
					if ($_SESSION['emandate'] == true && $_SESSION['login_data']['emiStatus'] != 'pending') {
						$this->updateSubsPlanDetails();
					} // only for emandate
					else {
						redirect(base_url() . 'userplan');
					}
				} else if ($_SESSION['login_data']['paymentCompleted'] == false) {
					if ($_SESSION['login_data']['city'] == $_SESSION['selectedcity']) {
						redirect(base_url() . 'review');
					} else {
						redirect(base_url() . 'address');
					}
				} else {
					redirect(base_url() . 'review');
				}
			} else {
				redirect(base_url() . 'address');
			}
		} else {
			redirect(base_url() . 'auth');
		}
	}

	public function updateSubsPlanDetails()
	{

		$userId = (int) ($_SESSION['login_data']['userId']);
		$planData['userId'] = $_SESSION['login_data']['userId'];
		$planData['customerId'] = $_SESSION['emandateCustId'];
		$planData['planId'] = $_SESSION['selected_plan']["selectedPlanId"];
		$planData['planName'] = $_SESSION["selected_plan"]["selectedPlanName"];
		$planData['duration'] = $_SESSION['selected_plan']["selectedPlanDuration"];
		$planData['tokenId'] = $_SESSION['subscriptionActiveId'];

		$url = local_ip_url . 'payment/chargeAtWillPlanModifiy';
		// $url = 'http://localhost:8080/payment/chargeAtWillPlanModifiy';
		$planUpdateDetails = json_decode(CallAPI('POST', $url, $planData));
		if ($planUpdateDetails->success) {
			if (
				$_SESSION['selected_plan']["selectedPlanDuration"] == '1'
				&& $_SESSION['subscriptionActive'] == 1
			) {
				$this->session->set_flashdata('message', "<p class='center'><b>You have successfully Updated the Plan. It will Applicable from Next Month</b></p>");
				redirect(base_url() . 'userplan');
			} else {
				redirect(base_url() . 'review');
			}
		} else {
			print_r('Some Error has beed occured..!!! PLease try after some time');
			redirect(base_url() . 'plan');
		}
	}

	/*Top Up*/
	public function addliters()
	{
		$requestParams = array(
			'allPlans' => "false"
		);

		$url = local_ip_url . api_version . '/planDetails';
		$planResult = json_decode(CallAPI('GET', $url, $requestParams));

		$topup = false;
		if ($planResult->status == true) {
			$data['currentPlan'] = $planResult->data->plans[0];
			$Data['userId'] = $_SESSION['login_data']['userId'];
			$url = local_ip_url . 'getDashboardDetails';
			$dashboardResult = json_decode(CallAPI('POST', $url, $Data));
			$topup = empty ($dashboardResult->dashboardDetails->message->isTopUpAllowed) ? false : $dashboardResult->dashboardDetails->message->isTopUpAllowed;
			// $topup = true;
			$data['liters'] = ["10", "50", "75", "100"];
			// $data['liters'] = json_encode($liters);
		}

		$requestParams = array(
			'allPlans' => "true",
		);

		$url = local_ip_url . api_version . '/planDetails';
		$upgradeplan = json_decode(CallAPI('GET', $url, $requestParams));
		$updateplan = $upgradeplan->data->plans;
		$data['plandetails'] = array();

		if (isset ($updateplan)) {
			if (count($updateplan) > 0) {
				$data['plandetails'] = $upgradeplan->data->plans;
			} else {
				$data['plandetails'] = [];
			}
		}
		$data['topup'] = $topup;
		$data['page'] = 'addliters';
		$this->load->view('addliters', $data);
	}

	public function save()
	{
		$inputBody = json_decode(file_get_contents('php://input'), true);
		if (decrypt_text($inputBody['iD']) !== false) {
			$requestBody = json_decode(decrypt_text($inputBody['iD']), true);
			// redis data starts 
			$redisData = [];
			$redisData['planId'] = $inputBody['planId'];
			$redisData['duration'] = $requestBody['duration'];
			$redisData['planProductType'] = $inputBody['planProductType'];
			$redisData['planStatus'] = $inputBody['planStatus'];
			$redisData['planDpAmount'] = decrypt_text($inputBody['planDpAmount']);
			$redisData['rPlanId'] = $inputBody['rPlanId'];
			$redisData['planName'] = $inputBody['planName'];
			$redisData['price'] = $requestBody['price'];
			// redis data ends
			$_SESSION['selected_plan']["selectedPlanId"] = $inputBody['planId'];
			$_SESSION['selected_plan']["selectedPlanDuration"] = $requestBody['duration'];
			$_SESSION['selected_plan']["selectedPlanProductType"] = $inputBody['planProductType'];
			$_SESSION['selected_plan']["selectedPlanStatus"] = $inputBody['planStatus'];
			$_SESSION['status'] = $inputBody['planStatus'];
			$_SESSION['selected_plan']["selectedDpAmount"] = decrypt_text($inputBody['planDpAmount']);
			$_SESSION["selectedRPlanId"] = $inputBody['rPlanId'];
			$_SESSION['nlp2'] = false;
			$_SESSION["selected_plan"]["selectedPlanName"] = $inputBody['planName']; //added by yashwanth on 08/10/2020
			$_SESSION["selected_plan"]["amount"] = $requestBody['price'];
			$_SESSION['currentplanname'] = $inputBody['planName'];
			if (isset ($_SESSION['token']) && !empty ($_SESSION['token'] && ($_SESSION['login_data']['paid'] == false || $_SESSION['login_data']['paid'] == null))) {
				$this->redis->set('user:' . $_SESSION['login_data']['userId'], json_encode($redisData));
				$this->redis->expire('user:' . $_SESSION['login_data']['userId'], TIMEOUT);
			}
		}

	}
}