<!DOCTYPE html>
<html lang="en" class="landing-html">

<head>
    <?php $this->load->view('common/css');?>
    
    <style>
        .login-orange {
            background:#f58220;
        }
    .hide {
        display: none;
    }

    .errorMsg {
        color: #eb5757;
        font-size: 12px;
        padding: 8px 0 0;
        font-weight: 500;
        font-family: 'Roboto';
    }

    .fa-exclamation-circle {
        color: red !important;
    }

    #source {
        border: 1px solid rgba(0, 0, 0, .6);
        max-height: 60px;
        margin-top: -22px;
        padding: 12px;
        width: 372px;
        max-width: 100%;
        background: #efefef;
    }

    .loginerror {
        color: #eb5757;
        font-size: 12px;
        font-weight: 500;
        font-family: 'Roboto';
        position: absolute;
        left: -66px;
        transform: translate(72px, 1px);
    }
    .loginerrorText {
        color: #eb5757;
        font-size: 12px;
        font-weight: 500;
        font-family: 'Roboto';
        position: absolute;
        left: -70px;
        transform: translate(72px, 1px);
    }
    .loginsuccess {
        color: #25d366;
        font-size: 12px;
        font-weight: 500;
        font-family: 'Roboto';
        position: absolute;
        left: 27px;
        transform: translate(72px, 1px);
    }

    .menu-bar .button-dropdown .dropdown-menu {
        margin: 0;
        margin-top: 3px;
        text-align: left;
        min-width: 200px !important;
        border-radius: 2px;
        padding: 0.5rem 0px 3px;
        position: absolute;
        background-color: #ffff;
        border: 1px solid rgba(0, 0, 0, .15);
        box-shadow: 0px 3px 27px 8px rgba(0, 0, 0, 0.2);
        z-index: 1;
    }

    .menu-bar .dropdown-menu a {
        padding: 5px 20px;
    }
    span#resendotptag {
        color: rgb(245, 130, 32);
        font-weight: bold;
    }
    form#b_loginTab label {
    color: #494949 !important;
}
.if_any{
        color: #929292 !important;
        font-weight: normal !important;
    font-family: 'sourcesanspro-regular';
    }
 
    p{
        color: #494949;
    }
    @media(max-width: 600px){
        .auth_img{
            background-image: url('<?php echo CDN; ?>assets/images/banner-auth-mobile.jpg') !important;
        }
        #auth_img.authimg-hide{
            background-image: url('') !important;
            display: none !important;
        }
    }
    @media(max-width: 425px){
        .loginerror{
            left: -22%;
            width:300px;
        }
    }
    @media(max-width: 375px){
        .loginerror{
            left: -22%;
            width:300px;
        }
    }
    </style>
</head>


<body>
<?php $this->load->view('common/header');?>
    <div class="header-spacing"></div>
    <main id="main-wrapper">
        <section class="form-section flex flex-column">
            <div id="entry-module" class="align-me-center flex-column"></div>
        </section>

        <section class="container sign_upcontainer">
            <div class="row sign_newCont" style="justify-content: center;">
                <div class="b_card">
                    <div class="row login_section">
                        <div id="auth_img" class="left_section auth_img"
                            style="background-image: url('<?php echo CDN; ?>assets/images/Sachin-Zinger-and-bolt.jpg');">
                        </div>
                        <div class="right_section auth_tab">
                            <div class="tabs">


                                <ul class="tabs-nav" id="logintab_nav">
                                    <li id="tab1"><a href="#tab-1">Log In</a></li>
                                    <li id="tab2"><a href="#tab-2">Sign Up</a></li>
                                </ul>

                                <div class="tabs-stage">
                                    <div class="tab_login" id="tab-1">
                                        <form id="b_loginTab" class="otpverify" id="otp" enctype="multipart/form-data">
                                            <label for="loginphone">Mobile Number</label>
                                            <div class="input-wrapper">
                                                <span>+91 |</span>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" id="token_<?php echo $this->security->get_csrf_token_name(); ?>">
                                                <input name="phone" id="loginphone" type="text" maxlength="10" minlength="10" <?php if(ENV === 'PROD') { ?>pattern="[6-9]{1}[0-9]{9}" <?php } ?> oninput="checkInputLengthLogin(); this.value = this.value.replace(/[^0-9]/g, '');">
                                                <div class="loginerrorText"></div>
                                                <div class="loginerror"></div>
                                            </div>
                                            <button class="btn login_btn" type="button" id="otp_button" disabled>Send
                                                OTP</button>
                                            <p style="color: #828282;">Don’t have an account?<a class="login_register" id="registernow">Register
                                                    Now</a>
                                            </p>
                                        </form>

                                        <div id="otp_tab">
                                            <div style="text-align: center;">
                                                <img src="<?php echo CDN; ?>images/auth_mob.webp" alt="" -
                                                    style="width: 100px;}">
                                                <p>Please enter the 4-digit OTP that was sent to the number below
                                                </p>
                                                <p class="ed_num">+91-<span id="loginnumber"><?=trim($_SESSION['loginphone'])?></span>
                                                    <span id="edit_number"
                                                        style="color: #f58220; cursor: pointer;font-weight:bold;">Edit</span>
                                                </p>
                                                <!-- action="<?php //echo base_url(); ?>auth/verifyotp" -->
                                                <form class="digit-group logingroup" method="post" action="<?php echo base_url(); ?>auth/verifyotp" data-group-name="digits"  data-autosubmit="false" autocomplete="off">
                                                    <div class="otp-input-fields">
                                                        <input type="hidden" name="phone" id="otpPhone">
                                                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" id="token_<?php echo $this->security->get_csrf_token_name(); ?>">
                                                        <input class="Box productkey1" type="tel" id="digit-1" name="digit-1" maxlength="1" required />
                                                        <input class="Box productkey1" type="tel" id="digit-2" name="digit-2" maxlength="1" required />
                                                        <input class="Box productkey1" type="tel" id="digit-3" name="digit-3" maxlength="1" required />
                                                        <input class="Box productkey1" type="tel" id="digit-4" name="digit-4" maxlength="1" required />
                                                    </div>
                                                    <div class="errorMsg">
                                                        <?php if (!empty($this->session->flashdata('wrongotpmessage'))) {
                                                            echo '<div class="errorMsg"> <i class="fa fa-exclamation-circle" aria-hidden="true" style="padding-right:4px;" ></i>';
                                                            echo $this->session->flashdata('wrongotpmessage');
                                                            echo '</div>';
                                                        }?>
                                                    </div>
                                                    <div class="loginsuccess"></div>
                                                    <div class="loginerror"></div>
                                                    <input type="submit" class="login_btn otp_btn otp_submitBtn" id="otp_submitBtn" value="Submit">
                                                </form>
                                                <p class="otptag" id="login_otptag" style="display:block; color: ">Did not receive a verfication code?<span class="resendotptag" id="resendotptag" data-tab="otp_tab" style="cursor: pointer;">&nbsp;Resend
                                                        OTP</span>
                                                </p>
                                                <p class="otptag resendotp-timer" style="display:none;">Re-send OTP in
                                                    <span class="sec" id="seconds" style="font-weight:bold;">&nbsp;
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab_login" id="tab-2">
                                        <div id="signupOtp_tab">
                                            <div style="    text-align: center;">
                                                <img src="<?php echo CDN; ?>images/auth_mob.webp" alt="" style="width: 100px;">
                                                <p>Please enter the 4-digit OTP that was sent to the number below</p>
                                                <p class="ed_num">+91-<span id="number"><?=trim($_SESSION['login_data']['phone'])?> </span></p>
                                                <form method="post" class="digit-group signupgroup" action="<?php echo base_url('auth/phoneOtp'); ?>" data-group-name="digits" data-autosubmit="false" autocomplete="off">
                                                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" id="token_<?php echo $this->security->get_csrf_token_name(); ?>">
                                                    <div class="otp-input-fields">
                                                        <input class="Box productkey1" type="tel" id="digit-1" name="digit-1" maxlength="1" required />
                                                        <input class="Box productkey1" type="tel" id="digit-2" name="digit-2" maxlength="1" required />
                                                        <input class="Box productkey1" type="tel" id="digit-3" name="digit-3" maxlength="1" required />
                                                        <input class="Box productkey1" type="tel" id="digit-4" name="digit-4" maxlength="1" required />
                                                    </div>
                                                    <div class="errorMsg">
                                                        <?php
                                                            if (!empty($this->session->flashdata('wrongotpmessage'))) {

                                                                echo ' <i class="fa fa-exclamation-circle" aria-hidden="true" style="padding-right:4px;" ></i>';
                                                                echo $this->session->flashdata('wrongotpmessage');
                                                            }?>
                                                    </div>
                                                    <div class="loginsuccess"></div>
                                                    <div class="loginerror"></div>
                                                    <button class="login_btn otp_btn otp_submitBtn" type="submit" id="otp_submitBtn">Verify</button>
                                                </form>
                                                <p class="otptag" id="otptag" style="display:block;">
                                                Did not receive a verfication code?
                                                    <span class="resendotptag" id="resendotptag" data-tab="signupOtp_tab" style="cursor: pointer;">&nbsp;Resend OTP</span></p>
                                                <p class="otptag resendotp-timer"  style="display:none;">Re-send OTP in
                                                    <span class="sec" id="seconds" style="font-weight:bold;">&nbsp;</span>
                                                </p>
                                            </div>
                                        </div>
                                        <form id="signup_tab" class="signup_tab" method="POST" enctype="multipart/form-data">
                                        <div class="signuperror" id="signuperror"></div>
                                            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" id="token_<?php echo $this->security->get_csrf_token_name(); ?>">
                                            <label for="name">Full Name</label>
                                            <div class="form-group">
                                                <input name="name" tabindex="2" id="name" type="text" maxlength="30" required="" aria-required="true" onkeyup="this.value = this.value.replace(/[^\sa-zA-Z]/g,'')" value="<?= (isset($_SESSION['formdata']['username']) && !empty($_SESSION['formdata']['username'])) ? $_SESSION['formdata']['username'] : '' ?>">
                                            </div>

                                            <label for="input_33">Mobile Number</label>
                                            <div class="input-wrapper">
                                                <span>+91 |</span>
                                                <input name="phone" <?= (ENV === "PROD") ? "pattern='[6-9]{1}[0-9]{9}'" : "pattern='[2-9]{1}[0-9]{9}'" ?> id="input_33" type="text" maxlength="10" minlength="10" oninput="checkInputLength(); this.value = this.value.replace(/[^0-9]/g, '');" required="" aria-required="true" value="<?= (isset($_SESSION['formdata']['phone']) && !empty($_SESSION['formdata']['phone'])) ? $_SESSION['formdata']['phone'] : '' ?>">
                                            </div>
                                            <label for="email">Email Id</label>
                                            <div class="form-group">
                                                <input name="email" id="email" type="email" maxlength="60" required="" aria-required="true" value="<?= (isset($_SESSION['formdata']['email']) && !empty($_SESSION['formdata']['email'])) ? $_SESSION['formdata']['email'] : '' ?>">
                                            </div>
                                            <label for="city">City</label>
                                            <div class="citySelect-dropdown">
                                                <select name="city" id="city" required>
                                                    <option value="" disabled selected>Select City</option>
                                                    <?php if(isset($_SESSION['formdata']['city']) && !empty($_SESSION['formdata']['city'])) { $_SESSION['user_plan_city'] = $_SESSION['formdata']['city'];};
                                                    foreach ($cities as $citylist) { $isSelected = ($citylist == $_SESSION['user_plan_city']) ? 'selected' : '';?>
                                                    <option value="<?= $citylist ?>" <?= $isSelected ?> > <?= $citylist ?> </option>
                                                    <?php } ?>
                                                </select>
                                            </div>                                        

                                            <label for="referralCode">Referral Code <span class="if_any">(if any)</span></label>
                                            <div class="form-group">
                                                <input name="referralCode" id="referralCode" type="text" minlength="6" maxlength="8">
                                            </div>
                                            <div class="b_checkbox">
                                                <label><input type="checkbox" id="terms" name="terms" checked required>
                                                    <span class="px-2">
                                                        By creating an account on LivpureSmart, you agree to our <a class="b_termUse" href="<?php echo site_url('terms_of_use'); ?>"> Terms
                                                        of Use.  </a> &amp; Receive notification from WhatsApp.
                                                    </span></label>
                                            </div>
                                            <span class="errorMessage"></span>
                                            <button type="submit" class="login_btn sign_up_btn" id="sign_upBtn"
                                                name="submit">Sign Up & Get 7 Days Free Trial</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main><!-- main-wrapper close -->
    <?php $this->load->view('common/footer');?>

    <script src="<?php echo CDN ?>assets/js/jquery.validate.min.js"></script>

    <script>
       $(document).ready(function () {
                $('.Box').on("keyup", function (e) {
                    
                    var activegroup='logingroup';
                    if($(this).closest('form').hasClass('signupgroup')){
                        activegroup='signupgroup';
                    }
                    var $input = $(this);
                    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                    //display error message
                    if (isNaN($input.val()) && $input.val().trim() !== "") {
                        $input.val("");
                        return false;
                    }
                    }
                    if ($input.val().length == 0 && e.which == 8) {
						$input.toggleClass("productkey2 productkey1").prev('.Box').focus();
					}
					else if ($input.val().length >= parseInt($input.attr("maxlength"), 10)) {
						$input.toggleClass("productkey1 productkey2").next('.Box').focus();
					}
                    let otpbtn = document.querySelector('#otp_submitBtn')
					var otp = $('.'+activegroup+' #digit-1').val() + $('.'+activegroup+' #digit-2').val() + $('.'+activegroup+' #digit-3').val() + $('.'+activegroup+' #digit-4').val();
                    if (otp.length == 4) { console . log('otp.length 2', otp.length);
                        otpbtn.disabled = false;
						$(".otp_submitBtn").addClass("login-orange");
					} else {
						otpbtn.disabled = true;
						$(".otp_submitBtn").removeClass("login-orange");
					}
                });
            });
    </script>

    <script type="text/javascript">

document.getElementById('name').addEventListener('input', function() {       
        let value = this.value.trim(); // Remove leading and trailing spaces
        let words = value.split(/\s+/); // Split the input by whitespace
        if (value === '') {           
            this.setCustomValidity('Please enter the name'); // Show an error message
        } else {            
            this.setCustomValidity(''); // Show an error message
        }
    });

    var searchRequest = null;

    $(function() {
        var length = 0;
        var minlength = 6;
        var maxlength = 8;
        $("#referralCode").on("keyup", function(e) {
            $('#signup_tab .validation').remove(); // remove it
            e.stopImmediatePropagation();
            value1 = $(this).val();
            value = value1.toUpperCase();
            if ($.inArray(value.length, [6,7,8]) !== -1) {
                    $.ajax({
                        type: "POST",
                        url: "<?php echo base_url(); ?>auth/validateReferralCode",
                        data: {'referralCode': value},
                        success: function(data) {
                            var result = JSON.parse(data);
                            if (result.success == true) {
                                $('#signup_tab .validation').remove();
                                $("#referralCode").after(
                                    "<div class='validation' style='color:#4caf50 !important;font-size:12px;margin-top: 14px;'>" +
                                    result.message + "</div>");
                                $('#submit_button').prop('disabled', false);

                            } else if (result.success == false) {
                                $('#signup_tab .validation').remove();
                                $("#referralCode").after("<div class='validation'>" +
                                    result.message + "</div>");

                                $('#submit_button').prop('disabled', true);



                            }
                        },

                        error: function(xhr, ajaxOptions, thrownError) {

                            console.log(thrownError);

                        }
                    });
            } else if (value.length == 0) {


                $('#submit_button').prop('disabled', false);

            } else if (value.length >= minlength || value.length >= maxlength) {


                $("#referralCode").after("<div class='validation'>" +
                    "Please enter valid referral code" + "</div>");
                $('#submit_button').prop('disabled', true);

            } else if (value.length > 0 && value.length < 6) {
                $("#referralCode").after("<div class='validation'>" +
                    "Please enter valid  referral code" + "</div>");
                $('#submit_button').prop('disabled', true);
            }
        });
        var hasClicked = false;
        $(".resendotptag").on("click",function(e) {
            $('#resendotptag').css("pointer-events", "none");
            var $this=$(this);
            var otptag=$this.data('tab');
                let phoneGet = document.getElementById('loginnumber').innerHTML;
                let resend_otp = "login";
                if(phoneGet.length === 0){
                    let phoneGet = document.getElementById('number').innerHTML;
                    let resend_otp = "signp";
                }
                loginphone = $('#loginphone').val();
            var url = `<?php echo base_url(); ?>ajax/sendLoginotp`;
            $.ajax({
                url: url,
                data: {
                    'phone': phoneGet,'resend_otp':resend_otp
                },
                type: "POST",
                success: function(data) {
                    var response = JSON.parse(data);
                    $("input[name='<?php echo $this->security->get_csrf_token_name(); ?>']").val(response.csrf_token);
                    $("#token_<?php echo $this->security->get_csrf_token_name(); ?>").val(response.csrf_token);
                    $('.errorMsg').css("display", "none");
                    $('#resendotptag').css("pointer-events", "unset");
                    if (response.statusCode == '200') {
                        $('.loginerror').hide();
                        messageShowHide('loginsuccess',response.message);
                        
                        var timeLeft = 30;
                        var elem = $("#"+otptag+" .sec");
                        var timerId = setInterval(Countdown, 1000,$this,otptag);
                        $("#"+otptag+' .resendotp-timer').css('display', 'block');
                        $this.parent().css('display', 'none');
                        function Countdown($this,otptag) {
                            if (timeLeft == -1) {
                                clearTimeout(timerId);
                                $("#"+otptag+' .resendotp-timer').css('display', 'none');
                                $this.parent().css('display', 'block');
                            } else {
                                 $("#"+otptag+" .sec").text('0' + '0' + ":" + timeLeft);
                                timeLeft--;
                            }
                            
                        }
                    }else if(response.statusCode == '201'){
                        $('.loginsuccess').hide();
                        messageShowHide('loginerror',response.message);
                    }else{
                        // $(".loginerror").text(response.message).show();
                        messageShowHide('loginerrorText', "This phone number is not regsisterd with us");
                    }
                }
            });
        });

    });

    $('.tabs-stage .tab_login').hide();
    $('.tabs-stage div:first').show();
    $('.tabs-nav li:first').addClass('tab-active');

    $('.tabs-nav a').on('click', function(event) {
        event.preventDefault();
        $('.tabs-nav li').removeClass('tab-active');
        $(this).parent().addClass('tab-active');
        $('.tabs-stage .tab_login').hide();
        $($(this).attr('href')).show();
    });
        
    function checkInputLengthLogin() {

        const inputField = document.getElementById('loginphone');
        const colorButton = document.getElementById('otp_button');

        if (!isNaN(inputField.value)) {
                console.log('Numeric value');   
        } else {
            $('#loginphone').val('');
            console.log('No Numeric value'); 
        }

        if (inputField.value.length === 10) {
            colorButton.classList.add('length-10');
            $('#otp_button').prop('disabled', false);
        } else {
            colorButton.classList.remove('length-10');
        }
    }

    var inputPhone = document.getElementById("loginphone");
    inputPhone.addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
            event.preventDefault();
            document.getElementById("otp_button").click();
        }
    });
    document.getElementById("otp_button").addEventListener("click", function(e) {
        var otpTab = document.getElementById("otp_tab");
        var loginTab = document.getElementById("b_loginTab");
        var loginSignup = document.getElementById("logintab_nav");
        // auth img
        var authimg=document.getElementById("auth_img");
        // end auth img
        var loginphone = $('#loginphone').val();
        var url = `<?php echo base_url(); ?>ajax/sendLoginotp`;
        $("#otp_button").removeClass("length-10");
        $('#otp_button').prop('disabled', true);
        $.ajax({
            url: url,
            data: $("#b_loginTab").serialize(),
            type: "POST",
            success: function(data) {
                $("#otp_button").addClass("length-10");
                $('#otp_button').prop('disabled', false);
                var response = JSON.parse(data);
                $("input[name='<?php echo $this->security->get_csrf_token_name(); ?>']").val(response.csrf_token);
                $("#token_<?php echo $this->security->get_csrf_token_name(); ?>").val(response.csrf_token);
                $('.errormsg').css("display", "none");
                if (response.statusCode == '200') {
                    otpTab.style.display = "block";
                    authimg . classList . add('authimg-hide');
                    loginTab.style.display = "none";
                    loginSignup.style.display = "none";
                    var element = document.getElementById("loginnumber");
                    element.textContent = loginphone;
                    var otpLoginData = document.getElementById("otpPhone");
                    otpLoginData.value = loginphone;
                    $('.loginerror').hide();
                    messageShowHide('loginsuccess',response.message);
                }else if(response.statusCode == '201'){
                    $('.loginsuccess').hide();
                    messageShowHide('loginerror',response.message);
                }else {
                    $(".loginsuccess,.loginerror").hide();
                    messageShowHide('loginerrorText', "This phone number is not regsisterd with us");
                }
            }
        });
    });

    function checkInputLength() {
        const inputField = document.getElementById('input_33');
        const colorButton = document.getElementById('otp_button');

        if (inputField.value.length === 10) {
            colorButton.classList.add('length-10');
            document.getElementById("otp_button").addEventListener("click", function(e) {
                e.preventDefault();
                var otpTab = document.getElementById("otp_tab");
                var loginTab = document.getElementById("b_loginTab");
                var loginSignup = document.getElementById("logintab_nav");
                if (otpTab.style.display === "none" || otpTab.style.display === "") {
                    otpTab.style.display = "block";
                    loginTab.style.display = "none";
                    loginSignup.style.display = "none";

                } else {
                    otpTab.style.display = "none";
                    loginTab.style.display = "none";
                    loginSignup.style.display = "none";
                }
            });
        } else {
            colorButton.classList.remove('length-10');
        };
    }

    checkInputLength();

    $(document).ready(function() {
        // Get the current URL
        const url = new URL(window.location.href);
        // Get a specific parameter value
        const param1Value = url.searchParams.get('type');
        var registered = "<?=$_SESSION['registersucess']?>";
        var loggedin = "<?=$_SESSION['loginsucess']?>";
        if(param1Value != 1){
            $('#tab1').removeClass('tab-active');
            $('#tab2').addClass('tab-active');
            $('#tab-1').hide();
            $('#tab-2').show();
        }
        if (registered == 'true') {
            var loginSignup = document.getElementById("logintab_nav");
            var signupOtpTab = document.getElementById("signupOtp_tab");
            var signupTab = document.getElementById("signup_tab");
            var regform = document.getElementById("tab-2");
            var loginform = document.getElementById("tab-1");
            var loginTab = document.getElementById("b_loginTab");

            signupOtpTab.style.display = "block";
            signupTab.style.display = "none";
            loginTab.style.display = "none";
            logintab_nav.style.display = "none";
            // loginform.style.display = "none";
            regform.style.display = "block";
        }

        $('.otp-input-fields input[type="text"]').on("keyup", function() {
            $('.errorMsg').css('display','none');
        });
        $(".digit-4").on("keyup", function() {
            var inputValue = $(this).val();
            if (inputValue.trim() !== "") {
                $(".otp_submitBtn").css("background-color", "#f58220");
            } else {
                $(".otp_submitBtn").css("background-color", "#bdbdbd");
            }
        });
    });

    // edit number js
    document.getElementById("edit_number").addEventListener("click", function(e) {
        e.preventDefault();
        $.ajax({
            type: "POST",
            url: "<?=base_url()?>ajax/editNumber",
            success: function(response) {
                var otpTab = document.getElementById("otp_tab");
                var loginTab = document.getElementById("b_loginTab");
                var loginSignup = document.getElementById("logintab_nav");
                var signupTab = document.getElementById("signup_tab");
                if (otpTab.style.display === "block" || otpTab.style.display === "") {
                    otpTab.style.display = "none";
                    loginTab.style.display = "block";
                    loginSignup.style.display = "block";
                } else {
                    otpTab.style.display = "block";
                    loginTab.style.display = "none";
                    loginSignup.style.display = "block";
                }
            },
            error: function(xhr, ajaxOptions, thrownError) {
                console.log("thrownError", thrownError);
            }

        });
    });
    // sign up js

    // genenrate otp
    function phoneotp(phone, userId) {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url()?>ajax/sendregistrationotp",
            data: {
                'phone': phone,
                'userId': userId
            },
            success: function(data) {
                console.log(data);
                var response = JSON.parse(data);
                // if (JSON.parse(response).status == true) {
                $('.errorMsg').css("display", "none");
                if (response.statusCode == '200') {
                    $("input[name='<?php echo $this->security->get_csrf_token_name(); ?>']").val(response.csrf_token);
                    $("#token_<?php echo $this->security->get_csrf_token_name(); ?>").val(response.csrf_token);
                    var loginSignup = document.getElementById("logintab_nav");
                    var signupOtpTab = document.getElementById("signupOtp_tab");
                    var signupTab = document.getElementById("signup_tab");
                    var authimg=document.getElementById("auth_img");
                    authimg . classList . add('authimg-hide');
                    signupOtpTab.style.display = "block";
                    signupTab.style.display = "none";
                    logintab_nav.style.display = "none";
                    var regotpverify = "<?=$_SESSION['reg_otp_verify']?>";

                    var element = document.getElementById("loginnumber");
                    element.textContent = '';

                    $('.loginerror').hide();
                    messageShowHide('loginsuccess',response.message);
                }
            },
            error: function(xhr, ajaxOptions, thrownError) {
                console.log("thrownError", thrownError);
            }

        });
    }

    $("#signup_tab").on('submit', function(e) {


        e.preventDefault();
        // $(".signuperror").remove();

        if ($("#signup_tab").valid()) {
            $('#signup_tab .sign_up_btn').attr("disabled",true);
            $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>ajax/register",
                data: $("#signup_tab").serialize(),

                success: function(result) {                  
                    $('#signup_tab .sign_up_btn').attr("disabled",false);
                    var response = JSON.parse(result);
                    $("input[name='<?php echo $this->security->get_csrf_token_name(); ?>']").val(response.csrf_token);
                    $("#token_<?php echo $this->security->get_csrf_token_name(); ?>").val(response.csrf_token);
                    if (response.statusCode == 200 || response.status == true) {
                        var phone = response.data.mobile
                        var userId = response.data.userId
                        var element = document.getElementById("number");
                        element.textContent = phone;
                        phoneotp(phone, userId);
                    } else {
                        var setData = document.getElementById('signuperror');
                        setData.textContent += response.message;
                        setTimeout(function(){
                            $('.signuperror').text('');
                        },3000);
                    }
                },


                error: function(xhr, thrownError) {
                    $('#signup_tab .sign_up_btn').attr("disabled",false);
                    console.log(thrownError);

                }
            });
        }
    });

    $('.digit-group').find('input').each(function() {


        $(this).attr('maxlength', 1);
        $(this).on('keyup', function(e) {
            var parent = $($(this).parent());
            // $(".otp_submitBtn").css("background-color", "#f58220");

            if (e.keyCode === 8 || e.keyCode === 37) {

                var prev = parent.find('input#' + $(this).data('previous'));

                if (prev.length) {

                    $(prev).select();
                }
            } else if ((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 65 && e.keyCode <= 90) || (
                    e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 39) {
                var next = parent.find('input#' + $(this).data('next'));


                if (next.length) {


                    $(next).select();
                } else {

                    if (parent.data('autosubmit')) {
                        parent.submit();
                    }
                }
            }
        });
    });


    $('#registernow').click(function() {

        $('.tabs-nav li').removeClass('tab-active');
        $('#tab2').addClass('tab-active');

        $('.tabs-stage .tab_login').hide();
        $('#tab-2').show();


    });

    <?php if(!empty($this->session->flashdata('statusCode'))) { ?>
        var otpTab = document.getElementById("otp_tab");
        var loginTab = document.getElementById("b_loginTab");
        var loginSignup = document.getElementById("logintab_nav");
        otpTab.style.display = "block";
        loginTab.style.display = "none";
        loginSignup.style.display = "none";
        var element = document.getElementById("loginnumber");
        element.textContent = "<?= $this->session->flashdata('phone') ?>";
        var otpLoginData = document.getElementById("otpPhone");
        otpLoginData.value = "<?= $this->session->flashdata('phone') ?>";
    <?php } ?>
    </script>
    <?php unset($_SESSION['formdata']);?>
</body>

</html>