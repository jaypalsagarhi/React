<style>

    ul#breadcrumb {
	margin: 0;
    padding: 3px 11px;
    line-height: 1;
}
    .breadcrumbs {
    padding: 10px;
    }
    .breadcrumbs__item {
    display: inline-block;
    line-height: 1;
    }
    .breadcrumbs__item:not(:last-of-type)::after {
    content: "\f105";
    margin: 0 14px;
    color: #cccccc;
    font-family: 'FontAwesome';
    }
	.b_brdcm{
		background: #f6f8fa;
		margin-bottom: 0px;
	}
    .breadcrumbs__link {
        text-decoration: none;
        font-size: 14px;
    font-family: 'NeoSansPro-Regular';
        color: #999999;
    }
	.breadcrumbs__link:hover {
		text-decoration: none;
        color: #000;
    }
	.breadcrumbs__link--active:hover{
		text-decoration: none;
	}
	
    .breadcrumbs__link--active {
		color: #000 !important;
    font-weight: bold;
	margin-bottom: 0;
    font-family: 'NeoSansPro-Regular';
    font-size: 14px;
    }
._block.product-section{
    padding-top: 0px;
}

@media(max-width:1200px){
    .brd_section {
    padding: 0;
}
}
</style>
<section class="brd_section">
    <div class="b_brdcm">
        <div class="brdcm container"> 
            <?php 
            if(!in_array($page, ['nlp','newnlp','premium','unlimited','purifier','nlpdealer','newflow2','nlp_newcity','nlpone'])){      
                ?>
                <ul id="breadcrumb">
                    <li class="breadcrumbs__item"><a href="<?=base_url()?>"  class="breadcrumbs__link">Home</a></li>
                    <?php
                    if($page === 'home'){
                        ?>
                    <li class="breadcrumbs__item"><a href="<?=base_url() ?>"  class="breadcrumbs__link--active">Water Purifier</a></li>
                    <?php
                    }else{
                        $getUrlData = $this->uri->segment_array();
                        for($i =1; $i <= $this->uri->total_segments(); $i++ ){
                            $jsonDataCreat[$i]['name'] = ucwords(str_replace(str_split('-_'), ' ', $getUrlData[$i]));
                            $jsonDataCreat[$i]['item'] = base_url() .implode('/',array_slice($getUrlData,0,$i));
                            ?>
                            <li class="breadcrumbs__item"><a href="<?=$jsonDataCreat[$i]['item']?>" class="<?= ($this->uri->total_segments() == $i) ? "breadcrumbs__link--active":"breadcrumbs__link"; ?>"><?= $jsonDataCreat[$i]['name'] ?></a></li>
                            <?php 
                        }
                    }
                    ?>
                </ul>
                <?php
            }
            $res_json_item=[];
            array_push($res_json_item,[
                "@type"=> "ListItem",
                "position"=> 1,
                "name"=>($page=='home')?'Water Purifier':'RO Subscription',
                "item"=>site_url()
            ]);
            foreach($jsonDataCreat as $key=>$jarr){
                array_push($res_json_item,[
                    "@type"=> "ListItem",
                    "position"=> ($key+1),
                    "name"=>$jarr['name'],
                    "item"=>$jarr['item']
                ]);
            }
            $res_json=[
                "@context"=>"https://schema.org/",
                "@type"=>"BreadcrumbList",
                "itemListElement"=>$res_json_item
            ];
            echo '<script type="application/ld+json">'.json_encode($res_json, JSON_UNESCAPED_SLASHES).'</script>';
            ?>
        </div>
    </div>
</section>
