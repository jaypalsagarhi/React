<?php defined('BASEPATH') or exit('No direct script access allowed');
class Auth extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$httpRef = $_SERVER['HTTP_REFERER'];
		$currentHost = "https://" . $_SERVER['HTTP_HOST'] . "/";
		if ($httpRef == $currentHost && !empty($_SESSION)) {
			$this->session->sess_destroy();
			header("Refresh:0");
		}
		$this->load->model('RegisterModel');
		$this->load->helper(array('form', 'url', 'datalayer_helper'));
		$this->load->model('Userlead');
		$this->redis = new \CI_Predis\Redis(['serverName' => SERVERNAME]);


	}

	public function index()
	{
		// Get the query parameter.
		$query_parameter = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
		$qParams = explode('=', $query_parameter);
		
		if ( ($query_parameter && $qParams[0] != 'type') || ($query_parameter && !in_array($qParams[1], array('0', '1')) ) ) {
			redirect(base_url() . 'auth');
		}
		$_SESSION['nlp'] = false;
		$_SESSION['purifier'] = false;
		$_SESSION['nlppage'] = false;
		$_SESSION['unlimited'] = false;
		$_SESSION['dealer'] = false;

		if ($_SESSION['login_data']['productType'] == "zinger-copper-emi") {
			session_unset();
			redirect(RO_URL);
		}

		$cities = cityList();
		$watersource = ["Water jars", "Ro Water Purifier", "Gravity Water Purifier", "Tap Water", "Other"];
		if (isset($_SESSION['formdata']['source']) && !empty($_SESSION['formdata']['source'])) {
			$watersource = array($_SESSION['formdata']['source']);
		}
		$id = 0;
		$type = 0;
		if (isset($_REQUEST['id']) != '') {
			$id = base64_decode($_REQUEST['id']);
		}
		if (isset($_REQUEST['type'])) {
			$type = $_REQUEST['type'];
		}

		$data['meta_title'] = 'Signup for LivpureSmart account';
		$data['meta_description'] = 'LivpureSmart: Register to subscribe to a RO Water Subscription Plan or to Recharge your existing subscription plan';
		if ($type == 1) {
			$data['meta_title'] = 'Login to Your LivpureSmart account';
			$data['meta_description'] = 'LivpureSmart: Login to subscribe to a RO Water Subscription Plan or to Recharge your existing subscription plan';
		}
		$data['page'] = 'auth';
		$data['id'] = $id;
		$data['cities'] = $cities;
		$data['watersource'] = json_encode($watersource);
		$data['authType'] = $type == 0 ? 'register' : 'login'; // 0 = register , 1 = login
		$this->load->view('auth', $data);

	}

	public function login()
	{
		$data = array(
			"username" => strip_tags($_POST['username']),
			"password" => strip_tags($_POST['password'])
		);
		$post = json_encode($data);

		/////////////////////////////////set cookie//////////////////////////////////////
		$hashedUserName = base64_encode($_POST['username']);
		$hashedUserPassword = base64_encode($_POST['password']);
		setcookie('cookie_roSub', 'false', time() + 60 * 60 * 24 * 365, '/', site_url(), false);
		setcookie('cookieEmail_roSub', $hashedUserName, time() + 60 * 60 * 24 * 365, '/', site_url(), false);
		setcookie('cookiePassword_roSub', $hashedUserPassword, time() + 60 * 60 * 24 * 365, '/', site_url(), false);
		session_regenerate_id(true);
		//////////////////////////////////////end//////////////////////////////////////
		// added by yashwanth on 25/09/2020

		$ch = curl_init(local_ip_url . api_version . '/authenticate');
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10); //allowed time to connect to api -rajeev 
		curl_setopt($ch, CURLOPT_TIMEOUT, 20); // allowed time to execute curl request -rajeev
		curl_setopt(
			$ch,
			CURLOPT_HTTPHEADER,
			array(
				'Content-Type: application/json'
			)
		);

		$result = json_decode(curl_exec($ch));
		if (curl_errno($ch)) {
			$error_msg = curl_error($ch);
			$message = "Network error,Please check internet connection";
			$this->session->set_flashdata('login_error', $message);
			redirect(base_url() . 'auth?type=1');
		}
		// set cookie after loggedin user
		setcookie('loggedin_user', md5($result->data->userId), time() + 60 * 60 * 24, '/', site_url(), false);

		$product = $result->data->productType;
		if (isset($product)) {
			if ($product == "furlenco" || $product == "rentmojo" || $product == "cityfurnish" || $product == "stpl") {

				$message = "Please login in livpure smart mobile app";
				$this->session->set_flashdata('login_error', $message);
				redirect(base_url() . 'auth?type=1');
			}
		}
		$_SESSION['Product'] = $result->data->productType;

		if (isset($result->data) && $result->statusCode == 200) {

			$Cod_user['userId'] = $result->data->userId;
			$check_cod_url = local_ip_url . 'v4/checkIsCod';
			$cod_response = json_decode(CallAPI('POST', $check_cod_url, $Cod_user));
			$cod_status = '';

			if ($cod_response->status == true) {
				if (isset($cod_response->data->cod_status) && $cod_response->data->cod_status == 'pending') {
					$cod_status = $cod_response->data->cod_status;
				}
			} else {
				$cod_status = 'none';
			}


			if ($result->data->paymentCompleted == true) {
				setcookie('cookieEmail_roSub', "", time() + 60 * 60 * 24 * 365, '/', site_url(), false); //unset the cookie
				setcookie('cookiePassword_roSub', "", time() + 60 * 60 * 24 * 365, '/', site_url(), false); // unset the cookie
			} //unset Cookie

			$loginVia = $_POST['username'];
			$data = array(
				'token' => $result->data->token,
				'userName' => $result->data->name,
				'username' => $result->data->name,
				'phone' => $result->data->mobile,
				'email' => $result->data->email,
				'userId' => $result->data->userId,
				'kycCompleted' => $result->data->kycCompleted,
				'Ekyc' => $result->data->kycCompleted == true ? 'Y' : 'N',
				'paid' => $result->data->paymentCompleted,
				'emiStatus' => $result->data->emiStatus,
				//added by yashwanth on 22/10/2020
				'emandCustId' => $result->data->emandCustId,
				// added by yashwanth on 22/10/2020
				'emandTokenId' => $result->data->emandTokenId,
				// added by yashwanth on 22/10/2020
				'emandSubCancelled' => $result->data->subscriptionCancelled,
				//// added by yashwanth on 22/10/2020
				'errorDescription' => $result->data->errorDescription,
				// added by yashwanth on 22/10/2020
				'paymentCompleted' => $result->data->paymentCompleted,
				"referralCode" => $result->data->referralCode,
				'loginType' => strpos($loginVia, '@') ? 'email' : 'phone',
				'planId' => $result->data->planId,
				'planName' => $result->data->planName,
				'kycStepTwoCompleted' => $result->data->kycStepTwoCompleted,
				'lastRechargeAmount' => $result->data->lastRechargeAmount,
				//added by yashwanth on 01/12/2020
				'city' => $result->data->city,
				'cod_status' => $cod_status,
				'phoneVerification' => $result->data->phoneVerification
			);
			$_SESSION['login_data'] = $data;
			$_SESSION['token'] = $result->data->token;
			$_SESSION['status'] = $result->data->planStatus;
			$_SESSION['realRefCode'] = $result->data->referredBy->referralCode;
			$_SESSION['realRefPhone'] = $result->data->referredBy->phone;
			$_SESSION['realRefName'] = $result->data->referredBy->name;
			$_SESSION['flipkartKycCompleted'] = $result->data->flipkartKycCompleted;
			$_SESSION['fleekKycCompleted'] = $result->data->kycCompleted;
			$_SESSION['source'] = $result->data->source;
			$_SESSION['emailVerification'] = $result->data->emailVerification;
			$_SESSION['phoneVerification'] = $result->data->phoneVerification;
			$_SESSION['kycStepTwoCompleted'] = $result->data->kycStepTwoCompleted;
			$_SESSION['permanentAddress'] = $result->data->permanentAddress;
			$_SESSION['login_data']['water_source'] = $result->data->waterSource;
			$_SESSION['login_data']['stoppedService'] = $result->data->stoppedService;
			$_SESSION['currentplanname'] = $result->data->planName;
			if ($_SESSION['login_data']['water_source'] == 'Others') {
				$_SESSION['login_data']['water_source'] = $result->data->waterSource;
			}
			$_SESSION['ekycStatus'] = $result->data->ekycStatus;
			$_SESSION['login_data']['ekycStatus'] = $result->data->ekycStatus;

			// Check if some user requested for relocation or not
			$_SESSION['relocation_status'] = $result->data->relocation_status;

			$_SESSION['gta4_login_event'] = "login";
			// loginPush();

			$_SESSION['deposit'] = 'true';

			if (isset($result->data->address) && $result->data->address !== '') {
				$_SESSION['login_data']['address'] = $result->data->address;
				$_SESSION['login_data']['city'] = $result->data->city;
				$_SESSION['login_data']['state'] = $result->data->state;
				$_SESSION['login_data']['pincode'] = $result->data->pincode;
				$_SESSION['selectedcity'] = $result->data->city;
				$addressSplit = explode(",", $_SESSION['login_data']['address'], 2);
				$_SESSION['login_data']['addressL1'] = $addressSplit[0];
				$_SESSION['login_data']['addressL2'] = count($addressSplit) == 1 ? "" : trim($addressSplit[1]);
			}

			$_SESSION['login_data']['rd_si'] = 'Y'; // to check page redirected from login si - signed in
			$_SESSION['new_customer'] = $_SESSION['login_data']['paymentCompleted'] == false ? "Y" : "N";

			$Data['userId'] = $_SESSION['login_data']['userId'];

			$userId = (int) ($_SESSION['login_data']['userId']);
			$reminder = $userId % 10;

			$this->setUserDetails();
			// Call LMS API on failed register

			if ($_SESSION['login_data']['paymentCompleted'] != '1') {
				$updatelead = array(
					'username' => $_SESSION['login_data']['userName'],
					'phone' => $_SESSION['login_data']['phone'],
					'email' => $_SESSION['login_data']['email'],
					'city' => $_SESSION['login_data']['city'],
					'current_source_of_water' => $_SESSION['login_data']['water_source'],
					'current_lead_page' => "Login",
					'business_id' => "1"
				);
				$this->Userlead->updateLeadData($updatelead, $_SESSION['login_data']['phone']);
			}
			// Call LMS API
			if ($_SESSION['source'] == 'Flipkart') {
				if ($_SESSION['phoneVerification'] == true) {
					if (isset($_SESSION['login_data']['address'])) {
						if ($_SESSION['flipkartKycCompleted'] == true) {
							if ($_SESSION['login_data']['kycCompleted'] == true || $_SESSION['relocation_status'] == '1') {
								if ($_SESSION['kycStepTwoCompleted'] == "true") {
									redirect(base_url() . 'dashboard');
								} else {
									redirect(base_url() . 'ekycstep');
								}
							} else {
								redirect(base_url() . 'ekycupload');
							}
						} else {

							redirect(FLIPCART_URL . 'ekyc?userId=' . $_SESSION['login_data']['userId'] . '&username=' . $_SESSION['login_data']['username'] . '&email=' . $_SESSION['login_data']['email'] . '');
						}
					} else {
						redirect(FLIPCART_URL . 'address?phone=' . $_SESSION['login_data']['phone'] . '&email=' . $_SESSION['login_data']['email'] . '');
					}
				} else {
					redirect(FLIPCART_URL . 'otp?phone=' . $_SESSION['login_data']['phone'] . '&userId=' . $_SESSION['login_data']['userId'] . '');
				}
			} else if ($_SESSION['source'] == 'Fleek') {
				if ($_SESSION['phoneVerification'] == true) {
					if (isset($_SESSION['login_data']['address'])) {
						if ($_SESSION['fleekKycCompleted'] == true || $_SESSION['relocation_status'] == '1') {
							if ($_SESSION['login_data']['kycCompleted'] == true) {
								if ($_SESSION['kycStepTwoCompleted'] == "true") {
									redirect(base_url() . 'dashboard');
								} else {
									redirect(base_url() . 'ekycstep');
								}
							} else {
								redirect(base_url() . 'ekycupload');
							}
						} else {
							redirect(redirect_url . 'fleekekyc?userId=' . $_SESSION['login_data']['userId'] . '&username=' . $_SESSION['login_data']['username'] . '&email=' . $_SESSION['login_data']['email'] . '');
						}
					} else {
						redirect(redirect_url . 'fleekaddress?phone=' . $_SESSION['login_data']['phone'] . '&email=' . $_SESSION['login_data']['email'] . '');
					}
				} else {

					redirect(redirect_url . 'fleekotp?phone=' . $_SESSION['login_data']['phone'] . '&userId=' . $_SESSION['login_data']['userId'] . '');
				}
			}
			//Condition for fleek
			else if ($_SESSION['source'] == 'v4') {
				if ($_SESSION['login_data']['paymentCompleted'] == false) {
					if ($this->isPlanSelected()) {
						redirect(base_url() . 'plan');
					}
				} else if ($_SESSION['login_data']['paymentCompleted'] == true) {
					if (isset($_SESSION['login_data']['address'])) {

						if ($_SESSION['login_data']['kycCompleted'] == false) {
							if (isset($_SESSION['login_data']['kycStepTwoCompleted']) && ($_SESSION['login_data']['kycStepTwoCompleted'] !== true)) {
								redirect(base_url('ekyc'));
							} else {
								redirect(base_url('ekycupload'));
							}
						} else if ($_SESSION['login_data']['kycCompleted'] == true) {
							if ($_SESSION['ekycStatus'] == 'Approved') {
								redirect(base_url('dashboard'));
							} else if ($_SESSION['kycStepTwoCompleted'] == "true") {
								redirect(base_url('dashboard'));
							} else {
								redirect(base_url('ekycstep'));
							}
						}
					} else {
						redirect(base_url() . 'nlpaddress?pincode=' . $result->data->pincode . '');
					}
				}
			}
			// if ($_SESSION['fromrefferalpage'] == 'refferalpage') {
			// 	redirect(base_url() . 'referral');
			// }

			if ($result->data->stoppedService == true) {
				redirect(base_url() . 'plan');
			}



			if ($cod_status == 'pending') {



				if ($_SESSION['login_data']['kycCompleted'] == false) {
					if (isset($_SESSION['login_data']['kycStepTwoCompleted']) && ($_SESSION['login_data']['kycStepTwoCompleted'] !== true)) {
						redirect(base_url('ekyc'));
					} else {
						redirect(base_url('ekycupload'));
					}
				} else if ($_SESSION['login_data']['kycCompleted'] == true) {



					if ($_SESSION['ekycStatus'] == 'Approved') {
						redirect(base_url('dashboard'));
					} else if ($_SESSION['kycStepTwoCompleted'] == "true") {
						redirect(base_url('dashboard'));
					} else {

						redirect(base_url('ekycstep'));
					}
				}
			}
			if ($_SESSION['Product'] == "zinger-copper-emi") {
				session_unset();
				redirect(RO_URL);
			} else {
				if ($_SESSION['login_data']['paymentCompleted'] == false) {
					if ($this->redis->exists('user:' . $_SESSION['login_data']['userId'])) {
						// Key exists in Redis
						$redisData = json_decode($this->redis->get('user:' . $_SESSION['login_data']['userId']), true);
						$_SESSION['selected_plan']["selectedPlanId"] = $redisData['planId'];
						$_SESSION['selected_plan']["selectedPlanDuration"] = $redisData['duration'];
						$_SESSION['selected_plan']["selectedPlanProductType"] = $redisData['planProductType'];
						$_SESSION['selected_plan']["selectedPlanStatus"] = $redisData['planStatus'];
						$_SESSION['status'] = $redisData['planStatus'];
						$_SESSION['selected_plan']["selectedDpAmount"] = $redisData['planDpAmount'];
						$_SESSION["selectedRPlanId"] = $redisData['rPlanId'];
						$_SESSION["selected_plan"]["selectedPlanName"] = $redisData['planName'];
						$_SESSION["selected_plan"]["amount"] = $redisData['price'];
						$_SESSION['currentplanname'] = $redisData['planName'];
					}
					if ($this->isPlanSelected()) {
						if (isset($_SESSION['login_data']['address']) && !empty($_SESSION['login_data']['address'])) {
							redirect(base_url() . 'review');
						} else {
							redirect(base_url() . 'address');
						}
					} else {
						redirect(base_url() . 'plan');
					}
				} else if ($_SESSION['login_data']['kycCompleted'] == false) {
					if (isset($_SESSION['login_data']['kycStepTwoCompleted']) && ($_SESSION['login_data']['kycStepTwoCompleted'] !== true)) {
						redirect(base_url('ekyc'));
					} else {
						redirect(base_url('ekycupload'));
					}
				} else if ($_SESSION['login_data']['kycCompleted'] == true) {

					if ($_SESSION['ekycStatus'] == 'Approved') {
						redirect(base_url('dashboard'));
					} else if ($_SESSION['kycStepTwoCompleted'] == "true") {
						redirect(base_url('dashboard'));
					} else {
						redirect(base_url('ekycstep'));
					}
				}
			}
		} else {
			$message = "Invalid username and password";
			$this->session->set_flashdata('login_error', $message);
			redirect(base_url() . 'auth?type=1');
		}
	}



	public function register()
	{
		if (!in_array(ENV, server) && !validatePassword(strip_tags($this->input->post('password')))) {
			$_SESSION['formdata'] = $_POST;
			$message = "Password must contain a capital letter, a small letter, a number, and a special character.";
			$this->session->set_flashdata('login_error', $message);
			$this->session->set_flashdata('error', $message);
			redirect(base_url() . explode(base_url(), $_SERVER['HTTP_REFERER'])[1]);
		}
		// remove neverbounce hidden keys from $_POST
		$removeKeys = array('nb-transaction-token', 'nb-confirmation-token', 'nb-result', 'pageName', 'cityName', 'name', 'datasource', 'terms');
		$via = strip_tags($this->input->post('pageName'));
		$_POST["username"] = strip_tags($this->input->post('name'));
		$_POST = array_diff_key($_POST, array_flip($removeKeys));
		$_POST['referralCode'] = strtoupper(strip_tags($this->input->post('referralCode')));

		////////////////////////////////////store in cookie//////////////////////////
		$hashedUserNameReg = base64_encode(strip_tags($this->input->post('email')));
		$hashedUserPasswordReg = base64_encode(strip_tags($this->input->post('password')));
		setcookie('cookie_roSub', 'false', time() + 60 * 60 * 24 * 365, '/', site_url(), false);
		setcookie('cookieEmail_roSub', $hashedUserNameReg, time() + 60 * 60 * 24 * 365, '/', site_url(), false);
		setcookie('cookiePassword_roSub', $hashedUserPasswordReg, time() + 60 * 60 * 24 * 365, '/', site_url(), false);
		///////////////////////////////////end////////////////////////////////////////////////
		// added by yashwanth on 25/09/2020

		if ($_SESSION['nlp'] == true || $_SESSION['zinger'] == true || $_SESSION['dealer'] == true) {
			$_POST['source'] = 'Water jars';
		}
		$post = json_encode($_POST);
		$ch = curl_init(local_ip_url . api_version . '/register');
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$ch,
			CURLOPT_HTTPHEADER,
			array(
				'Content-Type: application/json'
			)
		);

		$result = json_decode(curl_exec($ch));
		curl_close($ch);
		if ($result->statusCode == 200) {
			$this->RegisterModel->register($_POST);
			$source = null;
			if (strip_tags($this->input->post('source')) == 'Other') {
				if (strip_tags($this->input->post('datasource')) != "") {
					$source = strip_tags($this->input->post('datasource'));
				} else {
					$source = strip_tags($this->input->post('source'));
				}
			} else {
				$source = strip_tags($this->input->post('source'));
			}

			$refferalCode = strip_tags($this->input->post('referralCode'));
			$data = array(
				'token' => $result->data->token,
				'userId' => $result->data->userId,
				'userName' => $result->data->name,
				'email' => $result->data->email,
				'enteredReferralCode' => $refferalCode,
				// referral Code used while sign up - for analytics
				'city' => strip_tags($this->input->post('city')),
				// referral Code used while sign up - for analytics
				'phone' => $result->data->mobile,
				'water_source' => $source,
				'referralCode' => $refferalCode, //Added Dec21
				'phoneVerification' => $result->data->phoneVerification

			);

			$_SESSION['login_data'] = $data;
			$_SESSION['token'] = $result->data->token;
			$_SESSION['status'] = 'new-2022';
			// $_SESSION['login_data']['paymentlead'] = true;

			$_SESSION['login_data']['water_source'] = $this->input->post('source');
			if ($_SESSION['login_data']['water_source'] == 'Other') {
				$_SESSION['login_data']['water_source'] = $this->input->post('datasource');
			}
			// signUpPush();
			$_SESSION['gta4_signup_event'] = "signup";
			$_SESSION['deposit'] = 'true'; // added to get deposit amount changes for all customers

			//added to capture experience for type A customer by Yashwanth on 29/04/2020
			$userId = (int) ($_SESSION['login_data']['userId']);
			$reminder = $userId % 10;

			$_SESSION['login_data']['rd_su'] = 'Y'; // to check page redirected from login su - signed up
			$_SESSION['login_data']['page_source'] = $via;
			$_SESSION['new_customer'] = "Y";

			// default false
			$_SESSION['login_data']['Ekyc'] = 'N';
			$_SESSION['login_data']['kycCompleted'] = false;
			$_SESSION['login_data']['paymentCompleted'] = false;
			$_SESSION['login_data']['paid'] = false;

			$this->setUserDetails();

			// to insert and update the lead details to the api
			if ($_SESSION['nlppage'] == true) {
				$source_of_Enquiry = 'ro_nlp';
			} else if ($_SESSION['purifier'] == true) {
				$source_of_Enquiry = 'ro-Purifier';
			} else if ($_SESSION['unlimited'] == true) {
				$source_of_Enquiry = 'ro-unlimited';
			} else if ($_SESSION['zinger'] == true) {
				$source_of_Enquiry = 'zinger';
			} else if ($_SESSION['dealer'] == true) {
				$source_of_Enquiry = 'dealer_page';
			} else {
				$source_of_Enquiry = 'website';
			}
			$phone = $result->data->mobile;
			$updatelead = array(
				'user_id' => $userId,
				'username' => $_SESSION['login_data']['userName'],
				'phone' => $result->data->mobile,
				'alt_phone' => " ",
				'referral_code' => $refferalCode,
				'referral_phone' => $_SESSION['realRefPhone'],
				'referral_name' => $_SESSION['realRefName'],
				'email' => $_SESSION['login_data']['email'],
				'city' => $this->input->post('city'),
				'district' => '',
				'state' => '',
				'pincode' => '',
				'address' => '',
				'source_of_enquiry' => $source_of_Enquiry,
				'utm_source' => $_SESSION['utm_source'],
				'utm_medium' => $_SESSION['utm_medium'],
				'current_source_of_water' => $_SESSION['login_data']['water_source'],
				'current_plan_selected' => '',
				'lead_created_page' => "",
				'current_lead_page' => "Registration_page",
				'business_id' => "1"
			);
			//end
			$this->Userlead->addLead($userId);
			$this->Userlead->updateLeadData($updatelead, $phone);

			if ($this->isPlanSelected()) {
				if (isset($_SESSION['login_data']['address'])) {
					redirect(base_url() . 'review');
				} else {
					redirect(base_url() . 'address');
				}
			} else {
				redirect(base_url() . 'plan');
			}
		} else {

			// Call LMS API on failed register
			$updatelead = array(
				'username' => $this->input->post('name'),
				'phone' => $this->input->post('phone'),
				'email' => $this->input->post('email'),
				'city' => $this->input->post('city'),
				'source_of_enquiry' => 'Registration_page',
				'current_source_of_water' => $this->input->post('source'),
				'current_lead_page' => "Registration_page",
				'business_id' => "1"
			);
			$this->Userlead->updateLeadData($updatelead, $this->input->post('phone'));
			// Call LMS API

			$message = $result->message;
			//"Phone number in use" /*"Email in use"*/
			if (strpos($message, 'Phone number in use') !== false) {
				$message = 'This mobile number is already registered with us. Please login or sign up with a new mobile number.';
			} else if (strpos($message, 'Email in use') !== false) {
				$message = 'This email address is already registered with us. Please login or sign up with a new email address.';
			} else if (strpos($message, 'in use') !== false) {
				$message = 'This mobile and email number are already registered with us. Please login or sign up with a new mobile number and email address.';
			}
			if (strtolower($via) === 'landing') {
				$this->session->set_flashdata('error', $message);
				if ($_SESSION['purifier'] == true) {
					redirect(base_url() . 'purifier');
				} else if ($_SESSION['unlimited'] == true) {
					redirect(base_url() . 'unlimited');
				} else if ($_SESSION['zinger'] == true) {
					redirect(base_url() . 'premium');
				} else if ($_SESSION['dealer'] == true) {
					redirect(base_url() . 'nlpdealer');
				} else {
					redirect(base_url() . 'nlp');
				}
			} else {
				$this->session->set_flashdata('login_error', $message);
				$_SESSION['formdata'] = $_POST;
				$_SESSION['formdata']['city'] = $this->input->post('city');
				$_SESSION['formdata']['source'] = $this->input->post('source');
				if ($_SESSION['purifier'] == true) {
					redirect(base_url() . 'purifier');
				} else if ($_SESSION['unlimited'] == true) {
					redirect(base_url() . 'unlimited');
				} else {
					redirect(base_url() . (strtolower($via) === 'onboarding' ? 'auth' : 'lp/compare'));
				}
			}
		}
	}

	public function validateReferralCode()
	{

		$result = CallAPI('POST', local_ip_url . 'validateReferralCode', $_POST);
		$getDet = json_decode($result);
		if ($getDet->success) {
			$splitname = explode("from", $getDet->message);
			$_SESSION['referral_name'] = $splitname[1];
			$_SESSION['realRefCode'] = $_POST['referralCode'];
			$_SESSION['realRefPhone'] = $getDet->data->phone;
			$_SESSION['realRefName'] = $getDet->data->username;
		} else {
			$_SESSION['referral_name'] = "";
			$_SESSION['realRefCode'] = "";
		}
		echo $result;
		exit;
	}

	private function setUserDetails()
	{
		$_POST['userId'] = $_SESSION['login_data']['userId'];
		$url = local_ip_url . api_version . '/getReferralShortLink';
		$refUrl = json_decode(CallAPI('POST', $url, $_POST));
		if (!empty($refUrl) && $refUrl->sucess == true) {
			$_SESSION['refshoorturl'] = $refUrl->data->refShortLink;
		} else {
			$_SESSION['refshoorturl'] = '';
		}

		$Data['email'] = $_SESSION['login_data']['email'];
		$url = local_ip_url . 'getUserDetailsWeb';
		$userResult = json_decode(CallAPI('POST', $url, $Data));
		$userDetails = $userResult->userDetails[0];
		$_SESSION['login_data']['registerDate'] = $userDetails->registerDate;
		$_SESSION['login_data']['userName'] = $userDetails->username;
		$_SESSION['emailVerification'] = $userDetails->emailVerification;
		$_SESSION['phoneVerification'] = $userDetails->phoneVerification;

		if (isset($userDetails->ro_recharge[0]) && is_array($userDetails->ro_recharge[0]) && count($userDetails->ro_recharge[0]) >= 1) {
			$_SESSION['DeviceRechargeStatus'] = $userDetails->ro_recharge[0]->DeviceRechargeStatus;
		} else {
			$_SESSION['DeviceRechargeStatus'] = '';
		}
		if (isset($userDetails->lastName)) {
			$_SESSION['login_data']['fullName'] = $_SESSION['login_data']['userName'] . ' ' . $userDetails->lastName;
		} else {
			$_SESSION['login_data']['fullName'] = $_SESSION['login_data']['userName'];
		}

		$fullName = explode(" ", $_SESSION['login_data']['fullName'], 2);

		$_SESSION['login_data']['firstName'] = $fullName[0];
		$_SESSION['login_data']['lastName'] = count($fullName) == 1 ? "" : $fullName[1];

		$_SESSION['login_data']['phone'] = (isset($userDetails->phone) && !empty($userDetails->phone)) ? $userDetails->phone : $_SESSION['login_data']['phone'];
		$_SESSION['login_data']['productType'] = $userDetails->productType;
		$_SESSION['login_data']['userreferralCode'] = $userDetails->referralCode;
		$_SESSION['login_data']['referralCode'] = $userDetails->referredBy->referralCode;

		$_SESSION['login_data']['planName'] = isset($userDetails->planName) ? $userDetails->planName : "";
		$_SESSION['login_data']['premiumPlanName'] = isset($userDetails->planName) ? $userDetails->planName : "";
		$_SESSION['login_data']['referred_by'] = !empty($userResult->userDetails[0]->user_address[0]->referredBy);
	}

	function isPlanSelected()
	{
		if ($_SESSION['login_data']['productType'] != 'zinger-waas-copper') {
			$_SESSION['login_data']['productType'] = 'bolt-waas';
		}
		return isset($_SESSION['selected_plan']["selectedPlanId"]) && isset($_SESSION['login_data']['productType']) && $_SESSION['login_data']['productType'] != 'zinger-waas-copper';
	}

	function phoneOtp()
	{
		if ($this->input->method() === 'post' && $this->security->csrf_verify()) {
			$token = $this->security->get_csrf_hash();
			$otpvalue = $_POST['digit-1'] . $_POST['digit-2'] . $_POST['digit-3'] . $_POST['digit-4'];
			if (strlen($otpvalue) < '4') {
				$this->session->set_flashdata('wrongotpmessage', 'please enter proper otp');
				redirect(base_url() . 'auth');

			} else {
				$post['phoneOtp'] = $otpvalue;
				$post['userId'] = $_SESSION['login_data']["userId"];
				$otpverify = json_decode(CallAPI('POST', local_ip_url . api_version . '/verifyOtp', $post));
				if ($otpverify->statusCode == '200') {
					$_SESSION['sucessmessage'] = 'sucess';
					$_SESSION['phoneVerification'] = $otpverify->data->phoneVerification;
					$_SESSION['phoneVerified'] = $otpverify->data->phoneVerification;
					$_SESSION['login_data']['phoneVerification'] = true;
					$updatelead = array(
						'username' => $_SESSION['login_data']['userName'],
						'phone' => $_SESSION['login_data']['phone'],
						'email' => $_SESSION['login_data']['email'],
						'city' => $_SESSION['login_data']['city'],
						'current_source_of_water' => $_SESSION['login_data']['water_source'],
						'current_lead_page' => "Signup",
						'phone_verified' => true,
						'business_id' => "1"
					);
					$this->Userlead->updateLeadData($updatelead, $_SESSION['login_data']['phone']);
					redirect(base_url() . 'plan');
				} else if ($otpverify->message != 'sucess' && $otpverify->statusCode != '200') {
					$msg = 'Wrong OTP entered';
					$data['page'] = 'otp';
					$this->session->set_flashdata('wrongotpmessage', 'Wrong OTP entered');
					redirect(base_url() . 'auth');
				}
			}
		}else {
			$this->security->regenerate_csrf_hash();
			echo 'Invalid CSRF token or form submission method.';
		}
	}

	public function verifyotp()
	{
		if ($this->input->method() === 'post' && $this->security->csrf_verify()) {
			$phoneotpvalue = $_POST['digit-1'] . $_POST['digit-2'] . $_POST['digit-3'] . $_POST['digit-4'];
			if (strlen($phoneotpvalue) < '4') {

				$msg = 'Otp verification failed!';
				$data['page'] = 'auth';
				$this->session->set_flashdata('wrongotpmessage', 'Otp verification failed!');
				redirect(base_url() . 'auth');

			} else {
				$post['otp'] = $phoneotpvalue;
				$post['phone'] = $this->input->post('phone');

				$result = json_decode(CallAPI('POST', local_ip_url . api_version . '/otplogin', $post));
				
				if ($result->statusCode !== 200) {
					$this->session->set_flashdata('phone', $post['phone']);
					$this->session->set_flashdata('statusCode', $result->statusCode);
					$this->session->set_flashdata('wrongotpmessage', 'Wrong OTP entered');
					redirect(base_url() . 'auth?type=1');
				}
				// set cookie after loggedin user
				setcookie('loggedin_user', md5($result->data->userId), time() + 60 * 60 * 24, '/', site_url(), false);

				$product = $result->data->productType;
				if (isset($product)) {
					if ($product == "furlenco" || $product == "rentmojo" || $product == "cityfurnish" || $product == "stpl") {

						$message = "Please login in livpure smart mobile app";
						$this->session->set_flashdata('login_error', $message);
						redirect(base_url() . 'auth?type=1');
					}
				}
				$_SESSION['Product'] = $result->data->productType;

				if (isset($result->data) && $result->statusCode == 200) {

					$Cod_user['userId'] = $result->data->userId;
					$check_cod_url = local_ip_url . 'v4/checkIsCod';
					$cod_response = json_decode(CallAPI('POST', $check_cod_url, $Cod_user));
					$cod_status = 'none';

					if ($cod_response->status && isset($cod_response->data->cod_status) && $cod_response->data->cod_status == 'pending') {
						$cod_status = $cod_response->data->cod_status;
					}


					if ($result->data->paymentCompleted == true) {
						setcookie('cookieEmail_roSub', "", time() + 60 * 60 * 24 * 365, '/', site_url(), false); //unset the cookie
						setcookie('cookiePassword_roSub', "", time() + 60 * 60 * 24 * 365, '/', site_url(), false); // unset the cookie
					} //unset Cookie

					$loginVia = $_POST['username'];
					$data = array(
						'token' => $result->data->token,
						'userName' => $result->data->name,
						'username' => $result->data->name,
						'phone' => $result->data->mobile,
						'email' => $result->data->email,
						'userId' => $result->data->userId,
						'kycCompleted' => $result->data->kycCompleted,
						'Ekyc' => $result->data->kycCompleted == true ? 'Y' : 'N',
						'paid' => $result->data->paymentCompleted,
						'emiStatus' => $result->data->emiStatus,
						//added by yashwanth on 22/10/2020
						'emandCustId' => $result->data->emandCustId,
						// added by yashwanth on 22/10/2020
						'emandTokenId' => $result->data->emandTokenId,
						// added by yashwanth on 22/10/2020
						'emandSubCancelled' => $result->data->subscriptionCancelled,
						//// added by yashwanth on 22/10/2020
						'errorDescription' => $result->data->errorDescription,
						// added by yashwanth on 22/10/2020
						'paymentCompleted' => $result->data->paymentCompleted,
						"referralCode" => $result->data->referralCode,
						'loginType' => strpos($loginVia, '@') ? 'email' : 'phone',
						'planId' => $result->data->planId,
						'planName' => $result->data->planName,
						'kycStepTwoCompleted' => $result->data->kycStepTwoCompleted,
						'lastRechargeAmount' => $result->data->lastRechargeAmount,
						//added by yashwanth on 01/12/2020
						'city' => $result->data->city,
						'cod_status' => $cod_status,
						'phoneVerification' => $result->data->phoneVerification
					);
					$_SESSION['login_data'] = $data;
					$_SESSION['token'] = $result->data->token;
					$_SESSION['status'] = $result->data->planStatus;
					$_SESSION['realRefCode'] = $result->data->referredBy->referralCode;
					$_SESSION['realRefPhone'] = $result->data->referredBy->phone;
					$_SESSION['realRefName'] = $result->data->referredBy->name;
					$_SESSION['flipkartKycCompleted'] = $result->data->flipkartKycCompleted;
					$_SESSION['fleekKycCompleted'] = $result->data->kycCompleted;
					$_SESSION['source'] = $result->data->source;
					$_SESSION['emailVerification'] = $result->data->emailVerification;
					$_SESSION['phoneVerification'] = $result->data->phoneVerification;
					$_SESSION['kycStepTwoCompleted'] = $result->data->kycStepTwoCompleted;
					$_SESSION['permanentAddress'] = $result->data->permanentAddress;
					$_SESSION['login_data']['water_source'] = $result->data->waterSource;
					$_SESSION['login_data']['stoppedService'] = $result->data->stoppedService;
					$_SESSION['currentplanname'] = $result->data->planName;
					if ($_SESSION['login_data']['water_source'] == 'Others') {
						$_SESSION['login_data']['water_source'] = $result->data->waterSource;
					}
					$_SESSION['ekycStatus'] = $result->data->ekycStatus;
					$_SESSION['login_data']['ekycStatus'] = $result->data->ekycStatus;

					// Check if some user requested for relocation or not
					$_SESSION['relocation_status'] = $result->data->relocation_status;

					$_SESSION['gta4_login_event'] = "login";
					// loginPush();

					$_SESSION['deposit'] = 'true';

					if (isset($result->data->address) && $result->data->address !== '') {
						$_SESSION['login_data']['address'] = $result->data->address;
						$_SESSION['login_data']['city'] = $result->data->city;
						$_SESSION['login_data']['state'] = $result->data->state;
						$_SESSION['login_data']['pincode'] = $result->data->pincode;
						$_SESSION['selectedcity'] = $result->data->city;
						$addressSplit = explode(",", $_SESSION['login_data']['address'], 2);
						$_SESSION['login_data']['addressL1'] = $addressSplit[0];
						$_SESSION['login_data']['addressL2'] = count($addressSplit) == 1 ? "" : trim($addressSplit[1]);
					}

					$_SESSION['login_data']['rd_si'] = 'Y'; // to check page redirected from login si - signed in
					$_SESSION['new_customer'] = $_SESSION['login_data']['paymentCompleted'] == false ? "Y" : "N";

					$Data['userId'] = $_SESSION['login_data']['userId'];

					$userId = (int) ($_SESSION['login_data']['userId']);
					$reminder = $userId % 10;

					$this->setUserDetails();
					// Call LMS API on failed register

					if ($_SESSION['login_data']['paymentCompleted'] != '1') {
						$updatelead = array(
							'username' => $_SESSION['login_data']['userName'],
							'phone' => $_SESSION['login_data']['phone'],
							'email' => $_SESSION['login_data']['email'],
							'city' => $_SESSION['login_data']['city'],
							'current_source_of_water' => $_SESSION['login_data']['water_source'],
							'current_lead_page' => "Login",
							'business_id' => "1"
						);
						$this->Userlead->updateLeadData($updatelead, $_SESSION['login_data']['phone']);
					}
					// Call LMS API
					if ($_SESSION['source'] == 'Flipkart') {
						if ($_SESSION['phoneVerification'] == true) {
							if (isset($_SESSION['login_data']['address'])) {
								if ($_SESSION['flipkartKycCompleted'] == true) {
									if ($_SESSION['login_data']['kycCompleted'] == true || $_SESSION['relocation_status'] == '1') {
										if ($_SESSION['kycStepTwoCompleted'] == "true") {
											redirect(base_url() . 'dashboard');
										} else {
											redirect(base_url() . 'ekycstep');
										}
									} else {
										redirect(base_url() . 'ekycupload');
									}
								} else {

									redirect(FLIPCART_URL . 'ekyc?userId=' . $_SESSION['login_data']['userId'] . '&username=' . $_SESSION['login_data']['username'] . '&email=' . $_SESSION['login_data']['email'] . '');
								}
							} else {
								redirect(FLIPCART_URL . 'address?phone=' . $_SESSION['login_data']['phone'] . '&email=' . $_SESSION['login_data']['email'] . '');
							}
						} else {
							redirect(FLIPCART_URL . 'otp?phone=' . $_SESSION['login_data']['phone'] . '&userId=' . $_SESSION['login_data']['userId'] . '');
						}
					} else if ($_SESSION['source'] == 'Fleek') {
						if ($_SESSION['phoneVerification'] == true) {
							if (isset($_SESSION['login_data']['address'])) {
								if ($_SESSION['fleekKycCompleted'] == true || $_SESSION['relocation_status'] == '1') {
									if ($_SESSION['login_data']['kycCompleted'] == true) {
										if ($_SESSION['kycStepTwoCompleted'] == "true") {
											redirect(base_url() . 'dashboard');
										} else {
											redirect(base_url() . 'ekycstep');
										}
									} else {
										redirect(base_url() . 'ekycupload');
									}
								} else {
									redirect(redirect_url . 'fleekekyc?userId=' . $_SESSION['login_data']['userId'] . '&username=' . $_SESSION['login_data']['username'] . '&email=' . $_SESSION['login_data']['email'] . '');
								}
							} else {
								redirect(redirect_url . 'fleekaddress?phone=' . $_SESSION['login_data']['phone'] . '&email=' . $_SESSION['login_data']['email'] . '');
							}
						} else {

							redirect(redirect_url . 'fleekotp?phone=' . $_SESSION['login_data']['phone'] . '&userId=' . $_SESSION['login_data']['userId'] . '');
						}
					}
					//Condition for fleek
					else if ($_SESSION['source'] == 'v4') {
						
						if ($_SESSION['login_data']['paymentCompleted'] == false) {
							if ($this->isPlanSelected()) {
								redirect(base_url() . 'plan');
							}
						} else if ($_SESSION['login_data']['paymentCompleted'] == true) {
							if (isset($_SESSION['login_data']['address'])) {

								if ($_SESSION['login_data']['kycCompleted'] == false) {
									if (isset($_SESSION['login_data']['kycStepTwoCompleted']) && ($_SESSION['login_data']['kycStepTwoCompleted'] !== true)) {
										redirect(base_url('ekyc'));
									} else {
										redirect(base_url('ekycupload'));
									}

								} else if ($_SESSION['login_data']['kycCompleted'] == true) {
									if ($_SESSION['ekycStatus'] == 'Approved') {
										redirect(base_url('dashboard'));
									} else if ($_SESSION['kycStepTwoCompleted'] == "true") {
										redirect(base_url('dashboard'));
									} else {
										redirect(base_url('ekycstep'));
									}
								}
							} else {
								redirect(base_url() . 'nlpaddress?pincode=' . $result->data->pincode . '');
							}
						}
					}
					if ($result->data->stoppedService == true) {
						redirect(base_url() . 'plan');
					}
					if ($cod_status == 'pending') {
						if ($_SESSION['login_data']['kycCompleted'] == false) {
							if (isset($_SESSION['login_data']['kycStepTwoCompleted']) && ($_SESSION['login_data']['kycStepTwoCompleted'] !== true)) {
								redirect(base_url('ekyc'));
							} else {
								redirect(base_url('ekycupload'));
							}
						} else if ($_SESSION['login_data']['kycCompleted'] == true) {



							if ($_SESSION['ekycStatus'] == 'Approved') {
								redirect(base_url('dashboard'));
							} else if ($_SESSION['kycStepTwoCompleted'] == "true") {
								redirect(base_url('dashboard'));
							} else {

								redirect(base_url('ekycstep'));
							}
						}
					}
					if ($_SESSION['Product'] == "zinger-copper-emi") {
						session_unset();
						redirect(RO_URL);
					} else {
						if ($_SESSION['login_data']['paymentCompleted'] == false) {
							if ($this->redis->exists('user:' . $_SESSION['login_data']['userId'])) {
								// Key exists in Redis
								$redisData = json_decode($this->redis->get('user:' . $_SESSION['login_data']['userId']), true);
								$_SESSION['selected_plan']["selectedPlanId"] = $redisData['planId'];
								$_SESSION['selected_plan']["selectedPlanDuration"] = $redisData['duration'];
								$_SESSION['selected_plan']["selectedPlanProductType"] = $redisData['planProductType'];
								$_SESSION['selected_plan']["selectedPlanStatus"] = $redisData['planStatus'];
								$_SESSION['status'] = $redisData['planStatus'];
								$_SESSION['selected_plan']["selectedDpAmount"] = $redisData['planDpAmount'];
								$_SESSION["selectedRPlanId"] = $redisData['rPlanId'];
								$_SESSION["selected_plan"]["selectedPlanName"] = $redisData['planName'];
								$_SESSION["selected_plan"]["amount"] = $redisData['price'];
								$_SESSION['currentplanname'] = $redisData['planName'];
							}
							if ($this->isPlanSelected()) {
								if (isset($_SESSION['login_data']['address']) && !empty($_SESSION['login_data']['address'])) {
									redirect(base_url() . 'review');
								} else {
									redirect(base_url() . 'address');
								}
							} else {
								redirect(base_url() . 'plan');
							}
						} else if ($_SESSION['login_data']['kycCompleted'] == false) {
							if (isset($_SESSION['login_data']['kycStepTwoCompleted']) && ($_SESSION['login_data']['kycStepTwoCompleted'] !== true)) {
								redirect(base_url('ekyc'));
							} else {
								redirect(base_url('ekycupload'));
							}
						} else if ($_SESSION['login_data']['kycCompleted'] == true) {

							if ($_SESSION['ekycStatus'] == 'Approved') {
								redirect(base_url('dashboard'));
							} else if ($_SESSION['kycStepTwoCompleted'] == "true") {
								redirect(base_url('dashboard'));
							} else {
								redirect(base_url('ekycstep'));
							}
						}
					}
				} else {

					$msg = 'Wrong OTP entered';
					$data['page'] = 'otp';
					$this->session->set_flashdata('wrongotpmessage', 'Wrong OTP entered');
					redirect(base_url() . 'auth');
				}


			}
		} else {
			$this->security->regenerate_csrf_hash();
			echo 'Invalid CSRF token or form submission method.';
		}



	}

	public function logout()
	{
		session_unset();
		setcookie('cookie_roSub', 'true', time() + 60 * 60 * 24 * 365, '/', site_url(), false);
		if (isset($_COOKIE['loggedin_user'])) {
			unset($_COOKIE['loggedin_user']);
			setcookie('loggedin_user', null, time() - (60 * 60 * 24 * 2), '/', site_url());
		}
		$this->session->sess_destroy();
		//added by yashwanth on 25/09/2020 for auto login
		redirect(redirect_url, 'refresh');
	}
}