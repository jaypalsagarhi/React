<!DOCTYPE html>
<html lang="en" class="landing-html">

<?php

$amt_349 = 399;
$amt_499 = 549;
$amt_649 = 699;
$mr_codes = 'TE0B8Y,XAOS0R,MXZERX,93N3JU,XJ2SYK,LHL6VL,AICEEC,8ISGKG,WV3NBS,6D3494,8V0UKU,ZDNPYV,DUHSX9,TIFBD1,FLL5EJ,AO9ACA,D3FMJL,2LRAKC,ORMA4E,OUQFY9,M7ABXM,GR4W2C,5KXSOH,DL4FBW,ZTX2GK,QWPTXU,GVJGKU,1X09O5,UI2YZE,NAFMIT,NYAH8D,8WERLX,BZ6KAN,LEHHNU,ZCEMXH,CP1KXI,MR0044,MR0045,MR0046,MR0047,MR0048,MR0049,MR0050,MR0051,MR0052,MR0053,MR0054,MR0055,MR0056,MR0057,MR0058,MR0059,MR0060,MR0061,MR0062,MR0063,MR0064,MR0065,MR0071,MR0072,MR0073,MR0074,MR0075,MR0076,MR0077,MR0080,MR0090,MR0094,MR0096,MR0115,MR0116,MR0117,MR0118,MR0119,MR0121,MR0122,MR0123,MR0124,MR0125,MR0126,MR0127,MR0128,MR0129,MR0130,MR0131,MR0132,MR0133,MR0134,MR0135,MR0136,MR0137,MR0141,MR0143,MR0144,MR0145,MR0146,MR0148,MR0151,MR0152,MR0153,MR0155,MR0156,MR0157,MR0159,MR0160,MR0161,MR0162,MR0163,MR0165,MR0167,MR0170,MR0172,MR0173,MR0174,MR0175,MR0176,MR0177,MR0178,MR0179,MR0180,MR0181,MR0182,MR0183,MR0184,MR0185,MR0186,MR0187,MR0188,MR0189,MR0190,MR0191,MR0192,MR0193,MR0194,MR0196,MR0197,MR0198,MR0199,MR0200,MR0202,MR0203,MR0204,MR0205,MR0206,MR0207,MR0208,MR0209,MR0210,MR0211,MR0212,MR0213,MR0214,MR0215';
if ($this->input->get('rcode') && in_array($this->input->get('rcode'), explode(',', $mr_codes))) {
    $amt_349 = 349;
    $amt_499 = 549;
    $amt_649 = 699;
}
?>

<head>
    <?php
    $this->load->view('common/css');
    ?>
    <meta name="robots" content="noindex, follow" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="preload" href="<?php echo CDN ?>assets/css/nlp-v2.css?version=<?= version ?>" as="style">
    <link rel="stylesheet" href="<?php echo CDN ?>assets/css/nlp-v2.css?version=<?= version ?>">
    <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>
    <!-- <link rel="preload" href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;600;700&display=swap"
        crossorigin as="style">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;600;700&display=swap"> -->
    <!-- <link rel="preload" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap"
        crossorigin as="style"> -->
    <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap"> -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/glider-js@1/glider.min.css" media="print"
        onload="this.media='all';">

    <style>
        .bannerSec_spl {
            background-image: url("<?php echo base_url(); ?>assets/banner/nlp_web_banner.webp");
            background-size: contain;
            width: 100%;
            background-repeat: no-repeat;
            background-size: 100%;
        }
      
        .alert.alert-warning.alert-dismissible.fade.in {
            color: red;
            margin-bottom: 10px;
            opacity: 1;
        }

        #boltMinralizer .row {
            justify-content: center;
        }

        .fs_applicable{
            font-size: 12px !important;
            position: absolute;
            bottom: 74px;
            left: 31px;
            color: #696b6e;
            font-weight: 400;
            background: aliceblue;
            padding: 0px 10px;
            border-radius: 3px;
        }        .loginerror {
            color: #eb5757;
            font-size: 12px;
            padding: 8px 0 0;
            font-weight: 500;
            font-family: 'SourceSansPro-Regular';
            position: absolute;
            top: -34px;
            left: 6%;
        }
        #otp{
            position: relative;
        }
        .loginsuccess {
            color: #25d366;
            font-size: 14px;
            padding: 8px 0 0;
            font-weight: 500;
            font-family: 'SourceSansPro-Regular';
            position: absolute;
            top: -23px;
            left: 27%;
        }
        @media screen and (max-width:768px) {
            .bannerSec_spl {
                background-image:url("<?php echo base_url(); ?>assets/banner/nlp_mob_banner.webp");
                background-size: 100% 100%;
                height: 430px;
                width: 100%;
                background-repeat: no-repeat;
                /* background-size: cover; */
            }
            .showHide1{
            margin: 0 !important;
        }
            #header .menu-list li:last-child {
                border-bottom: none;
                margin-bottom: 4px;
            }
            .banner-section .banner-text-box p {
    margin: 10px 0 6px !important;
}

.fs_applicable {
    font-size: 10px !important;
    bottom: 284px;
}
        }
    </style>
</head>


<body>
    <?php
    $this->load->view('common/header');
    ?>

    <main id="main-wrapper">
        <section class="banner-section">
            <div class="d-flex justify-content-center">
                <div class="bannerSec_spl">
                    <!-- <img loading="eager" src="<?php echo base_url(); ?>assets/banner/nlp_web_banner.webp"
                        alt="Rent A RO Water Purifier | LivpureSmart" class="home-banner">
                    <img loading="eager" class="mobile-home-banner active"
                        src="<?php echo base_url(); ?>assets/banner/nlp_mob_banner.webp"
                        alt="Rent A RO Water Purifier | LivpureSmart" class="mobile-home-banner"> -->

                    <div class="container">
                        <div class="banner-text-box active">
                            <h1 class="banner-top-text" style="text-transform:none;">
                                Livpure Smart Water Purifier on Subscription
                                <br />
                            </h1>
                            <p> Plans Start from<span> &#8377;
                                    <?php echo $amt_349 ?>*/month
                                </span></p>
                        </div>
                    </div>
                    <p class="fs_applicable">* Price applicable on 12-month plan only. T&C Apply</p>
                </div>
                <?php if ($_SESSION['registersucess'] != true) {?>
                <div class="newNLP_Page_reg_form">
                    <form id="nlpRegistration" name="nlpRegistration" method="POST"
                        action="<?php echo base_url('nlp/register'); ?>">
                        <input type="hidden" name="id" value="<?= $id ?>">
                        <input type="hidden" name="pageName" value="Landing">
                        <div class="registration__form">
                            <div class="form__caption">Sign Up & Get 7 Days Free Trial</div>

                            <?php if ($this->session->flashdata('success')): ?>
                                <div class="alert alert-success alert-dismissible fade in">
                                    <?= $this->session->flashdata('success'); ?>
                                </div>
                            <?php endif;
                            ?>
                            <?php if ($this->session->flashdata('error')): ?>
                                <div class="alert alert-warning alert-dismissible fade in">
                                    <?= $this->session->flashdata('error'); ?>
                                </div>
                            <?php endif;
                            ?>

                            <div class="form__fields">
                                <div class="full__field" id="toggleClass">
                                    <input type="text" tabindex="2" class="custom__field wd40" name="name" id="username"
                                        placeholder="Enter name" maxlength="30" required="true" aria-required="true">
                                </div>

                                <div class="full__field" id="toggleClass1">
                                    <input type="tel" tabindex="5" class="custom__field" name="phone" id="phone"
                                        placeholder="Enter mobile number" <?php if(ENV === 'PROD') { ?>pattern="[6-9]{1}[0-9]{9}"<?php } else{?>pattern="[1-9]{1}[0-9]{9}"<?php }?>
                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');"
                                        minlength="10" maxlength="10" required="" aria-required="true">
                                </div>
                                <div class="full__field nlp_mob-hide">
                                    <input type="email" tabindex="4" class="custom__field wd40" name="email" id="email"
                                        placeholder="Enter email" maxlength="201" required="" aria-required="true">
                                </div>
                                
                                <div class="full__field nlp_mob-hide">
                                    <select tabindex="10" class="select2" name="city" id="city" required>
                                        <option value="" disabled selected>Select City</option>
                                        <?php
                                        foreach ($citylist as $cities) { ?>
                                            <option value="<?= $cities ?>"> <?= $cities ?> </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="full__field nlp_mob-hide">
                                    <input type="text" tabindex="13" name="referralCode" id="referralCode"
                                        class="custom__field" placeholder="Referral Code ( if any)"
                                        value=<?= $_SESSION['requestrefferalcode'] ? $_SESSION['requestrefferalcode'] : " " ?>>
                                </div>
                                <div class="mb-4 nlp_mob-hide">
                                    <label>
                                        <input type="checkbox" tabindex="13" id="terms"
                                            class="custom__field" required> <span class="px-2">
                                            By registering on LivpureSmart, you agree to communication through SMS, phone, email & WhatsApp, and our <a href="<?php echo site_url('terms_of_use'); ?>">Terms of Use</a> & <a href="<?php echo site_url('terms_and_conditions'); ?>">T&Cs.</a>
                                        </span>
                                    </label>
                                </div>
                                <div class="text-center btn-wrapper form__tc">
                                    <div class="clear"></div>
                                    <div class="text-center btn-wrapper" id="submittab">
                                        <input type="submit" name="" id="submit_button" class="submit-btn btn"
                                            value="Sign Up">
                                            
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>
                    </form>
                                        </div>
<?php } else {?>
              <div class="newNLP_Page_reg_form" style="background:#442c8c;">
                    <div class="otp">
                        <div class="otpcontainer">
                            <div class="otpimage" style="text-align:center;">
                                <img src="<?=CDN?>assets/images/logo.webp" id="imagelogo" alt="otplogo">
                            </div>




                            <div class="otpform">
                                <p id="otptxt">Please enter the 4-digit otp that was sent to the number below
                                <p id="otpphone">+91-<?=$_SESSION['login_data']['phone']?><span id="regnumber">
                                        <input type="hidden" id="otpphoneno" name="otpphoneno" value=""></p>
                            </div>
                        </div>

                        <form class="formverify" method="POST" id="otp"
                            action="<?php echo base_url('nlp/phoneOtp'); ?>" enctype="multipart/form-data"
                            style="text-align:center;">

                            <?php
if (!empty($this->session->flashdata('message1'))) {

    echo '<i class="fa fa-exclamation-circle errormsg" aria-hidden="true" style="color:red">' . '</i>' .
    '<i class="errormsg" style="color:red; font-family:NeoSansPro-Regular;">' . $this->session->flashdata('message1') . '</i>';

    //  echo '<i class="fa fa-exclamation-circle" aria-hidden="true" style="color:red">'.
    //  $this->session->flashdata('message1').'</i>';
}?>

                            <?php
if (!empty($this->session->flashdata('wrongotpmessage'))) {

    echo ' <i class="fa fa-exclamation-circle errormsg" aria-hidden="true" style="color:red;">' .
    $this->session->flashdata('wrongotpmessage') . '</i>';
}?>


                            <div class="loginsuccess"></div>
                            <div class="loginerror"></div>
                            <div id="otpbox" name="otpbox" class="inputs d-flex flex-row justify-content-center mt-4">


                                <input class="otpinputval m-2 text-center form-control rounded" type="tel" id="first"
                                    name="first" pattern="\d*" placeholder="-" maxlength="1"
                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required />
                                <input class="otpinputval m-2 text-center form-control rounded" type="tel" id="second"
                                    name="second" pattern="\d*" placeholder="-" maxlength="1"
                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required />
                                <input class="otpinputval m-2 text-center form-control rounded" type="tel" id="third"
                                    name="third" pattern="\d*" placeholder="-" maxlength="1"
                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required />
                                <input class="otpinputval m-2 text-center form-control rounded" type="tel" id="fourth"
                                    name="fourth" pattern="\d*" placeholder="-" maxlength="1"
                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required />

                            </div>

                            <div class="verifybtn d-flex flex-row justify-content-center">
                                <button class="otpbtn" type="submit" value="submit">Submit</button>
                            </div>

                            <div class="wrapper" style="text-align:center;">


                                <p class="otptag" id="otptag" style="display:block;">Didn't receive OTP code?<span
                                        class="resendotptag" id="resendotptag"
                                        onclick="resendOtp('<?=$_SESSION['login_data']['phone']?>','<?=$_SESSION['login_data']['userId']?>')"
                                        style="cursor: pointer;">&nbsp;Resend OTP</span></p>
                                <p class="otptag" id="resendotp" style="display:none;">Re-send OTP in <span class="sec"
                                        id="seconds" style="font-weight:bold;">&nbsp; </span></p>

                            </div>
                        </form>
                        <?php } ?>
                                        </div>
                </div>
            </div>
            <div class="newLPUI">
                <!-- /* 10.03.2022 New Landing Page Starts Below  */ -->
                <section class="newlpZeroOffers blueBG">
                    <div class="row d-flex align-items-center">
                        <div class="zeroCols">
                            <div class="d-flex align-items-center">
                                <div class="bluIcon whiteBg">

                                    <img loading="lazy" src="<?= CDN ?>assets/images/investment-icon.svg"
                                        class="img-fluid" width="37px" height="28px" alt="Livpuresmart Savings icon"
                                        srcset="">
                                </div>
                                <div class="zeroOffContent">
                                    <b><i class="rupee">`</i>0</b> <br>
                                    <span>Investment</span>
                                </div>
                            </div>
                        </div>
                        <div class="zeroCols">
                            <div class="d-flex align-items-center">
                                <div class="bluIcon whiteBg">
                                    <img loading="lazy" src="<?= CDN ?>assets/images/maintenance-icon.svg"
                                        class="img-fluid" width="34px" height="34px" alt="Livpuresmart Tools icon"
                                        srcset="">
                                </div>
                                <div class="zeroOffContent">
                                    <b><i class="rupee">`</i>0</b> <br>
                                    <span>Maintenance</span>
                                </div>
                            </div>
                        </div>
                        <div class="zeroCols">
                            <div class="d-flex align-items-center">
                                <div class="bluIcon whiteBg">
                                    <img loading="lazy" src="<?= CDN ?>assets/images/Installation-icon.svg"
                                        class="img-fluid" width="39px" height="30px" alt="livpuresmart driller icon"
                                        srcset="">
                                </div>
                                <div class="zeroOffContent">
                                    <b><i class="rupee">`</i>0 </b><br>
                                    <span>Installation</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- /* 10.03.2022 New Landing Page End  */ -->
            </div>
        </section>




        <div class="featuresBx">
            <div class="container">
                <h2 class="heading">Our Special Features</h2>
                <div class="row">
                    <div class="col-md-3 col-sm-12">
                        <ul class="feature__list">
                            <li>
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Monitor filters quality</span>
                            </li>
                            <li>
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Automatic service alert</span>
                            </li>
                            <li>
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Connect support team</span>
                            </li>
                            <li class="mobile__screen">
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Monitor machine-health based on real-time data </span>
                            </li>
                            <li class="mobile__screen">
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Track real-time water consumption</span>
                            </li>
                            <li class="mobile__screen">
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Easy recharge</span>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6 desktop__screen"><img loading="lazy" class="product__img"
                            src="<?= CDN ?>assets/images/fetured-products-nlp.webp" alt="Livpure Smart Product">
                    </div>
                    <div class="col-md-3 col-sm-6 desktop__screen">
                        <ul class="feature__list">
                            <li>
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Monitor machine-health based on real-time data</span>
                            </li>
                            <li>
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Track real-time water consumption</span>
                            </li>
                            <li>
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Easy recharge</span>
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-12 mobile__screen"><img loading="lazy" class="product__img"
                            src="<?= CDN ?>assets/images/fetured-products-nlp.webp" alt="Livpure Smart Product">
                    </div>
                </div>
                <!--row /desktop__screen -->

                <!-- <div class="row mobile__screen">
                    <div class="col-md-12">
                        <ul class="feature__list">
                            <li>
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Monitor Filters Quality</span>
                            </li>
                            <li>
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Automatic service alert</span>
                            </li>
                            <li>
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Monitor machine-health based on real-time data </span>
                            </li>
                            <li>
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Track real-time water consumption</span>
                            </li>
                            <li>
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Easy recharge</span>
                            </li>
                            <li>
                                <img loading="lazy" src="<?= CDN ?>assets/images/water-drop.webp" alt="Water Drop">
                                <span>Connect support team</span>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-12"><img loading="lazy" class="product__img"
                            src="<?= CDN ?>assets/images/fetured-products-nlp.webp" alt="Livpure Smart Product">
                    </div>
                </div> -->
                <!--row /mobile__screen -->
                <h5>Download App</h5>
                <ul class="play__store">
                    <li><a href="https://bit.ly/3H49y77" target="_blank" rel="nofollow noopener noreferrer"><img
                                loading="lazy" src="<?= CDN ?>assets/images/google_play.png" alt="Google play"></a></li>
                    <li><a href="https://apple.co/3v38tYs" target="_blank" rel="nofollow noopener noreferrer"><img
                                loading="lazy" src="<?= CDN ?>assets/images/app_store.png" alt="App"></a></li>
                </ul>
            </div>
        </div>
        <!--featuresBx-->



        <section class="section NewLP_Con great-choice-section active choiceSection">
            <div class="container">
                <h2 class="heading-nlp">WHY LIVPURE SMART IS THE BEST CHOICE IN INDIA</h2>
                <p class="hideme showme">For many homeowners, there are daily hassles of arranging drinking water- be it
                    water
                    jars
                    or maintaining the RO water purifiers. With Livpure Smart, you get rid of both and live a
                    hassle-free
                    life, with the assurance of pure RO drinking water at affordable rates.</p>
                <div class="choice-box-wrapper">
                    <div class="choice-box  slide-to-left">
                        <div class="icon-box"><img loading="lazy" src='<?= CDN ?>assets/images/investment_icon.png'
                                alt="LivpureSmart Investment Icon"></div>
                        <div class="choice-text">
                            <p class="amount">
                                <i class="rupee">`</i>
                                <span>0</span>
                            </p>
                            <label>machine cost<br> <small>with all plans</small>
                            </label>
                        </div>
                    </div><!-- choice-box close -->
                    <div class="choice-box   slide-to-right">
                        <div class="icon-box"><img loading="lazy" src='<?= CDN ?>assets/images/maintaince_icon.png'
                                alt="LivpureSmart maintaince Icon"></div>
                        <div class="choice-text">
                            <p class="amount">
                                <i class="rupee">`</i>
                                <span>0</span>
                            </p>
                            <label>maintenance <br><small>with all plans</small></label>
                        </div>
                    </div><!-- choice-box close -->

                    <div class="choice-box  slide-to-left">
                        <div class="icon-box"><img loading="lazy" src='<?= CDN ?>assets/images/installation_icon.png'
                                alt="LivpureSmart Installation Icon"></div>
                        <div class="choice-text">
                            <p class="amount">
                                <i class="rupee">`</i>
                                <span>0</span>
                            </p>
                            <label> installation charges <br><small>with all plans</small></label>

                        </div>

                    </div><!-- choice-box close -->


                    <div class="choice-box slide-to-right">
                        <div class="icon-box"><img loading="lazy" src='<?= CDN ?>assets/images/map_location.png'
                                alt="Location Icon" width="23" height="40"></div>
                        <div class="choice-text">
                            <p class="amount">
                                <i class="rupee">`</i>
                                <span>0</span>
                            </p>
                            <label>Relocation Cost <br><small>with all plans</small></label>
                        </div>
                    </div>

                    <div class="clear"></div>
                </div>
            </div>


        </section><!-- great-choice-section close -->



        <div class="planSection">
            <div class="container">
                <h2 class="heading-nlp">Subscription Plans</h2>
                <p class="text-center pay-less">Pay less as you drink more</p>

                <ul class="nav nav-tabs" id="myTab1" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#boltMinralizer" role="tab"
                            aria-controls="Minralizer" aria-selected="true">Bolt Mineraliser</a>
                    </li>
                    <li class="nav-item" role="presentation" style="display:none;">
                        <span class="premPlan">New</span>
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#boltAlkaline" role="tab"
                            aria-controls="Alkaline" aria-selected="false">Bolt Alkaline</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <span class="premPlan"><img loading="lazy" src='<?= CDN ?>assets/images/diamond-icon.svg'
                                alt="diamond-icon">PREMIUM</span>
                        <a class="nav-link" id="contact-tab" data-toggle="tab" href="#zingerHot" role="tab"
                            aria-controls="Zinger" aria-selected="false">Zinger Copper Hot</a>
                    </li>
                </ul>
                <!--nav tabs-->

                <div class="tabContainer">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="boltMinralizer" role="tabpanel"
                            aria-labelledby="Minralizer-tab">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="card__web hideOnMobile">
                                        <div class="card__header">Silver Plan</div>
                                        <div class="card__body">
                                            <p>Pay <i class="rupee">`</i>
                                                <?php echo $amt_349 ?>
                                            </p>
                                            <p>for 150 Litres water every month</p>
                                            <p>Additional Usage @ ₹3.00 per Litre</p>
                                            <p>*Rate per litre (Inclusive of GST)</p>
                                        </div>
                                        <div class="card__footer">
                                            <a href="#" class="selectPlanBtn">Select Plan</a>
                                        </div>
                                    </div>

                                    <a href="#nlpRegistration" class="card__mobile hideOnDesktop">
                                        <div class="panelBx">
                                            <div class="panelHeader">
                                                <ul>
                                                    <li>
                                                        <span class="plan">Silver Plan</span>
                                                        <span class="rateMonthly">
                                                            <i class="fa fa-inr"></i>
                                                            <?php echo $amt_349 ?><span>/month</span>
                                                        </span>
                                                    </li>
                                                    <li>
                                                        <span class="quantity">150<span>Litres</span></span>
                                                        <span class="description">Water every month</span>
                                                    </li>
                                                </ul>

                                            </div>
                                            <div class="panelFooter">Additional Usage @ ₹3.00 per Litre</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-4">
                                    <div class="card__web hideOnMobile">
                                        <div class="card__header">Family Plan</div>
                                        <div class="card__body">
                                            <p>Pay <i class="rupee">`</i>
                                                <?php echo $amt_499; ?>
                                            </p>
                                            <p>for 999 Litres water every month</p>
                                            <p>Additional Usage @ ₹1.00 per Litre</p>
                                            <p>*Rate per litre (Inclusive of GST)</p>
                                        </div>
                                        <div class="card__footer">
                                            <a href="#" class="selectPlanBtn">Select Plan</a>
                                        </div>
                                    </div>

                                    <a href="#nlpRegistration" class="card__mobile hideOnDesktop">
                                        <div class="panelBx">
                                            <div class="panelHeader">
                                                <ul>
                                                    <li>
                                                        <span class="plan">Family Plan</span>
                                                        <span class="rateMonthly">
                                                            <i class="fa fa-inr"></i>
                                                            <?php echo $amt_499 ?><span>/month</span>
                                                        </span>
                                                    </li>
                                                    <li>
                                                        <span class="quantity unlimited">999 <span>Litres</span></span>
                                                        <span class="description">Water every month</span>
                                                    </li>
                                                </ul>

                                            </div>
                                            <div class="panelFooter">Additional Usage @ ₹1.00 per Litre</div>
                                        </div>
                                    </a>
                                </div>
                                <!--col 3-->
                            </div>
                        </div>
                        <!-- Tab 1 -->

                        <div class="tab-pane fade" id="boltAlkaline" role="tabpanel" aria-labelledby="Alkaline-tab">
                            <div class="row d-flex justify-content-center">
                                <div class="col-md-4">
                                    <div class="card__web hideOnMobile">
                                        <div class="card__header">Family Plan</div>
                                        <div class="card__body">
                                            <p>Pay <i class="rupee">`</i> 575</p>
                                            <p>for unlimited water every month</p>
                                            <p>No Additional Usage charges</p>
                                            <p>*Rate per litre (Inclusive of GST)</p>
                                        </div>
                                        <div class="card__footer">
                                            <a href="#" class="selectPlanBtn">Select Plan</a>
                                        </div>
                                    </div>

                                    <a href="#" class="card__mobile hideOnDesktop">
                                        <div class="panelBx">
                                            <div class="panelHeader">
                                                <ul>
                                                    <li>
                                                        <span class="plan">Family Plan</span>
                                                        <span class="rateMonthly">
                                                            <i class="fa fa-inr"></i>575<span>/month</span>
                                                        </span>
                                                    </li>
                                                    <li>
                                                        <span class="quantity unlimited">Unlimited<span></span></span>
                                                        <span class="description">Water every month</span>
                                                    </li>
                                                </ul>

                                            </div>
                                            <div class="panelFooter">No Additional Usage charges</div>
                                        </div>
                                    </a>
                                </div>
                                <!--col 3-->
                            </div>
                            <!--row-->
                        </div>
                        <!-- Tab 2 -->

                        <div class="tab-pane fade" id="zingerHot" role="tabpanel" aria-labelledby="Zinger-tab">
                            <div class="row d-flex justify-content-center">
                                <div class="col-md-4">
                                    <div class="card__web hideOnMobile">
                                        <div class="card__header">Family Plan</div>
                                        <div class="card__body">
                                            <p>Pay <i class="rupee">`</i>
                                                <?php echo $amt_649; ?>
                                            </p>
                                            <p>for 999 Litres water every month</p>
                                            <p>Additional Usage @ ₹1.00 per Litre</p>
                                            <p>*Rate per litre (Inclusive of GST)</p>
                                        </div>
                                        <div class="card__footer">
                                            <a href="#" class="selectPlanBtn">Select Plan</a>
                                        </div>
                                    </div>

                                    <a href="#nlpRegistration" class="card__mobile hideOnDesktop">
                                        <div class="panelBx">
                                            <div class="panelHeader">
                                                <ul>
                                                    <li>
                                                        <span class="plan">Family Plan</span>
                                                        <span class="rateMonthly">
                                                            <i class="fa fa-inr"></i>
                                                            <?php echo $amt_649 ?><span>/month</span>
                                                        </span>
                                                    </li>
                                                    <li>
                                                        <span class="quantity unlimited">999 <span>Litres</span></span>
                                                        <span class="description">Water every month</span>
                                                    </li>
                                                </ul>

                                            </div>
                                            <div class="panelFooter">Additional Usage @ ₹1.00 per Litre</div>
                                        </div>
                                    </a>
                                </div>
                                <!--col 3-->
                            </div>
                            <!--row-->
                        </div>
                        <!-- Tab 3 -->
                    </div>
                </div>
                <!-- tabContainer -->
            </div>
            <!--container-->
        </div>
        <!--planSection-->


        <section class="section innovation-section active innovationSmartGen">
            <img loading="lazy" src='<?= CDN ?>assets/images/innovation_img.webp' alt="LivpureSmart Innovation Icon">
            <div class="container">
                <h2 class="heading02 ">Innovation for the Smart Generation</h2>
                <p>Livpure Smart is the sensible option for homeowners as it eliminates most of the worries of
                    ownership.
                    <br /> It also means you enjoy best water at an affordable rate.
                </p>
                <div class="innovation-box-wrap">
                    <figure class="innovation-box">
                        <div class="inno-img"><img loading="lazy" src='<?= CDN ?>assets/images/risk_trial.png'
                                alt="LivpureSmart Risk Trial Icon">
                        </div>
                        <figcaption>
                            <h3 class="heading03">7 Days No Risk Trial</h3>
                            <p>Getting started is easy! And you can do it all at no additional installation costs. Means
                                an
                                intelligent choice!</p>
                        </figcaption>
                    </figure><!-- innovation-box close -->
                    <figure class="innovation-box">
                        <div class="inno-img"><img loading="lazy" src='<?= CDN ?>assets/images/maintaince.png'
                                alt="LivpureSmart maintaince Icon">
                        </div>
                        <figcaption>
                            <h3 class="heading03">Free Lifetime Maintenance</h3>
                            <p class="">When you avail it, you also get peace of mind with hassle-free maintenance
                                of
                                your purifier free of cost.</p>
                        </figcaption>
                    </figure><!-- innovation-box close -->
                    <figure class="innovation-box">
                        <div class="inno-img"><img loading="lazy" src='<?= CDN ?>assets/images/support.png'
                                alt="LivpureSmart Support Icon"></div>
                        <figcaption>
                            <h3 class="heading03">App Support</h3>
                            <p>Experience the convenience with innovative engineering like IOT enabled technology,
                                filter
                                health information and service support on your mobile screen. </p>
                        </figcaption>
                    </figure><!-- innovation-box close -->
                    <div class="clear"></div>
                    <p>The machine and servicing are both managed and provided by Livpure Private Limited.</p>
                </div>
            </div>
        </section>
        <!-- innovation-section close --->


        <section class="section best-purchase-section active smartDealSection prodcutInformation">
            <div class="container">
                <h2 class="heading02 ">A Smart deal, Guaranteed!</h2>
                <p>Get a worry-free supply of RO filtered pure water. That too at a much less price than branded water
                    jars
                    or the best water purifier.</p>
                <ul class="deal-list">
                    <li>
                        You don’t buy the water purifier or pay for a water jar.
                        That’s saving <i class="rupee">`</i> 9000-15000 every year.
                    </li>
                    <li>
                        Real time water quality check or filter replacement at no extra cost.
                    </li>
                    <li>
                        Just one phone call and we take care of installing the RO device free of cost.
                    </li>
                    <li>Pay for what you drink</li>
                </ul>

                <div class="button__group hideOnDesktop">
                    <a href="javascript:void(0);" class="active" id="waterJar">Livpure Smart vs Water jars</a>
                    <a href="javascript:void(0);" id="otherPuri">Livpure Smart vs Other purifier</a>
                </div>
                <!--mobile buttons -->

                <div class="productOuter">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="cardBx lsh__card">
                                <h5>Livpure Smart</h5>
                                <div class="imgBx">
                                    <img loading="lazy" src="<?= CDN ?>assets/images/bolt-and-zinger-nlp-new.webp"
                                        alt="Livpure Smart">
                                </div>

                                <div class="description">
                                    <ul>
                                        <li>
                                            <span>Real-time Water Quality Check</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/check-icon-trans.svg"
                                                alt="check icon">
                                        </li>
                                        <li>
                                            <span>Zero Buying Cost</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/check-icon-trans.svg"
                                                alt="check icon">
                                        </li>
                                        <li>
                                            <span><i class="rupee">`</i> 0.5 For 999 Litres per Month</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/check-icon-trans.svg"
                                                alt="check icon">
                                        </li>
                                        <li>
                                            <span>Zero Installation Cost</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/check-icon-trans.svg"
                                                alt="check icon">
                                        </li>
                                        <li>
                                            <span>Zero Maintenance Cost</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/check-icon-trans.svg"
                                                alt="check icon">
                                        </li>
                                        <li>
                                            <span>Automatic Service Schedule</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/check-icon-trans.svg"
                                                alt="check icon">
                                        </li>
                                        <li>
                                            <span>Real-time Filter health Check</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/check-icon-trans.svg"
                                                alt="check icon">
                                        </li>
                                        <li>
                                            <span>Continuous UV Filtration</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/check-icon-trans.svg"
                                                alt="check icon">
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!--col-->

                        <div class="col-md-4 water__jar">
                            <div class="cardBx">
                                <h5>Water Jars</h5>
                                <div class="imgBx">
                                    <img loading="lazy" src="<?= CDN ?>assets/images/water-jar-new-nlp.webp"
                                        alt="Water Jar">
                                </div>

                                <div class="description">
                                    <ul>
                                        <li>
                                            <span>Questionable</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/question-red-bg.svg"
                                                alt="icon">
                                        </li>
                                        <li>
                                            <span>NA</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/circle-close-gray.svg"
                                                alt="icon">
                                        </li>
                                        <li>
                                            <span><i class="rupee">`</i> 2 - <i class="rupee">`</i> 3 Per Litre</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/up-arrow-red-bg.svg"
                                                alt="icon" class="uparrowImg">
                                        </li>
                                        <li>
                                            <span>NA</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/circle-close-gray.svg"
                                                alt="icon">
                                        </li>
                                        <li>
                                            <span>NA</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/circle-close-gray.svg"
                                                alt="icon">
                                        </li>
                                        <li>
                                            <span>NA</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/circle-close-gray.svg"
                                                alt="icon">
                                        </li>
                                        <li>
                                            <span>NA</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/circle-close-gray.svg"
                                                alt="icon">
                                        </li>
                                        <li>
                                            <span>NA</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/circle-close-gray.svg"
                                                alt="icon">
                                        </li>

                                    </ul>

                                </div>
                            </div>
                        </div>
                        <!--col-->

                        <div class="col-md-4 other__purifier">
                            <div class="cardBx">
                                <h5>Other Purifier</h5>
                                <div class="imgBx">
                                    <img loading="lazy" src="<?= CDN ?>assets/images/other-ro.webp" alt="Purifier">
                                </div>

                                <div class="description">
                                    <ul>
                                        <li>
                                            <span>Questionable</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/question-red-bg.svg"
                                                alt="icon">
                                        </li>
                                        <li>
                                            <span><i class="rupee">`</i> 15000+ Buying Cost</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/up-arrow-red-bg.svg"
                                                alt="icon" class="uparrowImg">
                                        </li>
                                        <li>
                                            <span><i class="rupee">`</i> 4 - <i class="rupee">`</i> 5 Per Litre</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/up-arrow-red-bg.svg"
                                                alt="icon" class="uparrowImg">
                                        </li>
                                        <li>
                                            <span>Varying installation costs</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/up-arrow-red-bg.svg"
                                                alt="icon" class="uparrowImg">
                                        </li>
                                        <li>
                                            <span><i class="rupee">`</i> 4000 to <i class="rupee">`</i> 5000 AMC</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/up-arrow-red-bg.svg"
                                                alt="icon" class="uparrowImg">
                                        </li>
                                        <li>
                                            <span>Full of Hassle & Manual</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/sad-emoji.svg" alt="icon">
                                        </li>
                                        <li>
                                            <span>NA</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/circle-close-gray.svg"
                                                alt="icon">
                                        </li>
                                        <li>
                                            <span>Questionable</span>
                                            <img loading="lazy" src="<?= CDN ?>assets/images/question-red-bg.svg"
                                                alt="icon">
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!--col-->
                    </div>
                    <!--row-->
                </div>
                <!--productOuter-->

            </div>
            <!--container-->
        </section><!-- best-purchase-section close -->



        <section class="productSection">
            <div class="container">
                <div class="productTabBx">
                    <h2 class="heading02 text-center">Top of the line Models Bolt & Zinger</h2>
                    <div class="row">
                        <div class="col-md-4"></div>
                        <div class="col-md-8">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link active" id="bolt-tab" data-toggle="tab" href="#BoltMin"
                                        role="tab" aria-controls="bolt" aria-selected="true">Bolt Mineraliser</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="zinger-tab" data-toggle="tab" href="#zingerCuHot" role="tab"
                                        aria-controls="zinger" aria-selected="false">Zinger Copper Hot</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!--row-->

                    <div class="tab-content" id="myTabContent1">
                        <div class="tab-pane fade show active" id="BoltMin" role="tabpanel"
                            aria-labelledby="zinger-tab">
                            <div class="row">
                                <div class="col-md-4 text-center"><img loading="lazy"
                                        src="<?= CDN ?>assets/images/bolt-product-nlp.webp" alt="product"></div>
                                <div class="col-md-8">
                                    <p>
                                        Bolt | 3-in-1 Advantage | RO + UV + Mineraliser Embrace the healthy life with
                                        100% pure water. Experience lifetime happiness with best-in-class water purifies
                                        with 3-in-1 Advantage. With our assured quality and prompt services, you can say
                                        goodbye to all hassles of buying a water purifier and say hello to Livpure
                                        Smart.
                                    </p>
                                    <a href="<?= base_url() . 'product/bolt-mineraliser' ?>"
                                        class="btn explore-heka-btn prodcutKnowMoreBtn">Know More </a>
                                </div>
                            </div>
                            <!--row-->

                        </div>
                        <!--Tab 1-->

                        <div class="tab-pane fade" id="zingerCuHot" role="tabpanel" aria-labelledby="zinger-tab">
                            <div class="row">
                                <div class="col-md-4 text-center"> <img loading="lazy"
                                        src="<?= CDN ?>assets/images/zinger_copper_new_nlp.webp" alt="product">
                                </div>
                                <div class="col-md-8">
                                    <p>
                                        Zinger Copper Hot provides you water at three different temperatures. You get
                                        warm, hot and ambient water as per your needs with just one touch. The RO+UV+UF
                                        water purifier comes with a copper cartridge that adds the goodness of natural
                                        copper to provide you clean and healthy drinking water. With the in-tank UV
                                        sterilization, you get clean water even after storing water for a few days.
                                    </p>
                                    <a href="<?= base_url() . 'product/zinger-copper-hot' ?>"
                                        class="btn explore-heka-btn prodcutKnowMoreBtn">Know More </a>
                                </div>
                            </div>
                            <!--row-->
                        </div>

                    </div>
                    <!--tab content -->


                </div>
                <!--productTabBx-->

            </div>
            <!--container-->
        </section>
        <!--Tab Section-->
        <!-- Happy Customer -->
        <div class="demo happy__customer" id="happycus_hide">
            <div class="container">
                <!-- <div class="row"> -->
                <div class="col-md-12">
                    <h2 class="text-center customer-heading heading02" id="happycus"><span>Happy Customer</span></h2>
                    <div class="glider-contain multiple">
                        <button class="glider-prev">
                            <img src="<?= CDN ?>assets/images/ic_keyboard.png" >
                        </button>

                        <div class="glider">
                            <div class="testimonial">
                                <div class="testimonial-content">
                                    <p class="description">
                                    <div id="circle1" class="circle1">
                                        <img loading="lazy" class="face-img lazy lazymobile"
                                            src="<?= CDN ?>assets/images/Kiran.jpg" alt="Happy Customer">
                                    </div>
                                    <div class="mySlides" style="    display: block;
                            background-color: rgb(255, 255, 255);">
                                        <p class="text-center custom-para">Kiran Mathew</p>
                                        <p class="text-center custom-para1">Gurgaon</p>
                                        <p class="custom-para2"> Leader in Rental RO segment - bringing out an of the
                                            blue
                                            concept and doing the best in industry. During these challenging times of
                                            Covid
                                            they've been fentabulous in terms of service. Nominal cost involved for
                                            having
                                            purified water at the comfort of your home, good job Livpure Smart team!</p>
                                        <p class="star__rating">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        </p>
                                    </div>

                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="testimonial-content">
                                    <div id="circle2" class="circle1">
                                        <img loading="lazy" class="face-img lazy lazymobile"
                                            src="<?= CDN ?>assets/images/Nitasha.jpg" alt="Happy Customer">
                                    </div>
                                    <div class="mySlides1" style="    display: block;
                            background-color: rgb(255, 255, 255);">
                                        <p class="text-center custom-para">Nitasha Rai</p>
                                        <p class="text-center custom-para1">Bengaluru</p>
                                        <p class="custom-para2">A human body is 75% water and when it comes to quality I
                                            only trust Livpure Smart. All I did was, waited for 48 hours and rest
                                            everything
                                            was taken care of. Zero Delivery/Installation/Maintenance charges and zero
                                            follow-ups</p>
                                        <p class="star__rating">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="testimonial-content">
                                    <div id="circle3" class="circle1">
                                        <img loading="lazy" class="face-img lazy lazymobile"
                                            src="<?= CDN ?>assets/images/Akash.jpg" alt="Happy Customer">
                                    </div>
                                    <div class="mySlides2" style="    display: block;
                            background-color: rgb(255, 255, 255);">
                                        <p class="text-center custom-para">Akash sahani</p>
                                        <p class="text-center custom-para1">Mumbai</p>
                                        <p class="custom-para2">Great service by Livpure Smart. Very economical, 100%
                                            Hassle
                                            Free and timely maintenance. Everything will be taken care by Livpure,
                                            Really
                                            appreciate the effort of the Livpure Smart team.</p>
                                        <p class="star__rating">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="testimonial-content">
                                    <div id="circle4" class="circle1">
                                        <img loading="lazy" class="face-img lazy lazymobile"
                                            src="<?= CDN ?>assets/images/Deepak.jpg" alt="Happy Customer">
                                    </div>
                                    <div class="mySlides3" style="    display: block;
                            background-color: rgb(255, 255, 255);">
                                        <p class="text-center custom-para">Deepak Jain</p>
                                        <p class="text-center custom-para1">New Delhi</p>
                                        <p class="custom-para2">Being a fitness enthusiast myself, I know how important
                                            it
                                            is to keep myself hydrated with pure water. For my drinking water needs, I
                                            always trust on LivPure smart. No tension, high investment, budget friendly,
                                            RO
                                            water purifier.</p>
                                        <p class="star__rating">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial">
                                <div class="testimonial-content">
                                    <div id="circle5" class="circle1">
                                        <img loading="lazy" class="face-img lazy lazymobile"
                                            src="<?= CDN ?>assets/images/Gopal.jpg" alt="Happy Customer">
                                    </div>
                                    <div class="mySlides4" style="    display: block;
                            background-color: rgb(255, 255, 255);">
                                        <p class="text-center custom-para">Panchugopal Mandal</p>
                                        <p class="text-center custom-para1">Hyderabad</p>
                                        <p class="custom-para2">It was very good experience with livpure RO, smooth
                                            installation process and also water quality is very good. I'm very happy to
                                            bought Livpure smart RO.</p>
                                        <p class="star__rating">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <button class="glider-next">
                            <img src="<?= CDN ?>assets/images/ic_keyboard_arrow_right.png" >
                        </button>

                        <div id="dots" class="glider-dots"></div>
                    </div>
                </div>
            </div>
            <!-- </div> -->
        </div>
        <!-- Happy Customer -->

        <div class="step__container">
            <div class="container">
                <h2 class="heading-nlp">5 easy steps to get a <br> Water Purifier on Subscription</h2>
                <div class="card__parent">
                    <div class="card__child">
                        <div class="circleBx">
                            <img loading="lazy" src="<?= CDN ?>assets/images/notes-icon.svg" alt="notes">
                        </div>
                        <article>
                            <h5>Step-1</h5>
                            <p><b>Sign Up</b> & choose <b>plan</b></p>
                        </article>
                    </div>
                    <!--card__child-->

                    <div class="card__child">
                        <div class="circleBx">
                            <img loading="lazy" src="<?= CDN ?>assets/images/address-icon.svg" alt="icon">
                        </div>
                        <article>
                            <h5>Step-2</h5>
                            <p>Add Installation <b>Address</b></p>
                        </article>
                    </div>
                    <!--card__child-->

                    <div class="card__child">
                        <div class="circleBx">
                            <img loading="lazy" src="<?= CDN ?>assets/images/payment-icon-new.svg" alt="icon">
                        </div>
                        <article>
                            <h5>Step-3</h5>
                            <p>Complete your <b>payment</b></p>
                        </article>
                    </div>
                    <!--card__child-->

                    <div class="card__child">
                        <div class="circleBx">
                            <img loading="lazy" src="<?= CDN ?>assets/images/document-icon.svg" alt="document-icon">
                        </div>
                        <article>
                            <h5>Step-4</h5>
                            <p>Upload your <b>KYC documents</b></p>
                        </article>
                    </div>
                    <!--card__child-->

                    <div class="card__child">
                        <div class="circleBx">
                            <img loading="lazy" src="<?= CDN ?>assets/images/van-icon.svg" alt="van-icon">
                        </div>
                        <article>
                            <h5>Step-5</h5>
                            <p>Delivery & installation <b>within 72hrs</b></p>
                        </article>
                    </div>
                    <!--card__child-->
                </div>
            </div>
        </div> <!-- step__container -->




    </main><!-- main-wrapper close -->

    <?php
    $this->load->view('common/footer');
    ?>

    <script>
        var asyncStyleSheets = [
            '<?= CDN ?>assets/css/bootstrap.min.css',
            '<?php echo CDN ?>assets/css/header.css?version=<?= version ?>'
        ];

        for (var i = 0; i < asyncStyleSheets.length; i++) {
            var link = document.createElement('link');
            link.setAttribute('rel', 'stylesheet');
            link.setAttribute('href', asyncStyleSheets[i]);
            document.head.appendChild(link);
        }
    </script>

    <script src="<?php echo CDN ?>assets/js/bootstrap.min.js" defer></script>
    <!-- bootstrap js-->
    <script src="https://cdn.jsdelivr.net/npm/glider-js@1/glider.min.js"></script>

    <script>
        new Glider(document.querySelector('.glider'), {
            // Mobile-first defaults
            slidesToShow: 1,
            slidesToScroll: 1,
            scrollLock: true,
            dots: '#dots',
            itemWidth: 150,
            arrows: {
                prev: '.glider-prev',
                next: '.glider-next'
            },
            responsive: [{
                // screens greater than >= 775px
                breakpoint: 775,
                settings: {
                    // Set to `auto` and provide item width to adjust to viewport
                    slidesToShow: 'auto',
                    slidesToScroll: 'auto',
                    itemWidth: 150,
                    duration: 0.25
                }
            }, {
                // screens greater than >= 1024px
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                }
            }]
        })
        // removed opening and closing script tags
        jQuery.extend(jQuery.expr[':'], {
            focusable: function (el, index, selector) {
                return $(el).is('a, button, :input, [tabindex]');
            }
        });
        $(document).on('keypress', 'input,select', function (e) {
            if (e.which == 13) {
                e.preventDefault();
                var $canfocus = $(':focusable');
                var index = $canfocus.index(document.activeElement) + 1;
                if (index >= $canfocus.length) index = 0;
                $canfocus.eq(index).focus();
            }
        });
        // removed opening and closing script tags
        $(document).ready(function () {
            //Change water jar to purifier
            let waterJar = $('.prodcutInformation .row > div[class^="col-"].water__jar');
            let otherJar = $('.prodcutInformation .row > div[class^="col-"].other__purifier');

            $("#waterJar").on('click', function () {
                waterJar.css('display', 'inline-block');
                otherJar.hide();
            });
            $("#otherPuri").on('click', function () {
                otherJar.css('display', 'inline-block');
                waterJar.hide();
            });
            //Active Class compare watar jar && purifier
            $(".button__group a").click(function (e) {
                $(".button__group a").removeClass("active");
                $(this).addClass("active");
            });
        });
        $('#toggleClass').click(function () {
            $("div").removeClass("nlp_mob-hide");
        });
        $('#toggleClass1').click(function () {
            $("div").removeClass("nlp_mob-hide");
        });
        // removed opening and closing script tags
        $("#username").keyup(function () {
            //document.getElementById("submit_button").disabled = false;
            $("#username").parent().next(".namevalidation").remove();
        });
        $(document).on('keypress', '#username', function (event) {
            var regex = new RegExp("^[a-zA-Z ]+$");
            var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
            if (!regex.test(key)) {
                event.preventDefault();
                return false;
            }
        });
        // removed opening and closing script tags

        // removed opening and closing script tags
        jQuery.extend(jQuery.expr[':'], {
            focusable: function (el, index, selector) {
                return $(el).is('a, button, :input, [tabindex]');
            }
        });
        $(document).on('keypress', 'input,select', function (e) {
            if (e.which == 13) {
                e.preventDefault();
                // Get all focusable elements on the page
                var $canfocus = $(':focusable');
                var index = $canfocus.index(document.activeElement) + 1;
                if (index >= $canfocus.length) index = 0;
                $canfocus.eq(index).focus();
            }
        });
    </script>
    
    <script type="text/javascript">
        var searchRequest = null;
        $(function () {
            var length = 0;
            var minlength = 6;
            var maxlength = 8;

            $("#referralCode").on('keyup keydown', function (e) {
                e.which = 86; // 'V' key
                e.ctrlKey = true;
                $("#referralCode").trigger(e);
            });
            $("#referralCode").bind("change keyup input", function () {
                // handle events here


                //   $("#referralCode").keyup(function() {
                $("#referralCode").parent().next(".validation").remove(); // remove it
                value1 = $(this).val();
                console.log(value1);
                value = value1.toUpperCase();

                if (value.length >= minlength && value.length <= maxlength) {
                    console.log("value2", value);

                    if (searchRequest != null)
                        searchRequest.abort();

                    searchRequest = $.ajax({
                        type: "POST",
                        url: "<?php echo base_url(); ?>Auth/validateReferralCode",

                        dataType: 'application/json; charset=utf-8',
                        data: {
                            'referralCode': value
                        },

                        success: function (result) { },

                        error: function (xhr, ajaxOptions, thrownError) {

                            if (thrownError != 'abort') {
                                var refferalstatus = JSON.parse(xhr.responseText);
                                if (refferalstatus.success == true) {
                                    $("#referralCode").parent().after("<div class='validation' style='color:#4caf50 !important;padding-top: 1px;margin-left: 20px;'>" + refferalstatus.message + "</div>");
                                    $('#submit_button').prop('disabled', false);

                                } else if (refferalstatus.success == false) {

                                    $("#referralCode").parent().after("<div class='validation' style='color:red;padding-top: 1px;margin-left: 20px;'>" + refferalstatus.message + "</div>");

                                    $('#submit_button').prop('disabled', true);
                                }
                            }

                        }
                    });
                } else if (value.length == 0) {


                    $('#submit_button').prop('disabled', false);

                } else if (value.length >= minlength || value.length >= maxlength) {


                    $("#referralCode").parent().after("<div class='validation' style='color:red;padding-top: 1px;margin-left: 20px;'>" + "Please enter valid referral code" + "</div>");
                    $('#submit_button').prop('disabled', true);

                } else if (value.length > 0 && value.length < 6) {
                    $("#referralCode").parent().after("<div class='validation' style='color:red;padding-top: 1px;margin-left: 20px;'>" + "Please enter valid  referral code" + "</div>");
                    $('#submit_button').prop('disabled', true);
                }
            });


        });

        $('#toggleClass').click(function () {
            $("div").removeClass("nlp_mob-hide");
        });
        $('#toggleClass1').click(function () {
            $("div").removeClass("nlp_mob-hide");
        });
        $("#username").keyup(function () {
            $("#username").parent().next(".namevalidation").remove();
        });

        $(document).ready(function () {

             $("#terms").prop("checked", true);
            //Change water jar to purifier
            let waterJar = $('.prodcutInformation .row > div[class^="col-"].water__jar');
            let otherJar = $('.prodcutInformation .row > div[class^="col-"].other__purifier');

            $("#waterJar").on('click', function () {
                waterJar.css('display', 'inline-block');
                otherJar.hide();
            });

            $("#otherPuri").on('click', function () {
                otherJar.css('display', 'inline-block');
                waterJar.hide();
            });

            //Active Class compare watar jar && purifier
            $(".button__group a").click(function (e) {
                $(".button__group a").removeClass("active");
                $(this).addClass("active");
            });
        }) //doc ready
        function resendOtp(phone, userId) 
        {
            $('.validation').css('display', 'none');
            $('#resendotptag').css("pointer-events", "none");
            var url = `<?php echo base_url(); ?>ajax/sendLoginotp`;
            $.ajax({
                type: "POST",
                url:url,
                data: {
                    'phone': phone,
                    'userId': userId
                },
                success: function(response) {
                    resendphone = JSON.parse(response);
                    $('#resendotptag').css("pointer-events", "unset");
                    const inputs = document.querySelectorAll('#otpbox > *[id]');
                    for (let i = 0; i < inputs.length; i++) {
                        inputs[i].value = '';
                        if (i !== 0) inputs[i - 1].focus();
                    }
                    $('.errormsg').css("display", "none");
                    if (resendphone.status == true && resendphone.statusCode == 200) {
                        var sendPhoneOtp = true;
                        $('.loginerror').hide();
                        messageShowHide('loginsuccess',resendphone.message);
                    }else if(resendphone.statusCode == '201'){
                        var sendPhoneOtp = false;
                        $('.loginsuccess').hide();
                        messageShowHide('loginerror',resendphone.message);
                    }else{
                        var sendPhoneOtp = false;
                        $(".loginerror").text(resendphone.message).show();
                    }

                    if (sendPhoneOtp == true) {
                        var timeLeft = 30;
                        var elem = document.getElementById('seconds');
                        var timerId = setInterval(Countdown, 1000);
                        $("#otptag").css('display', 'none');
                        $("#resendotp").css('display', 'block');
                        function Countdown() {
                            if (timeLeft == -1) {
                                clearTimeout(timerId);
                                $('#resendotp').css('display', 'none');
                            } else {
                                elem.innerHTML = '0' + '0' + ":" + timeLeft;
                                timeLeft--;
                            }
                        }
                        setTimeout(function() {
                            $('#resendotp').css('display', 'none');
                            $("#otptag").css('display', 'block');
                        }, 30000);
                    }
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    // alert(xhr.status);
                }
            });
    }
    const inputs = document.getElementById("otpbox");
    if (inputs) {
        inputs.addEventListener("input", function(e) {

          
            const target = e.target;
            const val = target.value;

            if (isNaN(val)) {
                target.value = "";
                return;
            }

            if (val != "") {
                $('.errormsg').css("display", "none");
                const next = target.nextElementSibling;
                if (next) {
                    next.focus();
                }
            }
        });

        inputs.addEventListener("keyup", function(e) {
            const target = e.target;
            const key = e.key.toLowerCase();

            if (key == "backspace" || key == "delete") {
                target.value = "";
                const prev = target.previousElementSibling;
                if (prev) {
                    prev.focus();
                }
                return;
            }
        });
    }

    document.getElementById('username').addEventListener('input', function() {       
        let value = this.value.trim(); // Remove leading and trailing spaces
        let words = value.split(/\s+/); // Split the input by whitespace
        if (value === '') {           
            this.setCustomValidity('Please enter the name'); // Show an error message
        } else {            
            this.setCustomValidity(''); // Show an error message
        }
    });

    </script>

</body>

</html>