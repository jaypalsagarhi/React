<?php
    $actual_link = $_SERVER["REQUEST_URI"];
    $citylist = cityList();
    $oldcitylist = oldCityList();
    $newCityList = newCityList();

  if (strpos($actual_link, 'index') !== false) { echo 'true'; }
    $_SESSION['utm_source'] = (isset($_SESSION['utm_source'])) ? $_SESSION['utm_source'] : "";
    $_SESSION['utm_medium'] = (isset($_SESSION['utm_medium'])) ? $_SESSION['utm_medium'] : "";
    $_SESSION['utm_campaign'] = (isset($_SESSION['utm_campaign'])) ? $_SESSION['utm_campaign'] : "";

    $_SESSION['utm_source'] = (isset($_REQUEST['utm_source'])) ? $_REQUEST['utm_source'] : $_SESSION['utm_source'];
    $_SESSION['utm_medium'] = (isset($_REQUEST['utm_medium'])) ? $_REQUEST['utm_medium'] : $_SESSION['utm_medium'];
    $_SESSION['utm_campaign'] = (isset($_REQUEST['utm_campaign'])) ? $_REQUEST['utm_campaign'] : $_SESSION['utm_campaign'];
    if (empty($_SESSION['utm_source'])) {
        $_SESSION['utm_source'] = (isset($_COOKIE['utm_source'])) ? $_COOKIE['utm_source'] : $_SESSION['utm_source'];
    }
    if (empty($_SESSION['utm_medium'])) {
        $_SESSION['utm_medium'] = (isset($_COOKIE['utm_medium'])) ? $_COOKIE['utm_medium'] : $_SESSION['utm_medium'];
    }
    if (empty($_SESSION['utm_campaign'])) {
        $_SESSION['utm_campaign'] = (isset($_COOKIE['utm_campaign'])) ? $_COOKIE['utm_campaign'] : $_SESSION['utm_campaign'];
    }
    $showMinimalHeader = ($page === 'address' || $page === 'review' || $page === 'subscription' || $page === 'nlpaddress' || $page === 'nlpreview');
    $isAuthPage = ($page === 'auth'); ?>
<style>
  html{overflow-y:scroll}header{box-shadow:0 8px 16px 0 rgba(0,0,0,.2)}.brd_section{padding:0}.banner-section{position:relative;padding-top:0}.bnavbar{margin-bottom:0;background-color:#fff;padding:0;position:relative}.bnavbar-container{display:flex!important;justify-content:space-between!important;padding:0 0!important;flex-wrap:unset!important}ul.nav.bnavbar-nav.bnavbar-right{display:flex;flex-direction:row;flex-wrap:unset}#main-bnavbar .bnavbar-collapse_d{flex-basis:unset;flex-grow:unset;margin:0}div#bnavbar{align-self:center}.bnavbar .bnavbar-nav li a{color:#452f8a!important;font-family:NeoSansPro-Bold;background:#fff!important;text-decoration:none!important;font-size:14px;}.bnavbar .bnavbar-nav li a:hover{color:#f37a21!important}.bnavbar-brand{font-size:25px;transition:all .2s ease-out;color:rgba(200,100,0,.8)}.sign_loginSection{display:flex;justify-content:center;align-items:center}.bnavbar-scroll{opacity:1}.enq_btn{background:#452f8a;box-shadow:0 1px 2px #452f8a;color:#fff!important;margin-left:10px;font-family:NeoSansPro-Regular!important;border-radius:3px;font-weight:700;font-size:14px!important;line-height:14px;height:33px}button{outline:0;background:0 0;border:none}.dropdown,.dropdown_product{position:relative;display:inline-block;align-self:center;font-family:NeoSansPro-Bold}#help_drpdown{margin-left:35px}#water-purifier-dropdown .dropdown-content{left:25px!important;background:#fff!important}.dropdown-content{display:none;position:absolute;background-color:#f9f9f9;min-width:135px;box-shadow:0 8px 16px 0 rgba(0,0,0,.2);margin-left:-29px;padding:0 0;top:25px;left:-5PX;border-radius:10px;line-height:23.48px}button#bnavbar-toggle{display:none}.bnavbar-collapse_d:before,.bnavbar:before{content:none}.container:after,.bnavbar:after{display:none}.container{max-width:1140px}.dropdown_productContent{display:none;position:absolute;background-color:#f9f9f9;min-width:205px;box-shadow:0 8px 16px 0 rgba(0,0,0,.2);margin-left:-29px;padding:0 0;top:-10px;left:79px;border-radius:10px}.dropdown-content a,.dropdown_productContent a{color:#000;padding:10px 16px;text-decoration:none;display:block}.dropdown:hover .dropdown-content,.dropdown_product:hover .dropdown_productContent{z-index:9999;color:#f37a21}.dropdown-content a:hover,.dropdown_productContent a:hover{color:#f37a21!important;background:#fff!important}.dropdown.active .dropdown-content,.dropdown_product.active .dropdown_productContent{display:block;z-index:9999;color:#f37a21}.dropdown:before{top:3px;right:-22px}.dropdown_product:before{top:-15px;right:-32px;transform:rotate(267deg)}.dropdown:hover:before,.dropdown_product:hover:before{filter:invert(59%) sepia(81%) saturate(2568%) hue-rotate(349deg) brightness(103%) contrast(92%)}.dropdown-content a,.dropdown_productContent a{border-bottom:1px solid #452f8a}.dropdown-content a:first-child,.dropdown_productContent a:first-child{border-radius:15px 15px 0 0}.dropdown-content a:last-child,.dropdown_productContent a:last-child{border-bottom:0!important;border-radius:0 0 15px 15px}.bnavbar .bnavbar-nav li:hover{color:#f37a21}.dropdown.active,.dropdown_product.active{color:#f37a21!important}.dropdown.active:before,.dropdown_product.active:before{filter:invert(59%) sepia(81%) saturate(2568%) hue-rotate(349deg) brightness(103%) contrast(92%)}.container.bnavbar-container::before{content:none}.bnavbar-nav>li{color:#452f8a!important;font-family:NeoSansPro-Bold;font-size:14px}.overlay{background-color:rgba(0,0,0,.5);width:100%;height:100vh;position:absolute;top:60px}.hide{display:none!important}.show-drop-down{background:#f6f8fa;width:580px;position:absolute;right:80px;box-shadow:0 0 20px rgb(1 118 190 / 25%);top:65px;border-radius:10px;font-family:"Source Sans Pro",sans-serif!important;min-height:360px!important}.body-alert-message-city,.heading-container{display:flex;justify-content:space-between;align-items:center}.city-heading{font-size:17px;color:#442c8c;margin:15px;font-weight:600}.close-city-icon img{color:#9b9797;font-size:22px;padding-right:30px;cursor:pointer}.city-search{margin:0 10px}.city-search .form-group{position:relative}.city-search .form-group span{position:absolute;left:0;top:10px;color:#bdbdbd}.city-search input{border:none;padding-left:35px;box-shadow:none!important}.city-container{max-height:270px;overflow-y:scroll}.row-flex{justify-content:flex-start;align-items:center;margin-right:0!important;margin-left:0!important}.row-flex .col-sm-4{padding:0!important}.city-check{display:flex;align-items:center;justify-content:center}.city-check [type=radio]:checked,.city-check [type=radio]:not(:checked){position:absolute;left:-9999px}.city-check [type=radio]:checked+label,.city-check [type=radio]:not(:checked)+label{position:relative;line-height:20px;display:inline-block;padding:5px 30px 5px 40px;margin:10px;min-width:155px;font-size:14px;background:#ebf2fa;cursor:pointer}.city-check [type=radio]:checked+label{color:#442c8c;border:1px solid #442c8c;border-radius:5px}.city-check [type=radio]:not(:checked)+label{color:#000;border:1px solid #8592a6;border-radius:5px}.city-check [type=radio]:checked+label:before{content:'';position:absolute;left:10px;top:5px;width:18px;height:18px;border:1px solid #442c8c;border-radius:100%;background:#fff}.city-check [type=radio]:not(:checked)+label:before{content:'';position:absolute;left:10px;top:5 px;width:18px;height:18px;border:1px solid #ddd;border-radius:100%;background:#fff}.city-check [type=radio]:checked+label:after{content:'';width:12px;height:12px;background:#442c8c;position:absolute;top:8px;left:13px;border-radius:100%;-webkit-transition:.2s;transition:.2s}.city-check [type=radio]:not(:checked)+label:after{content:'';width:12px;height:12px;background:#f87da9;position:absolute;top:8px;left:13px;border-radius:100%;-webkit-transition:.2s;transition:.2s;opacity:0;-webkit-transform:scale(0);transform:scale(0)}.city-check [type=radio]:checked+label:after{opacity:1;-webkit-transform:scale(1);transform:scale(1)}.show-more-city{background:#fff;text-align:center;padding:5px 10px;margin:10px 10px 15px;border-radius:10px}.show-more-city p{margin-bottom:0;color:#8592a6;display:flex;justify-content:center;align-items:center;cursor:pointer}.show-more-city img{width:15px;margin-left:5px}.city-drop-down{border:1px solid #452f8a;border-radius:20px;cursor:pointer;display:inline-block}.city-drop-down .city-drop-inner{display:flex;justify-content:space-between;align-items:center;height:100%;padding:0 10px}.city-drop-down .city-drop-inner .city-left{display:flex;align-items:center;width:110px}.city-drop-down .city-drop-inner .city-left .city_name{margin:0;padding-left:5px;font-size:14px;font-weight:600;text-transform:capitalize;color:#452f8a}.desk-login-button{background:#fff0;color:#f37a21!important;display:flex!important;width:80px}.mediaicon li{text-align:end}#myDIV{text-align:start!important}@media (min-width:768px){.bnavbar-nav>li{margin-left:50px}.bnavbar-nav>li>a{padding:0;position:relative}.bnavbar-brand{padding:0;display:block}#top-social-menu{display:initial}.bnavbar-scroll{height:70px}.bnavbar-scroll #top-social-menu{display:none}.bnavbar-scroll .bnavbar-brand{height:70px;line-height:70px}.bnavbar-scroll .bnavbar-nav>li>a{opacity:1;padding:0;margin-top:0}.sign_loginSectionHead{display:none!important}.bnavbar-nav>li>a::after{position:absolute;top:80%;left:4px;width:80%;height:1px;background:#f37a21;content:'';opacity:0;transform:translateY(-10px)}.bnavbar-nav>li.b_active_b{position:relative}.bnavbar-nav>li.b_active_b::after{content:'';height:2px;background:#f37a21;position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:100%}.dropdown:hover .dropdown-content,.dropdown_product:hover .dropdown_productContent{display:block}li.showOnlyMobilePages{display:none}.fixed-header{position:fixed;top:0;width:100%;z-index:1000}}@media only screen and (max-width:1023px){#citymob-login{display:none}.city-drop-down{float:right;margin:7px 1px}}@media(max-width:768px){.overlay{height:350vh}.show-drop-down{width:100%;right:0}.city-check [type=radio]:not(:checked)+label{width:100px;min-width:auto;padding:5px 10px 5px 25px;font-size:11px}.city-check [type=radio]:checked+label:before,.city-check [type=radio]:not(:checked)+label:before{width:14px;height:14px;left:4px;top:8px}.city-check [type=radio]:checked+label{width:100px;min-width:auto;padding:5px 10px 5px 30px;font-size:11px}.city-check [type=radio]:checked+label:after{top:10px;left:6px;width:10px;height:10px}.user-account{margin-right:10px}.city-drop-down .city-drop-inner .city-left .city_name{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.city-drop-down .city-drop-inner .city-left{width:90px}.row-flex .col-sm-4{width:33.33%}#bnavbar{display:none}span.icon-bar{display:block;width:25px!important;height:2px!important;background:#452f8a;margin-top:4px!important;transition:.7s}.bnavbar-container{display:block!important}.bnavbar{padding:0}.login_newHead{display:none!important}.sign_newHead img{display:none}.bnavbar-header{display:flex;align-items:self-start}div#sign_upSectionHead{display:flex;justify-content:end;width:100%}.enq_btn{font-size:11px!important;margin-left:0!important;align-self:center}.sign_newHead{background:#452f8a;box-shadow:0 1px 2px #452f8a;color:#fff!important;font-family:NeoSansPro-Regular!important;border-radius:3px;font-weight:700;font-size:11px!important;line-height:22px;padding:5px;align-self:center;height:33px;width:76px;text-align:center;margin-left:5px;display:inline-block}.bnavbar-brand img{width:95%!important}ul.nav.bnavbar-nav.bnavbar-right{display:block;margin-bottom:0!important}.bnavbar-right li{padding:12px 17px;display:block;border-bottom:1px solid #452f8a;background:#fff}.nav>li>a{padding:0}.dropdown{margin-left:0}.sign_loginSection{position:absolute;right:11px;top:13px}#main-bnavbar .container{width:100%!important}.dropdown:before{top:16px;left:122px;z-index:999}.dropdown-content{width:38%;left:34px!important;top:39px}button.bnavbar-toggle.active .icon_first{transform:rotate(48deg);position:relative;top:3px;transition:.7s;height:3px!important}button.bnavbar-toggle.active .icon_hidden{display:none}button.bnavbar-toggle.active .icon_last{transform:rotate(137deg);position:relative;top:-3px;left:-1px;transition:.7s;height:3px!important}.banner-section .container{top:82px}.compare-box.active.water-jar-link img{width:60px;height:102px}.compare-box.water-purifiers-link img{width:56px;height:95px}button#bnavbar-toggle{display:block}#help_drpdown{margin-left:0}.bnavbar-nav{margin:0}#bnavbar{background:#fff!important}#bnavbar.active{display:block!important}.bnavbar-default .bnavbar-toggle .icon-bar{background-color:#452f8a}.bnavbar-default .bnavbar-toggle:focus,.bnavbar-default .bnavbar-toggle:hover{background-color:#fff}.bnavbar-default .bnavbar-toggle{border:none}#header .logo{margin:0!important;position:relative;line-height:14px}.bnavbar-container{padding:0!important}.bnavbar-toggle{position:relative;float:right;padding:9px 10px;margin-right:0;margin-top:8px;margin-bottom:8px;background-color:transparent;background-image:none;border:1px solid transparent;border-radius:4px;margin-right:0;margin-left:18px}.container>.bnavbar-header{margin-right:0;margin-left:0}.bnavbar-collapse_d.in{overflow-y:unset!important}main#main-wrapper{margin-top:0}#main-bnavbar .collapse_d:not(.show){display:none}#water-purifier-dropdown .dropdown-content{left:37px!important}#header{z-index:111!important}li#help_drpdown.dropdown:before{left:58px}#main-bnavbar .bnavbar-collapse_d{position:absolute;width:100%;margin:0}}@media(max-width:500px){.bnavbar-toggle{margin-left:0!important}}@media (max-width:365px){.city-drop-down .city-drop-inner .city-left{width:75px}.enq_btn,.sign_newHead{width:100%}}@media (max-width:350px){.city-drop-down .city-drop-inner .city-left{width:65px}#header .logo{margin-left:25px!important}.enq_btn{width:55%;vertical-align:middle}.sign_newHead{width:50px}}
  #bnavbar .arrow {
  border: solid #452f8a;
  border-width: 0 2px 2px 0;
  display: inline-block;
  padding: 3px;
}

.dropdown_productContent a {
    display: block !important;
}
#bnavbar .down {
  transform: rotate(45deg);
  -webkit-transform: rotate(45deg);
  margin-left: 8px;
  margin-bottom: 1px;

}
#bnavbar .right {
  transform: rotate(-45deg);
  -webkit-transform: rotate(-45deg);
}
#bnavbar .dropdown.active .w_purifier {
    border-color: #f37a21!important;
}
#bnavbar .dropdown_product.active .w_product {
    border-color: #f37a21 !important;
}

.fa-user-circle:before{
    content: none;
}
#water-purifier-dropdown a{
    display: inline-block;
}
</style>
<?php if(ENV=='PROD')
{ ?>
  <script type="text/javascript" src="https://cdn.moengage.com/webpush/moe_webSdk.min.latest.js"></script>
  <script type="text/javascript">
  Moengage = moe({
      app_id: "GVH6KZUQXZH0GYP8C95HOEWO"
  });
  </script>
  <!-- Google Tag Manager (noscript) -->
  <noscript>
      <iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo GTM_KEY; ?>" height="0" width="0"
          style="display:none;visibility:hidden"></iframe>
  </noscript>
  <!-- End Google Tag Manager (noscript) -->
    <script>
        if(typeof dataLayer != 'undefined'){
            dataLayer.push({
                event: "set_user_id",
                user_id: "<?php echo isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : '' ?>",
                user_type: "<?php echo isset($_SESSION['login_data']) ? 'signin' : 'guest' ?>"
            });
        }
    </script>
    <?php 
}
  if(isset($_SESSION['gta4_login_event'])){ // GA4 login Event ?>
        <script>
            window.dataLayer = window.dataLayer || [];
            dataLayer.push({
                'event': 'login',
                'userId': '<?= $_SESSION['login_data']['userId'] ?>',
                'loginType': '<?= $_SESSION['login_data']['loginType'] ?>'
            });   
            dataLayer.push({
                'event': 'set_user_id',
                'user_id': '<?= $_SESSION['login_data']['userId'] ?>',
                'event_fired': 'login',
                'user_type': 'signin'
            });
        </script>
    <?php unset($_SESSION['gta4_login_event']); }

    // GA4 signed_up Event
    if(isset($_SESSION['gta4_signup_event'])){ ?>
        <script >
        window.dataLayer = window.dataLayer || [];
        dataLayer.push({
            'event': 'signed_up',
            'userId':  '<?= $_SESSION['login_data']['userId']; ?>',
            'city': '<?= $_SESSION['login_data']['city']; ?>',
            'userName': '<?= $_SESSION['login_data']['userName']; ?>',
            'userEmail': '<?= $_SESSION['login_data']['email']; ?>',
            'mobileNumber': '<?= $_SESSION['login_data']['phone']; ?>',
            'pincode': '<?= $_SESSION['pincode']; ?>',
            'referralCode': '<?= $_SESSION['login_data']['referralCode']; ?>'
        });
            
        dataLayer.push({
            'event': 'set_user_id',
            'user_id': '<?= $_SESSION['login_data']['userId'] ?>',
            'event_fired': 'signed_up',
            'user_type': 'signin'
        });
        </script>
    <?php unset($_SESSION['gta4_signup_event']); }

    // GA4 select_item Event
    if(isset($_SESSION['gta4_product_event'])){ ?>
        <script>
            window.dataLayer = window.dataLayer || [];
            dataLayer.push({ ecommerce: null }); 
            dataLayer.push({
                'event': 'select_item',
                'planType': 'Silver',
                'ecommerce': {
                    'items': [{
                        'item_name': 'Live Pure Smart - Bolt/Envy',
                        'item_id': '12345', 
                        'price': '325.00',
                        'item_brand': 'Livpure Smart RO',
                        'item_category': 'RO Subscription',
                        'item_variant': 'Silver - 12 months',
                        'quantity': 1
                    }]
                }
            });
            dataLayer.push({
                'event': 'set_user_id',
                'user_id': '<?= $_SESSION['login_data']['userId'] ?>',
                'event_fired': 'select_item',
                'user_type': '<?php echo isset($_SESSION['login_data']) ? 'signin' : 'guest' ?>'
            });
        </script>
    <?php unset($_SESSION['gta4_product_event']); }

    // GA4 enquire_now Event
    if(isset($_SESSION['enquire_now'])){ ?>
        <script>
            window.dataLayer = window.dataLayer || [];
            dataLayer.push({
                'event': 'enquire_now',
                'user_id': '<?= $_SESSION['login_data']['userId'] ?>',
                'city': '<?= $_SESSION['enquire_now']["city"] ?>',
                'current_drinking_source': '<?= $_SESSION['enquire_now']["watersource"] ?>'
            });
            dataLayer.push({
                'event': 'set_user_id',
                'user_id': '<?= $_SESSION['login_data']['userId'] ?>',
                'event_fired': 'enquire_now',
                'user_type': '<?php echo isset($_SESSION['login_data']) ? 'signin' : 'guest' ?>'
            });
        </script>
    <?php unset($_SESSION['enquire_now']); }

    // GA4 refer_now Event
    if(isset($_SESSION['gta4_referNow_event'])){ ?>
        <script>
            window.dataLayer = window.dataLayer || [];
            dataLayer.push({
                'event': 'refer_now',
                'user_id': '<?= $_SESSION['login_data']['userId'] ?>',
                'city': '<?= $_SESSION['referrcity'] ?>',
                'referralCode': '<?= $_SESSION['referrcode'] ?>'
            });
            dataLayer.push({
                'event': 'set_user_id',
                'user_id': '<?= $_SESSION['login_data']['userId'] ?>',
                'event_fired': 'refer_now',
                'user_type': '<?php echo isset($_SESSION['login_data']) ? 'signin' : 'guest' ?>'
            });
        </script>
        <?php unset($_SESSION['gta4_referNow_event']);
        unset($_SESSION['referrcity']);;
    }

    // GA4 whatsapp_signup Event
    if(isset($_SESSION['whatsaap_signup'])){ ?>
        <script>
            window.dataLayer = window.dataLayer || [];
            dataLayer.push({
                'event': 'whatsapp_signup',
                'user_id': '<?= $_SESSION['login_data']['userId'] ?>',
                'city': '<?= $_SESSION['whatsaap_signup']["city"] ?>',
                'current_drinking_source': '<?= $_SESSION['whatsaap_signup']["watersource"] ?>'
            });
            dataLayer.push({
                'event': 'set_user_id',
                'user_id': '<?= $_SESSION['login_data']['userId'] ?>',
                'event_fired': 'whatsapp_signup',
                'user_type': '<?php echo isset($_SESSION['login_data']) ? 'signin' : 'guest' ?>'
            });
        </script>
    <?php unset($_SESSION['whatsaap_signup']); }
    
    if(isset($_COOKIE['city_request_callback_name'])){ ?>
        <script>
            window.dataLayer = window.dataLayer || [];
            dataLayer.push({
                'event': 'city_request_callback',
                'name': '<?= $_COOKIE['city_request_callback_name'] ?>',
                'city': '<?= $_COOKIE['city_request_callback_city'] ?>',
                'phone': '<?= $_COOKIE['city_request_callback_phone'] ?>',
                'email': '<?= $_COOKIE['city_request_callback_email'] ?>'
            });
            dataLayer.push({
                'event': 'set_user_id',
                'name': '<?= $_COOKIE['city_request_callback_name'] ?>',
                'city': '<?= $_COOKIE['city_request_callback_city'] ?>',
                'phone': '<?= $_COOKIE['city_request_callback_phone'] ?>',
                'email': '<?= $_COOKIE['city_request_callback_email'] ?>',
                'event_fired': 'city_request_callback',
                'user_type': '<?php echo isset($_SESSION['login_data']) ? 'signin' : 'guest' ?>'
            });
        </script>
        <?php 
        setcookie('city_request_callback_name', '', time() - 3600);
        setcookie('city_request_callback_city', '', time() - 3600);
        setcookie('city_request_callback_phone', '', time() - 3600);
        setcookie('city_request_callback_email', '', time() - 3600);
    }

    // GA4 purchase Event
    if(isset($_SESSION['gta4_purchase_event'])){
        if ($_SESSION['plan_order_data']['first_payment'] == true){
            $_SESSION['check_first_payment'] = "new";
            $amount = $_SESSION['plan_order_data']['plan_amount_paid']+'1499';
            unset($_SESSION['plan_order_data']['first_payment']);
        }else{
            $amount =  $_SESSION['plan_order_data']['plan_amount_paid'];
        }
        if(isset($_SESSION['appCouponAmount']) && $_SESSION['appCouponAmount'] != ''){
            $amount = $amount - $_SESSION['appCouponAmount'];
        }
        $purchase_type = ($_SESSION['check_first_payment'] == 'new') ? "New Subscription":"Subscription Renewal";//'RO',
        
        ?>
        <script>
            window.dataLayer = window.dataLayer || [];
            dataLayer.push({ ecommerce: null });  // Clear the previous ecommerce object.
            dataLayer.push({
                'event': 'purchase',
                'ecommerce': {
                    'transaction_id': '<?= $_SESSION['plan_order_data']['plan_order_id'] ?>',
                    'affiliation': 'Livpuresmart.com',
                    'value': '<?= $amount ?>',
                    'tax': '',
                    'shipping': '',
                    'currency': 'INR',
                    'coupon': '<?= $_SESSION['appCouponAmount'] ?>',
                    'payment_type':'',
                    'Payment_type_detail':'',
                    'emi_value':'<put EMI value here (optional if order is placed on EMI)>',
                    'emi_duration':'<?= $_SESSION['plan_order_data']['plan_duration'] ?>',
                    'purchase_type':'<?= $purchase_type ?>',//'RO',
                    'items': [{
                        'item_name': '<?= $_SESSION['plan_order_data']['plan_name'] ?>',
                        'item_id': '<?= $_SESSION['plan_order_data']['plan_id'].'_'.$_SESSION['plan_order_data']['plan_duration'] ?>',
                        'price': '<?= $_SESSION['plan_order_data']['plan_amount_paid'] ?>',
                        'item_brand': 'Livpuresmart.com',
                        'item_category': 'RO',
                        'quantity': '1'
                    }]
                }
            });
            dataLayer.push({
                'event': 'set_user_id',
                'user_id': '<?= $_SESSION['login_data']['userId'] ?>',
                'event_fired': 'set_user_id',
                'user_type': '<?php echo isset($_SESSION['login_data']) ? 'signin' : 'guest' ?>'
            });
        </script>
    <?php unset($_SESSION[' ']); }
    if(isset($_SESSION['ekycstep'])){ ?>
        <script>
            window.dataLayer = window.dataLayer || [];
            dataLayer.push({
                'event': 'ekyc_step_3',
                'question_1': '<?= $_SESSION['ekycstep']['q1choices'] ?>',
                'question_2': '<?= $_SESSION['ekycstep']['q2choices'] ?>',
                'question_3': '<?= $_SESSION['ekycstep']['q3choices'] ?>',
                'question_4': '<?= $_SESSION['ekycstep']['q6choices'] ?>',
                'question_5': '<?= $_SESSION['ekycstep']['q4choices'] ?>',
                'question_6': '<?= $_SESSION['ekycstep']['q5choices'] ?>'
            });
            dataLayer.push({
                'event': 'set_user_id',
                'user_id': '<?= $_SESSION['login_data']['userId'] ?>',
                'event_fired': 'ekyc_step_3',
                'user_type': '<?php echo isset($_SESSION['login_data']) ? 'signin' : 'guest' ?>'
            });
        </script>
    <?php unset($_SESSION['ekycstep']); } ?>

<header id="header">
    <div class="overlay hide"></div>
    <?php if($page == 'plan'){ ?>
    <div class="show-drop-down hide" id="head-city-select">
        <div class="heading-container">
            <div class="city-heading">Select your city</div>
            <div class="close-city-icon"><img src="<?= CDN ?>assets/images/close-icon_new.svg" ></div>
        </div>
        <div class="city-search">
            <div class="form-group has-search">
                <span class="fa fa-search form-control-feedback"></span>
                <input type="text" class="form-control" placeholder="Search your city">
            </div>
        </div>
        <div class="city-container city-container-header">
            <div class="body-alert-message body-alert-message-city">
                <div class="row row-flex">
                    <?php foreach($oldcitylist as $oldcities){?>
                    <div class="col-sm col-sm-4">
                        <div class="city-check" data-id="popup<?= str_replace(' ', '' ,$oldcities)?>">
                            <input type="radio" class="popup" id="popup<?= str_replace(' ', '' ,$oldcities)?>"
                                name="radio-group" value="<?= $oldcities ?>">
                            <label for="popup<?= str_replace(' ','' ,$oldcities)?>"><?=  $oldcities ?></label>
                        </div>
                    </div>
                    <?php } ?>
                    <?php foreach ($newCityList as $newcities){?>
                        <div class="col-sm col-sm-4">
                            <div class="city-check" data-planid="newcitypopup<?= str_replace(' ', '' ,$newcities)?>">
                                <input type="radio" id="newcitypopup<?=$newcities ?>" name="radio-group"
                                    value="<?=$newcities?>">
                                <label for="newcitypopup<?= $newcities ?>"><?=$newcities ?></label>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>            
        </div>
        <div class="show-more-city" id="b_see_more">
            <p class="show-more b_show_more">See More <span><img src="<?= CDN ?>assets/images/see_more_down.svg" ></span></p>
        </div>
    </div>
    <?php } ?>

	  <nav id="main-bnavbar" class="bnavbar bnavbar-default bnavbar-fixed-top ">
    <?php //echo ($showMinimalHeader) ? 'align-logo-center' : ''; ?>
			  <div class="container bnavbar-container">
          
          <div class="bnavbar-header">
            <button type="button" id="bnavbar-toggle" class="bnavbar-toggle b_collapsed" data-toggle="collapse_d" data-target="#bnavbar" aria-expanded="false" aria-controls="bnavbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar icon_first"></span>
              <span class="icon-bar icon_hidden"></span>
              <span class="icon-bar icon_last"></span>
            </button>
            <!-- <a class="bnavbar-brand" href="#"> -->
            <a href='<?php echo LOGO_URL_PATH ?>' class="bnavbar-brand logo  <?=!isset($_SESSION['login_data']) ? 'pre-login' : ''?> align-mob-logo">
              <img src='<?php echo CDN; ?>assets/images/newlogo.svg' data-src='<?php echo CDN; ?>assets/images/newlogo.svg' alt="Water Purifier on Rent" 
                title="Livpure Smart Water Purifier on Subscription" class="lazyload" loading="lazy" width="100" height="50" style="width: 75%;">
            </a>
				  </div>

          <?php 
          $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
          $actual_links = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
          if (!$showMinimalHeader) 
          { ?>
            
              <div id="bnavbar" class="bnavbar-collapse_d collapse_d">
                <ul class="nav bnavbar-nav bnavbar-right"> 
                  <li class="<?php echo ($page == '') ? 'b_active_b' : ''; ?>"><a href="<?php echo LOGO_URL_PATH ?>">Home</a></li>
                
                  <li class="dropdown <?php echo ( ($this->uri->segment(1) == 'product') || (base_url() == $actual_link) || (base_url() == $actual_links) )? 'b_active_b':''; ?>" id="water-purifier-dropdown"> <a href="<?php echo base_url(); ?>">Water Purifier</a>  <span class="arrow down w_purifier"></span>
                    <div class="dropdown-content">
                      <a href="<?php echo base_url() . 'product'; ?>" style="display: inline-block; border:0px!important; border-radius: 10px!important;">Product</a>
                      <div class="dropdown_product" id="RO_dropdown" ><span class="arrow right w_product"></span>
                        <div class="dropdown_productContent">
                          <a href="<?php echo base_url() . 'product/bolt-mineralizer'; ?>">Bolt Mineralizer</a>
                          <!-- <a href="<?php echo base_url() . 'product/bolt-copper'; ?>">Bolt Copper Mineralizer</a> -->
                          <a href="<?php echo base_url() . 'product/zinger-copper-hot'; ?>">Zinger Copper Hot</a>
                          <a href="<?php echo base_url() . 'product/stealth-under-sink'; ?>">Stealth Under the Sink</a>
                          <a href="<?php echo base_url() . 'product/hydroboost'; ?>">Hydroboost</a>
                        </div>
                      </div>
                    </div>
                  </li>
                  <?php if ((isset($_SESSION['login_data']['cod_status']) && $_SESSION['login_data']['cod_status'] == "pending")) { ?>

                  <?php } else { ?>
                    <li class=" <?php echo ($page == 'plan') ? 'b_active_b' : ''; ?>"><a href="<?php echo base_url() . 'plan'; ?>">Plans</a></li>
                  <?php } ?>
                  
                  <li class="<?php echo ($page == 'referral') ? 'b_active_b' : ''; ?>"><a href="<?php echo base_url() . 'referral?utm_source=referral-page&utm_medium=referral-page&utm_campaign=referral_page&utm_id=Referral'; ?>">Refer & Earn</a></li>

                  <li class="dropdown <?php echo ($page == 'howitwork') ? 'b_active_b' : ''; ?>" id="help_drpdown"> Help <span class="arrow down w_purifier"></span>
                    <div class="dropdown-content">
                      <a href="<?php echo  base_url().'how-it-works'; ?>" data-scroll="#smart-steps">How it Works</a>
                      <?php if(!isset($_SESSION['login_data'])) {?>
                      <a href="<?php echo LOGO_URL_PATH . 'faqs'; ?>">FAQs</a>
                      <?php } ?>
                      <a href="https://www.livpuresmart.com/blog" target="_blank">Blog</a>
                    </div>
                  </li>

                  <?php if (isset($_SESSION['login_data']) && ($_SESSION['login_data'] != '')) {?>
                  <li class="<?php echo ($page == 'dashboard') ? 'b_active_b' : ''; ?>"><a href="<?php echo base_url() . 'dashboard'; ?>" class="options-gap-x">Profile</a></li>
                  <?php } else {?>
                  <li class="showOnlyMobilePages">
                    <a href="<?php echo base_url() . 'auth?type=1'; ?>" class="desk-login-button options-gap-x login_newHeadMob" style="margin:0"> 
                       Log In
                    </a>
                  </li>

                  <?php }?>

                </ul>
              </div>


              <div id="sign_upSection" class="sign_loginSection">
                <?php if (!isset($_SESSION['login_data']) && strtolower($this->router->class) != 'auth' && strtolower($this->router->class) != 'welcome' && strtolower($this->router->class) != 'product') 
                { ?>
                    
                    <a href="<?php echo base_url() . 'auth?type=1'; ?>" class="desk-login-button options-gap-x login_newHead" style="margin:0"> 
                      <img src="<?php echo CDN; ?>assets/images/login.png" alt="login" style="width: 18px;margin-right: 6px;"> Log In
                    </a>
                    <a href="<?php echo base_url() . 'auth'; ?>" class="desk-login-button options-gap-x sign_newHead"> 
                      <img src="<?php echo CDN; ?>assets/images/user.png" alt="login" style="width: 18px;margin-right: 6px;">Sign Up
                    </a>
                      <!-- Plan start -->
                      <?php if($page == 'plan') { ?>
                        <div class="city-drop-down" id="citymob-login">
                          <div class="city-drop-inner">
                              <div class="city-left">
                                  <img src="<?php echo CDN; ?>assets/images/location_city.svg" >
                                  <p class="city_name">
                                      <?php echo $_SESSION['login_data']['city'] ? $_SESSION['login_data']['city'] : ($_REQUEST['city'] ? $_REQUEST['city'] :  'Delhi NCR');?>
                                  </p>
                              </div>
                              <div class="city-right">
                                  <img src="<?php echo CDN; ?>assets/images/city-drop-icon.svg" >
                              </div>
                          </div>
                        </div>
                      <?php } ?>
                      <!-- Plan end -->
                    
                    <?php 
                }
                else if(!isset($_SESSION['login_data']))
                {
                      // if (strtolower($this->router->class) == 'product' || $page === 'home')
                      if( $page === 'home' || $page === 'product' || $page === 'zingercopper' || $page === 'bolt' || $page === 'stealth-under-sink' ||  $page === 'hydroboost') 
                      {
                    ?>
                        <button class="enquire_popup_out enq_btn">Enquire Now</button>
                        <a href="<?php echo base_url() . 'auth?type=1'; ?>" class="desk-login-button options-gap-x login_newHead" style="margin:0"> 
                          <img src="<?php echo CDN; ?>assets/images/login.png" alt="login" style="width: 18px;margin-right: 6px;"> Log In
                        </a>
                        <a href="<?php echo base_url() . 'auth'; ?>" class="desk-login-button options-gap-x sign_newHead"> 
                          <img src="<?php echo CDN; ?>assets/images/user.png" alt="login" style="width: 18px;margin-right: 6px;">Sign Up
                        </a>
                    <?php  } else if($page === 'investors' || (strtolower($this->router->class) == 'purifier' && strtolower($this->router->class) == 'unlimited') ){ ?>
                        <a href="<?php echo base_url() . 'auth'; ?>" class="desk-login-button options-gap-x sign_newHead"> 
                          <img src="<?php echo CDN; ?>assets/images/user.png" alt="login" style="width: 18px;margin-right: 6px;">Sign Up
                        </a>
                    <?php }

                } else if (isset($_SESSION['login_data']) != '') { ?>
                  <!-- login User start -->
                    <?php if($page == 'plan') { ?>
                      <div class="city-drop-down <?php if ((isset($_SESSION['login_data']['paymentCompleted']) && $_SESSION['login_data']['paymentCompleted'] == "true" )) { echo "disabled-city"; } ?>">
                          <div class="city-drop-inner">
                              <div class="city-left">
                                  <img src="<?php echo CDN; ?>assets/images/location_city.svg" >
                                  <p class="city_name">
                                      <?= $_SESSION['login_data']['city'] ? $_SESSION['login_data']['city'] : 'Delhi NCR'?>
                                  </p>
                              </div>
                              <div class="city-right">
                                  <img src="<?php echo CDN; ?>assets/images/city-drop-icon.svg" >
                              </div>
                          </div>
                      </div>
                    <?php } ?>
                    <div class="user-account-wrapper">
                        <div class="user-account"><i class="fa fa-user-circle"></i></div>
                        <ul class="user-account-content">
                            <li><a href="<?=base_url() . 'updateuser'?>">Update Profile</a></li>
                            <li><a href="<?=base_url() . 'auth/logout'?>" onclick="sessionLogout()">Logout</a></li>
                        </ul>
                    </div>
                    <!-- login User end -->
                <?php } ?>
                    
              </div>

            <?php  
          } ?>
			</div>
		</nav>
    
    <script>
        function sessionLogout() {
            analytics.track('Signed Out', {
                "username": "<?=isset($_SESSION['login_data']['userId']) ? $_SESSION['login_data']['userId'] : ""?>"
            });
            analytics.reset();
        }
    </script>

    <?php if (isset($_REQUEST['r']) == true) { ?>
      <div class="modal" id="modal"></div>
    <?php } 
     $this->load->view('common/initialScripts'); ?>

  <!-- header js -->
  <script>
        // mobile toggle
        document.addEventListener("DOMContentLoaded", function () {
            var bnavbarToggle = document.querySelector(".bnavbar-toggle");
            var bnavbar = document.getElementById("bnavbar");
            bnavbarToggle.addEventListener("click", function () {
              bnavbar.classList.toggle("active");
              this.classList.toggle('active');
            });
            // fixed haeder
            var header = document.querySelector('header');
            var headerHeight = 150;
            window.addEventListener('scroll', function () {
                if (window.scrollY > headerHeight) {
                    header.classList.add('fixed-header');
                } else {
                    header.classList.remove('fixed-header');
                }
            });
            // drpdown js
            const waterPurifierDropdown = document.getElementById("water-purifier-dropdown");
            const RO_dropdown = document.getElementById("RO_dropdown");
            waterPurifierDropdown.addEventListener("click", function () {
              this.classList.toggle("active");
            });
            RO_dropdown.addEventListener("click", function (event) {
              event.stopPropagation();
              this.classList.toggle("active");
            });
            // Close dropdowns when clicking outside
            document.addEventListener("click", function (event) {
              const isClickInsideWaterPurifierDropdown = waterPurifierDropdown.contains(event.target);
              const isClickInsideRODropdown = RO_dropdown.contains(event.target);
              if (!isClickInsideWaterPurifierDropdown) {
                waterPurifierDropdown.classList.remove("active");
              }
              if (!isClickInsideRODropdown) {
                RO_dropdown.classList.remove("active");
              }
          });
        // help drpdown
          const help_drpdown = document.getElementById("help_drpdown");
          document.addEventListener("click", function (event) {
            const isClickInsideDropdown = help_drpdown.contains(event.target);
            if (!isClickInsideDropdown) {
              help_drpdown.classList.remove("active");
            }
          });
          help_drpdown.addEventListener("click", function () {
            this.classList.toggle("active");
          });
        });
  </script>
<!-- header js end -->

</header>
<?php $this->load->view('common/breadcrumb'); ?>
<?php if(STICKYMESSAGE && (strtolower($page) === 'plan') && (isset($_SESSION['login_data']))) $this->load->view('common/stickyMessage');
?>

<?php if (isset($_SESSION['login_data'])) {
    if (isset($_SESSION['login_data']['emiStatus']) && $_SESSION['login_data']['emiStatus'] == 'pending') {
        $this->load->view('common/pendingEMISticky');
    }
}
