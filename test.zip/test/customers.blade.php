@extends('layouts.app')
@section('styles')
@endsection
@section('content')
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        var customerDetailsUrl = '{{ route('getCustomerDetails') }}';
        var getCancelRequestDataUrl = '{{ route('getCancelRequestData') }}';
        var getServiceRequestUrl = '{{ route('getServiceRequest') }}';
        var updateCalllogUrl = '{{ route('updateCalllog') }}';
        var getCOVDataUrl = '{{ route('getCOVData') }}';
        var serviceRequestUrl = '{{ route('serviceRequest') }}';
        var getSubCustomerVoiceUrl = '{{ route('getSubCustomerVoice') }}';
        var getRequestReasonUrl = '{{ route('getRequestReason') }}';
        var cancelRequestUrl = '{{ route('cancelRequest') }}';
        var updateCOVUrl = '{{ route('updateCOV') }}';
        var refreshRechargeUrl = '{{ route('refreshRecharge') }}';
        var csrfToken = '{{ csrf_token() }}';
        var dronaUrl = '{{ route('callDrona') }}';
        var checkStatusUrl = '{{ route('callCheckStatus') }}';
        var getCallHistoryDataUrl = '{{ route('getCallHistoryData') }}';
        var paymentLinkDataUrl = '{{ route('paymentLinkData') }}';
    </script>

    <style>
        /*    .table td {
                                                                                                                                                       } */
        .custom-width {
            max-width: 900px;
            /* Set your desired width */
            width: 100%;
        }

        .custom-width-servcie-request {
            max-width: 1600px;
            /* Set your desired width */
            width: 100%;
        }

        .custom-width-call-log {
            max-width: 1350px;
            /* Set your desired width */
            width: 100%;
        }

        .news-ticker {
            display: none;
        }

        #breadcrumb-header {
            display: none;
        }

        element.style {}

        .card .card {
            box-shadow: none;
        }

        /* .card-body {
                                                                                                                                                            padding: 0px !important;
                                                                                                                                                        } */
        /* table.dataTable {
                                                                                                                                                            margin-block: 0px !important;
                                                                                                                                                        }
                                                                                                                                                        .table td {
                                                                                                                                                             padding: 0.0rem;
                                                                                                                                                        } */
        .card {
            margin-block-end: 0px !important;
        }

        #file-datatable_filter {
            display: none;
        }

        #file-datatable_length {
            display: none;
        }

        .flex-wrap {
            display: none;
        }



        .getCustomerDetails {
            cursor: pointer;
            color: #629cec;

        }
    </style>
    <!-- PAGE-HEADER -->

    <!-- END PAGE-HEADER -->
    <!-- Include SweetAlert library -->


    @include('waas/list')
    <!-- ROW -->

    <!-- END ROW -->
    <!-- Customer Details MODAL -->
    @include('waas/customerDetail')
    <!-- END MODAL Customer Details -->

    <!-- COV MODAL START-->

    <!-- COV Model End  -->


    @include('waas/cov_model')

    <!-- CANCELLATION / REPLACEMENT REQUEST MODAL -->
    @include('waas/cancellation_replacement_model')
    <!-- END MODAL CANCELLATION / REPLACEMENT REQUEST -->

    <!-- Service Request MODAL Start -->
    @include('waas/service_request_model')
    <!-- Service Request MODAL Start -->

    <!-- Payment Link MODAL Start -->
    @include('waas/payment_link_model')
    <!-- Payment Link MODAL Start -->


    <!--  Call log Modal Start -->
    @include('waas/call_log_model')
    <!-- Call log Modal End -->
@endsection
@section('scripts')
    <!-- SELECT2 JS -->
    <script src="{{ asset('build/assets/plugins/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('build/assets/plugins/select2/select2.full.min.js') }}"></script>
    @vite('resources/assets/js/select2.js')

    <!-- DATA TABLE JS -->

    <script src="{{ asset('build/assets/plugins/datatable/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('build/assets/plugins/datatable/js/dataTables.bootstrap5.js') }}"></script>
    <script src="{{ asset('build/assets/plugins/datatable/js/dataTables.buttons.min.js') }}"></script>
    <script src="{{ asset('build/assets/plugins/datatable/js/buttons.bootstrap5.min.js') }}"></script>
    <script src="{{ asset('build/assets/plugins/datatable/js/jszip.min.js') }}"></script>
    <script src="{{ asset('build/assets/plugins/datatable/pdfmake/pdfmake.min.js') }}"></script>
    <script src="{{ asset('build/assets/plugins/datatable/pdfmake/vfs_fonts.js') }}"></script>
    <script src="{{ asset('build/assets/plugins/datatable/js/buttons.html5.min.js') }}"></script>
    <script src="{{ asset('build/assets/plugins/datatable/js/buttons.print.min.js') }}"></script>
    <script src="{{ asset('build/assets/plugins/datatable/js/buttons.colVis.min.js') }}"></script>
    <script src="{{ asset('build/assets/plugins/datatable/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('build/assets/plugins/datatable/responsive.bootstrap5.min.js') }}"></script>
    <script>
        function newFunction() {
            //$("#field_value").val('');
            //$("#status").val('');
        }

        $(document).ready(function() {
            // newFunction();
        });
    </script>

    <script src="{{ asset('js/waas-customer.js') }}"></script>
    <script src="{{ asset('js/paymentLink.js') }}"></script>
@endsection

<!-- DATA TABLE JS -->
@vite('resources/assets/js/table-data.js')
