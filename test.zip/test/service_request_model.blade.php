<style>
    .your-custom-class {
        z-index: 99999 !important;
    }
</style>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr@4.6.6/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr@4.6.6/dist/flatpickr.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        flatpickr("#appointment_dateSR", {
            enableTime: false, // Set to true if you want to enable time selection
            dateFormat: "Y-m-d", // Define your desired date format
        });
    });
</script>
<div class="modal fade" id="serviceRequestModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog custom-width-servcie-request" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: #FD971E;">
                <h5 class="modal-title" id="example-Modal3">Create New Case</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body table-responsive b_tbl_responsive">
                <form>
                    <table class="table table-bordered text-nowrap table-striped border-bottom">
                        <tbody>

                            <tr>
                                <td>LSH Id (IOT):
                                    <input type="text" id="lshIdSR" class="form-control" name="lshIdSR" readonly>
                                </td>
                                <td>SAP Customer Code: <input type="text" id="sapCustomerCodeSR" class="form-control"
                                        name="sapCustomerCodeSR" readonly>

                                </td>
                                <td>Customer Name: <input type="text" id="customerNameSR" class="form-control"
                                        name="customerNameSR" readonly>
                                </td>
                                <td>Mobile No: <input type="text" id="mobileNoSR" class="form-control"
                                        name="mobileNoSR" readonly>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label class="form-label">Call Type: </label>
                                    <input type="text" readonly name="callTypeSR" value="Service Complaint"
                                        id="callTypeSR" class="form-control">
                                    {{-- <select name="callTypeSR" id="callTypeSR"
                                        class="form-control form-select select2 select2-hidden-accessible"
                                        tabindex="-1" aria-hidden="true">
                                        <option value="0">Select Call Type</option>
                                        <option selected="selected" value="1">Service Complaint</option>
                                        <option value="2">Installation Request</option>
                                        <option value="3">Dismantle Request</option>
                                        <option value="4">Re-installation Request</option>
                                        <option value="5">Manual Installation</option>
                                    </select> --}}
                                </td>
                                <td>Asset: <input type="text" id="assetSR" class="form-control" name="asset"
                                        readonly>
                                    {{-- LIV-STEALTH-WAAS+A1NR25D1070505 --}}
                                </td>
                                <td>CRM Dealer Name: <input type="text" id="dealer_nameSR" class="form-control"
                                        name="dealer_nameSR" value="Livpure Waas" readonly></td>
                                <td>Product: <input type="text" id="productSR" class="form-control" name="productSR"
                                        readonly></td>
                            </tr>

                            <tr>
                                <td>

                                    <div class="card">
                                        <div class="card-header">
                                            <div class="card-title">
                                                Basic Date picker
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <div class="input-group-text">
                                                        <i class="typcn typcn-calendar-outline tx-24 lh--9 op-6"></i>
                                                    </div>
                                                    <input type="text" class="form-control flatpickr-input"
                                                        id="appointment_dateSR" placeholder="Choose date"
                                                        readonly="readonly">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </td>



                                <td>
                                    <div class="form-group">
                                        <label class="form-label">Appointment Time</label>
                                        <select name="appointment_timeSR" id="appointment_timeSR"
                                            class="form-control form-select select2 select2-hidden-accessible"
                                            tabindex="-1" aria-hidden="true">
                                            <option value="07:00:00">07:00</option>
                                            <option value="08:00:00">08:00</option>
                                            <option value="09:00:00">09:00</option>
                                            <option value="10:00:00">10:00</option>
                                            <option value="11:00:00">11:00</option>
                                            <option value="12:00:00">12:00</option>
                                            <option value="13:00:00">13:00</option>
                                            <option value="14:00:00">14:00</option>
                                            <option value="15:00:00">15:00</option>
                                            <option value="16:00:00">16:00</option>
                                            <option value="17:00:00">17:00</option>
                                            <option value="18:00:00">18:00</option>
                                            <option value="19:00:00">19:00</option>
                                        </select>

                                    </div>

                                </td>
                                <td>

                                    @php
                                        $call_typeValues = DB::select('SELECT id, call_type_name FROM waas_call_type_masters');
                                        $source_of_purchaseValues = DB::select('SELECT id, source_of_purchase_name FROM wass_source_of_purchases');
                                    @endphp



                                    <div class="form-group">
                                        <label class="form-label">Customer Voice</label>
                                        <select name="customer_voiceSR" id="customer_voiceSR"
                                            class="form-control form-select select2 select2-hidden-accessible"
                                            tabindex="-1" aria-hidden="true">



                                            <option value="0">Select Call Type</option>
                                            @foreach ($call_typeValues as $call_typeValue)
                                                <option value="{{ $call_typeValue->call_type_name }}">
                                                    {{ $call_typeValue->call_type_name }}</option>
                                            @endforeach

                                        </select>
                                    </div>
                                </td>
                                <td>
                                    Status <input type="text" id="sr_statusSR" class="form-control"
                                        name="sr_statusSR" readonly>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <label class="form-label">Source of Purchase / Call</label>
                                    <select style="width: 200px;" name="source_of_purchase_callSR"
                                        id="source_of_purchase_callSR"
                                        class="form-control form-select select2 select2-hidden-accessible"
                                        tabindex="-1" aria-hidden="true">
                                        <option value="0">Select source of Purchase</option>
                                        @foreach ($source_of_purchaseValues as $source_of_purchaseValue)
                                            <option value="{{ $source_of_purchaseValue->source_of_purchase_name }}">
                                                {{ $source_of_purchaseValue->source_of_purchase_name }}</option>
                                        @endforeach



                                    </select>
                                </td>
                                <td>Remarks:
                                    <input type="text" id="service_remarkSR" class="form-control"
                                        name="service_remarkSR">
                                </td>
                                <td>Fresh Desk Id:
                                    <input type="text" id="fresh_desk_idSR" class="form-control"
                                        name="fresh_desk_idSR">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary br-7" data-bs-dismiss="modal">Close</button>
                <button type="button" id="createServiceRequest" class="btn btn-primary br-7">Create Request</button>
            </div>

            <div class="card-body" style="padding: 0px;">
                <div class="table-responsive">
                    <table class="table table-bordered text-nowrap text-md-nowrap  table-secondary mb-0">
                        <thead>
                            <tr>
                                <th>Ticket No</th>
                                <th>Request Date</th>
                                <th>Call Type</th>
                                <th>Job Sheet No</th>
                                <th>Appointment Date</th>
                                <th>CustomerVoice</th>
                                <th>JS Status</th>
                                <th>Assigned to Name</th>
                                <th>Assigned To Contact No</th>
                                <th>Close Date</th>                               
                                <th>Kapture Ticket ID</th>                                
                                <th>#</th>
                                <th>Create By</th>
                                <th>Creation Source</th>
                                <th>Reminder</th>
                            </tr>
                        </thead>
                        <tbody id="callTableBody">

                            {{-- <tr>
                                <td>Ticket No</td>
                                <td>Request Date</td>
                                <td>Call Type</td>
                                <td>Job Sheet No</td>
                                <td>Appointment Date</td>
                                <td>CustomerVoice</td>
                                <td>JS Status</td>
                                <td>Assigned to Name</td>
                                <td>Assigned To Contact No</td>
                                <td>Close Date</td>
                                <td>FreshDeskId</td>
                                <td>Edit</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>#</td>
                                <td>Create By</td>
                                <td>Creation Source</td>
                                <td><button type="button">R</button></td>
                            </tr>
 --}}


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
