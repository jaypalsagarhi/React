<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header b_card-header">
                            <h3 class="card-title">Customers </h3>

                            @php
                            //  echo   $currentDateTime = now();
                             // echo $result = dateFormat( $currentDateTime);
                            @endphp
                        </div>
                        <div class="dropSEction">
                            <div class="row">
                                <div class="col-lg-12 col-md-12">
                                    <div class="card">
                                        <div class="card-body b_card-body">
                                            <form action="{{ route('Waas_Customer') }}" id="additionalFilter"
                                                method="post">
                                                @csrf
                                                <div class="row">
                                                    <div class="col-md-3 mb-3">
                                                        <select name="field_type" id="field_type"
                                                            class="form-control form-select select2" required>
                                                            <option value="mobile_no" selected>Mobile No</option>
                                                            <option value="alternate_mobile_no"
                                                                {{ isset($search['field_type']) && $search['field_type'] == 'alternate_mobile_no' ? 'selected' : '' }}>
                                                                Alternate Mobile No</option>
                                                            <option value="email_id"
                                                                {{ isset($search['field_type']) && $search['field_type'] == 'email_id' ? 'selected' : '' }}>
                                                                Email ID</option>
                                                            <option value="pl">Ticket No</option>
                                                            <option value="lot_user_id"
                                                                {{ isset($search['field_type']) && $search['field_type'] == 'lot_user_id' ? 'selected' : '' }}>
                                                                IOT</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3 mb-3">
                                                        <input class="form-control" name="field_value" id="field_value"
                                                            value="{{ isset($search['field_value']) ? $search['field_value'] : '' }}"
                                                            type="text">
                                                    </div>
                                                    <div class="col-md-3 mb-3">
                                                        <select name="status" id="status_dd"
                                                            class="form-control form-select select2">
                                                            <option value="0" selected disabled>Search by status
                                                            </option>
                                                            <option value="Active">Active</option>                                                          </option>
                                                            <option value="Delivered"
                                                                {{ isset($search['status']) && $search['status'] == 'Delivered' ? 'selected' : '' }}>
                                                                Delivered</option>
                                                            <option value="Installed"
                                                                {{ isset($search['status']) && $search['status'] == 'Installed' ? 'selected' : '' }}>
                                                                Installed</option>
                                                            <option value="Installation Pending"
                                                                {{ isset($search['status']) && $search['status'] == 'Installation Pending' ? 'selected' : '' }}>
                                                                Installation Pending</option>
                                                            <option value="Cancelled"
                                                                {{ isset($search['status']) && $search['status'] == 'Cancelled' ? 'selected' : '' }}>
                                                                Cancelled</option>
                                                            <option value="Reschedule"
                                                                {{ isset($search['status']) && $search['status'] == 'Reschedule' ? 'selected' : '' }}>
                                                                Reschedule</option>
                                                            <option value="On its way"
                                                                {{ isset($search['status']) && $search['status'] == 'On its way' ? 'selected' : '' }}>
                                                                On its way</option>
                                                            <option value="Rejected"
                                                                {{ isset($search['status']) && $search['status'] == 'Rejected' ? 'selected' : '' }}>
                                                                Rejected</option>
                                                            <option value="Pending"
                                                                {{ isset($search['status']) && $search['status'] == 'Pending' ? 'selected' : '' }}>
                                                                Pending</option>
                                                            <option value="Recieved At Branch"
                                                                {{ isset($search['status']) && $search['status'] == 'Recieved At Branch' ? 'selected' : '' }}>
                                                                Recieved At Branch</option>
                                                            <option value="Return to Branch"
                                                                {{ isset($search['status']) && $search['status'] == 'Return to Branch' ? 'selected' : '' }}>
                                                                Return to Branch</option>
                                                            <option value="YPending"
                                                                {{ isset($search['status']) && $search['status'] == 'Payment received' ? 'selected' : '' }}>
                                                                Payment received</option>
                                                            <option value="NPending"
                                                                {{ isset($search['status']) && $search['status'] == 'EKYC Pending' ? 'selected' : '' }}>
                                                                EKYC Pending</option>

                                                        
                                                            <option value="Assigned"
                                                                {{ isset($search['status']) && $search['status'] == 'Assigned' ? 'selected' : '' }}>
                                                                Assigned</option>
                                                            <option value="Assigned To Driver"
                                                                {{ isset($search['status']) && $search['status'] == 'Assigned To Driver' ? 'selected' : '' }}>
                                                                Assigned To Driver</option>
                                                            <option value="Closed"
                                                                {{ isset($search['status']) && $search['status'] == 'Closed' ? 'selected' : '' }}>
                                                                Closed</option>
                                                            <option value="OUT For Delivery"
                                                                {{ isset($search['status']) && $search['status'] == 'OUT For Delivery' ? 'selected' : '' }}>
                                                                OUT For Delivery</option>
                                                            <option value="Pending For Driver Assignment"
                                                                {{ isset($search['status']) && $search['status'] == 'Pending For Driver Assignment' ? 'selected' : '' }}>
                                                                Pending For Driver Assignment</option>
                                                            <option value="Pending For Pick Up"
                                                                {{ isset($search['status']) && $search['status'] == 'Pending For Pick Up' ? 'selected' : '' }}>
                                                                Pending For Pick Up</option>
                                                            <option value="Semi Cancel"
                                                                {{ isset($search['status']) && $search['status'] == 'Semi Cancel' ? 'selected' : '' }}>
                                                                Semi Cancel</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <button class="btn btn-primary btn-block btn_cutom"
                                                                    type="submit">Search</button>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <button onclick="newFunction()"
                                                                    class="btn btn-primary btn-block btn_cutom">Reset</button>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <button
                                                                    class="btn btn-primary btn-block btn_cutom">CL-S</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive export-table">
                    <table id="file-datatable" class="table table-bordered text-nowrap key-buttons border-bottom">
                        <thead>
                            <tr>
                                <th class="border-bottom-0">FULL NAME</th>
                                <th class="border-bottom-0">IOT USER ID</th>
                                <th class="border-bottom-0">MOBILE NO.</th>
                                <th class="border-bottom-0">ALTERNATE NO</th>
                                <th class="border-bottom-0">HUB NAME</th>
                                <th class="border-bottom-0">KYC DATE</th>
                                <th class="border-bottom-0">ORDER TYPE</th>
                                <th class="border-bottom-0">DELIVERY TYPE</th>
                                <th class="border-bottom-0">SAP Status</th>
                                <th class="border-bottom-0">SAFEDRINK STATUS</th>
                                <th class="border-bottom-0">COV</th>
                                <th class="border-bottom-0">SR</th>
                                <th class="border-bottom-0">SS</th>
                                <th class="border-bottom-0">PL</th>
                                <th class="border-bottom-0">CL</th>
                                <th class="border-bottom-0">SP</th>
                            </tr>
                        </thead>


                        <tbody>

                            @foreach ($data as $item)
                                @php

                                    //$mobileNumber = $item->mobile_no;
                                    //echo  $mobileNumber;
                                    //$query = "SELECT status FROM humsar.waas_call_history WHERE mobile_no = '$item->mobile_no' ORDER BY serial_no DESC LIMIT 0,1";
                                    //$callHistoryData = DB::select($query);
                                    //var_dump($callHistoryData);
                                    //dump($query, $callHistoryData);
                                    // echo $callHistoryData[0]['status'];
                                @endphp


                                <tr>
                                    <td class="getCustomerDetails" data-id="{{ $item->id }}"
                                        data-IotId="{{ $item->lot_user_id }}" data-mobileNo="{{ $item->mobile_no }}">
                                        {{ $item->full_name }}</td>
                                    <td>{{ $item->lot_user_id }}</td>
                                    <td>{{ $item->mobile_no }}</td>
                                    <td>{{ $item->alternate_mobile_no }}</td>
                                    <td>{{ $item->hub_name }}</td>

                                    <td>{{ \Carbon\Carbon::parse($item->kyc_date)->format('d M Y h:i A') }}</td>
                                    <td>{{ $item->order_type }}</td>
                                    <td>{{ $item->delivery_type }}</td>
                                    <td>   {{ $item->status }}       </td>
                                   {{--  <td>{{ isset($callHistoryData[0]->status) ? $callHistoryData[0]->status : 'No Status' }}
                                    </td> --}}

                                    <td>{{ substr($item->ekyc_message, 0, 50) }}</td>
                                    <td class="getCOVData" data-id="{{ $item->id }}">Edit</td>
                                    <td class="getServiceCompliantData" data-id="{{ $item->id }}"><i
                                            class="fa fa-cogs"></i></td>
                                    <td class="getCancelRequestData" data-id="{{ $item->id }}"><i
                                            class="fa fa-close"></i></td>
                                    <td class="getPaymentLinkData" data-id="{{ $item->id }}">
                                        <i class="fa fa-rupee"></i>
                                    </td>
                                    <td class="callLogRequestData" data-id="{{ $item->id }}">
                                        <i class="fa fa-phone"></i>
                                    </td>
                                    <td class="" data-id="{{ $item->id }}"><i class="fa fa-inr"></i>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
