<div class="modal fade" id="covModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog custom-width" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: #FD971E;">
                <h5 class="modal-title" id="example-Modal3">Update COV</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body table-responsive b_tbl_responsive">
                <form>
                    <table class="table table-bordered text-nowrap table-striped border-bottom">
                        <tbody>
                            <input type="hidden" id="wass_customer_detail_id" value="">
                            <tr>
                                <td> Customer Voice:
                                    <span id="customerVoiceDiv"></span>
                                </td>
                                <td> Sub Customer Voice:
                                    <span id='subCustomerVoiceDiv'>
                                        <select></select>
                                    </span>
                                </td>
                            </tr>

                            <tr>
                                <td>{{--  Kapture Ticket ID: --}}
                                    <input type="text" class="form-control" id="cov_ticket_id" name="input"
                                        placeholder="Kapture Ticket ID">
                                </td>
                                <td>
                                    {{--  Reason --}}
                                    <span>
                                        <textarea class="form-control" id="covReason" rows="3" placeholder="Write a reason here ..."></textarea>
                                    </span>
                                </td>
                                {{--  <td><input type="text" id="agentRamarks"></td> --}}
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary br-7" data-bs-dismiss="modal">Close</button>
                <button type="button" id="update_cov" class="btn btn-primary br-7">Update</button>
            </div>
        </div>
    </div>
</div>