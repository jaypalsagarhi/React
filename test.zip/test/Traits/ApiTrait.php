<?php

namespace App\Traits;

use Illuminate\Support\Facades\Http;
use App\Models\WaasCustomerDetail;
use App\Models\WaasCallHistory;
use App\Models\WaasRechargeDetails;

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

trait ApiTrait
{
    public function hitApi($url, $method = 'GET', $params = [])
    {
        $response = Http::withHeaders([
            // Add any headers if required
        ])->$method($url, $params);

        return $response->json();
    }

    function GetWAASCustomer($mobile){
       //echo $mobile;die;
        try{
            $startTime = now();
            $jsonPayload = [ 'MobileNo' => $mobile ];
            $response = Http::withHeaders([
                'Content-Type' => 'application/json',
                'Authorization' => 'Basic UE9fUE9QX1JGQzpsdGRAMTIzNA=='
            ])->send('POST','https://poqas.sar-group.com/RESTAdapter/CallCenter_DashBoard', [
                'body' => json_encode($jsonPayload)
            ]);
            $startTime = now();
            $data = $response->json();
          // echo '<pre>API Data Array';
          // echo '<br>'; 
          // echo '-------------------------------------------------';
          // print_r($data);die;
            if(!empty($data['Basic_Details']['Status'])){
                $Status = strtolower($data['Basic_Details']['Status']);
                if($Status != "mobile number does not exist"){
                    // Basic Details
                    if ($Status == "active" || $Status == "machine not found"){
                        $IsActive = "0";
                    }else{
                        $IsActive = "1";
                    }
                    $lot_user_id = $data['Basic_Details']['Lot_User_ID'];
//die;
                    $record = [
                        'lot_user_id' => $lot_user_id,
                        'company_id' => $data['Basic_Details']['Company_ID'],
                        'full_name' => $data['Basic_Details']['Full_Name'],
                        'mobile_no' => $data['Basic_Details']['Mobile_No'],
                        'alternate_mobile_no' => $data['Basic_Details']['Alternate_Mobile_No'],
                        'area' => $data['Basic_Details']['Area'],
                        'city' => $data['Basic_Details']['City'],
                        'state' => $data['Basic_Details']['State'],
                        
                        'purchase_date' => date("Y-m-d H:i:s", strtotime($data['Basic_Details']['PurchaseDate'])),
                        'business_type' => $data['Basic_Details']['Business_Type'],
                        'hub_name' => $data['Basic_Details']['Plant_Name'],
                        'hub_code' => $data['Basic_Details']['Plant_Code'],
                        'hub_address' => $data['Basic_Details']['Plant_Address'],
                        

                        'cutomer_create_date' => date("Y-m-d H:i:s", strtotime($data['Basic_Details']['Create_Date'])),
                        'email_id' => $data['Basic_Details']['Email_ID'],
                        'customer_delivery_address' => $data['Basic_Details']['address'],
                        'model_name' => $data['Basic_Details']['Model'],
                        'product_name' => $data['Basic_Details']['Model_Decscribtion'],
                        'serial_no' => $data['Basic_Details']['Serial_No'],
                        'challan_no' => $data['Basic_Details']['Challan_No'],
                        'challan_date' => date("Y-m-d H:i:s", strtotime($data['Basic_Details']['Challan_Date'])),
                        
                        'delivery_date' => date("Y-m-d H:i:s", strtotime($data['Basic_Details']['Delivery_Date'])),
                        'delivery_executive_mobile_no' => $data['Basic_Details']['Delivery_Executive_Mob_No'],
                        'pincode' => $data['Basic_Details']['PinCode'],
                        'sap_customer_id' => $data['Basic_Details']['SapCustomerID'],
                        'delivery_executive_username' => $data['Basic_Details']['Delivery_Executive_UserName'],
                        'delivery_executive_name' => $data['Basic_Details']['Delivery_Executive_Name'],
                        'kyc_date' => date("Y-m-d H:i:s", strtotime($data['Basic_Details']['KycDate'])),
                        
                        'kyc_time' => $data['Basic_Details']['KycTime'],
                        'base_amount' => $data['Basic_Details']['BaseAmount'],
                       // 'latitude' => $data['Basic_Details']['Latitude'],
                        //'longitude' => $data['Basic_Details']['Longitude'], // not available in basic array
                        'etd_date' =>  date("Y-m-d H:i:s", strtotime($data['Basic_Details']['Expdlv_Date'])),
                        //'eti_date' =>  date("Y-m-d H:i:s", strtotime($data['Basic_Details']['Expint_date'])),
                        'eti_date' =>  NULL,
                        //'create_date' => $data['Basic_Details']['cDate'], // need to confirm
                        'create_date' => "2022-12-14 14:46:39",                        'IsSAP' => 1,
                        'IsClosedCust' => $IsActive,
                        'status' => $data['Basic_Details']['Status'],
                        'order_type' => $data['Basic_Details']['OrderType'],
                        'deposit_amount' => $data['Basic_Details']['DepositAmount'],
                        'call_type' => $data['Basic_Details']['Calltype'],
                        'first_payment_date' => $data['Basic_Details']['FirstPaymentDate'],
                        'security_amount' => $data['Basic_Details']['SecurityAmount'],
                        'asset_date' =>  date("Y-m-d H:i:s", strtotime($data['Basic_Details']['Asset_date']))
                       
                    ];
                 

                    if(WaasCustomerDetail::where('lot_user_id', $lot_user_id)->exists()){
                       // WaasCustomerDetail::where('lot_user_id', $lot_user_id)->update($record);
                   //echo 'Update Case';
                    }else{
                        //echo 'DataToCreate';
                        //echo '<br><br><br>';
                        //var_dump($record);//die;
                      $wcdQ =   WaasCustomerDetail::create($record);
                   // var_dump($wcdQ->id);die;
                    }
                    //die;

                    // Order Details
                    $wchQ = WaasCallHistory::where('mobile_no', $data['Basic_Details']['Mobile_No'])->where('is_sap', '1')->delete();
                // echo '<pre>Order_Details'; print_r($data['Order_Details']);
                 
                    foreach($data['Order_Details'] as $orderDetail){
                     
                        $order_arr = [];
                        
                        if(!empty($orderDetail['OMS_Status'])){
                            $order_arr = [
                                'mobile_no' => $data['Basic_Details']['Mobile_No'], // not available in api order data
                                'serial_no' => $orderDetail['Srno'],
                                'ref_no' => $orderDetail['Refrence_No'],
                                'status' => $orderDetail['OMS_Status'],
                                'is_sap' => '1', 
                                'row_id' => '12',   //// extra field added                              
                                'request_date' => date("Y-m-d H:i:s", strtotime($orderDetail['Order_Status_Change_Date'])),
                                'jobsheet_no' => $orderDetail['JobsheetNo'],
                                 //'jobsheet_date' => date("Y-m-d H:i:s", strtotime($orderDetail['Jobsheet_Date'])),
                                'jobsheet_date' => "2022-12-15 09:04:53",
                                'warranty' => $orderDetail['Warranty'],
                                'assigned_to_name' => $orderDetail['Assign_name'],
                                'assigned_to_contact_no' => $orderDetail['Assign_to_mobNo'],
                                'lattitude' => $orderDetail['Lattitude'],
                                'longitude' => $orderDetail['Longitude'],
                                'jobsheet_msg' => $orderDetail['JobsheetMsg']
                            ];
                         
                          $wchQ =  WaasCallHistory::create($order_arr);
                          //$wchQ =  WaasCallHistory::create($order_arr)->toSql();
                          
                         
                        }
                    }
                   // echo '<pre>RechargeArrayqqq----'; print_r($data['Recharge_Details']);
                   //die;
//die;$data['Recharge_Details']


                    // Recharge Details
                    WaasRechargeDetails::where('mobile_no', $data['Basic_Details']['Mobile_No'])->delete();

                  
                    foreach($data['Recharge_Details'] as $rechargeDetail){
                       
                       // if(!empty($rechargeDetail['Transaction_ID'])){
                           // echo '----------------Recharge_Details--------------------';die;
                            $recharge_arr = [
                                'mobile_no' => $data['Basic_Details']['Mobile_No'] ?: '7835806412', /// not received in API
                                'transaction_id' => $rechargeDetail['Transaction_ID'] ?:  NULL,
                                'recharge_type' => $rechargeDetail['Recharge_Type'] ?: NULL,
                                'recharge_date' => $rechargeDetail['Recharge_Date'] ?: NULL,
                                'amount' => $rechargeDetail['Recharge_Amt'] ?: NULL,
                                'valid_from' => $rechargeDetail['Valid_From'] ?: NULL,  
                                'valid_to' =>   $rechargeDetail['Valid_To'] ?: NULL
                                
                            ];
                           //echo '<pre>Inside foreachRechargeArray----'; print_r($recharge_arr);die;
                            WaasRechargeDetails::create($recharge_arr);
                        //}
                    }
                    //die;
                    return true;
                }else{
                    return $data['Basic_Details']['Status'];
                }
            }else{
                return $data['Basic_Details']['Status'];
            }
        } catch (\Exception $ex) {
            $responseString = $ex->getMessage();
            return $responseString;
        }
    }

    function eKYC($mobile){
        try{
            $startTime = now();
            $response = Http::get('https://api-dev.rpsapi.in/v3/ekycIVR', [
                'mobileNo' => $mobile,
                'APIKey' => 'DsLj4CpABH6ThpN',
            ]);
            $endTime = now();
            $data = $response->json();
            if($data['status'] == "true" || $data['status'] == true){
                // echo "data: <pre>"; print_r($data);die;
                if ($data['status'] == "00"){
                    $CaseStatus = "eKYC Under Process";
                }else if($data['status'] == "01"){
                    $CaseStatus = "eKYC Address Mismatch";
                } else if($data['status'] == "02"){
                    $CaseStatus = "eKYC Docum. Mismatch";
                }else if($data['status'] == "03"){
                    $CaseStatus = "eKYC Disapproved";
                }else if ($data['status'] == "04"){
                    $CaseStatus = "eKYC Approved";
                }else{
                    $CaseStatus = "";
                }

                if($CaseStatus != ""){
                    $record['oms_status'] = $CaseStatus;
                }
                $record['oms_status'] = $CaseStatus;
                $record['ekyc_success'] = $data['success'];
                $record['ekyc_status'] = $data['status'];
                $record['ekyc_message'] = $data['message'];
                WaasCustomerDetail::where('mobile_no', $mobile)->update($record);
                return "SUCCESS";
            }else{
                return "ERROR";
            }
        } catch (\Exception $ex) {
            $responseString = $ex->getMessage();
            return $responseString;
        }
    }

    function Waascustomerdetails($mobile){
        
        //echo $mobile;
        
        try{
            $startTime = now();
            $jsonPayload = [ 'phoneNo' => $mobile ];
            $response = Http::withHeaders([
                'Content-Type' => 'application/json'
            ])->send('POST','https://api-stage.rpsapi.in/v3/admin/getCustomerDetails', [
                'body' => json_encode($jsonPayload)
            ]);

           
            $endTime = now();
            $response = $response->json();
           
           
           // echo '<pre>';print_r($response);
            //echo 'Waascustomerdetails';
          //  die;
            if($response['statusCode'] == "200"){
                $userId = $response['data']['userId'];
                if(WaasCustomerDetail::where('lot_user_id', $userId)->exists()){
                    $record = [
                        'full_name' => $response['data']['username'],
                        'mobile_no' => $response['data']['phone'],
                        'area' => $response['data']['area'],
                        'city' => $response['data']['city'],
                        'state' => $response['data']['state'],
                        'hub_code' => $response['data']['hub_code'],
                        'email_id' => $response['data']['email'],
                        'customer_category' => $response['data']['customer_category']
                    ];
                    WaasCustomerDetail::where('lot_user_id', $userId)->update($record);
                }else{
                    $record = [
                        'lot_user_id' => $userId,
                        'full_name' => $response['data']['username'],
                        'mobile_no' => $response['data']['phone'],
                        'alternate_mobile_no' => $response['data']['phone'],
                        'area' => $response['data']['area'],
                        'city' => $response['data']['city'],
                        'state' => $response['data']['state'],
                        'hub_code' => $response['data']['hub_code'],
                        'email_id' => $response['data']['email'],
                        'pincode' =>  $response['data']['hub_code'],
                        'create_date' => $response['data']['hub_code'],
                        'IsSAP' => 1,
                        'IsClosedCust' => 0,
                        'call_type' => 'K',
                        'customer_category' => $response['data']['customer_category']
                    ];
                    WaasCustomerDetail::create($record);
                }
            }else{
                return $data['success'];
            }
        } catch (\Exception $ex) {
            $responseString = $ex->getMessage();
            return $responseString;
        }
    }

    function WaasekyccustomerStatus($mobile){
        try{
            $startTime = now();
            $jsonPayload = [ 'phoneNo' => $mobile ];
            $response = Http::withHeaders([
                'Content-Type' => 'application/json'
            ])->send('POST','https://api-stage.rpsapi.in/v3/admin/getCustomerEkyc', [
                'body' => json_encode($jsonPayload)
            ]);
            $endTime = now();
            $response = $response->json();
          
            if($response['statusCode'] == 200){
                if($response['success'] == "true" || $response['success'] == true){
                    $record['oms_status'] = $response['data']['Ekyc'];
                    if(isset($response['data']['ekycStatus'])){
                        $record['oms_status'] = $response['data']['Ekyc'].$response['data']['ekycStatus'];
                    }
                    WaasCustomerDetail::where('mobile_no', $mobile)->update($record);
                    return "SUCCESS";
                }
            }
            return $response['status'];
        } catch (\Exception $ex) {
            $responseString = $ex->getMessage();
            return $responseString;
        }
    }

    function WaasekyccustomerpaymentStatus($mobile){
       
        try{
            $startTime = now();
            $jsonPayload = [ 'phoneNo' => $mobile ];
            $response = Http::withHeaders([
                'Content-Type' => 'application/json'
            ])->send('POST','https://api-dev.rpsapi.in/v3/admin/getCustomerPayment', [
                'body' => json_encode($jsonPayload)
            ]);
            $endTime = now();
            $response = $response->json();
            ///echo 'WaasekyccustomerpaymentStatus'; //die;
          //  echo '<pre>';print_r($response);die;
            if($response['statusCode'] == "200"){
                if($response['data']['paymentStatus'] == "Y"){
                    foreach($response['data']['payments'] as $payment){
                        if(WaasRechargeDetails::where('mobile_no', $mobile)->exist()){
                            $record = [
                                'recharge_date' => $payment['RechargeDate'],
                                'amount' => $payment['RechargeAmount'],
                                'transaction_id' => $payment['PaymentId'],
                                'recharge_type' => $payment['rechargeType']
                            ];
                            WaasRechargeDetails::where('mobile_no', $mobile)->update($record);
                        }else{
                            $record = [
                                'recharge_date' => date('Y-m-d H:i:s', strtotime($payment['RechargeDate'])),
                                'amount' => $payment['RechargeAmount'],
                                'transaction_id' => $payment['PaymentId'],
                                'recharge_type' => $payment['rechargeType'],
                                'mobile_no' => $mobile,
                                'is_sap' => '1',
                                'create_date' => Date("Y-m-d h:i:s")
                            ];
                            WaasRechargeDetails::create($record);
                        }                        
                    }
                    return true;
                }else{
                    return $response['statusCode'];
                }
            }else{
                return $response['statusCode'];
            }
        } catch (\Exception $ex) {
            $responseString = $ex->getMessage();
            return $responseString;
        }
    }

    function RefreshMachine($iotId){
        try{
            $startTime = now();
            $jsonPayload = [ 'userId' => $iotId ];
            $response = Http::withHeaders([
                'Content-Type' => 'application/json'
            ])->send('POST','https://api-dev.rpsapi.in/ro/refresh', [
                'body' => json_encode($jsonPayload)
            ]);
            $endTime = now();
            $response = $response->json();
            return $response['message'];
        } catch (\Exception $ex) {
            $responseString = $ex->getMessage();
            return $responseString;
        }
    }

    function dismantleRequest($record){
        try{
            $startTime = now();
            $jsonPayload = [ 
                "userId" => $record['userId'],
                "phoneNo" => $record['phoneNo'],
                "serialNo" => $record['serialNo'],
                "cancelCategory" => "Stopped Service",
                "reason" => $record['reason'],
                "appointmentDate" => $record['appointmentDate'],
                "timeslot" => $record['timeslot']
            ];
            $response = Http::withHeaders([
                'Content-Type' => 'application/json'
            ])->send('POST','https://waas-ekycapi-dev.rpsapi.in/v1/dismantle', [
                'body' => json_encode($jsonPayload)
            ]);
            $endTime = now();
            $response = $response->json();
            return $response['message'];
        } catch (\Exception $ex) {
            $responseString = $ex->getMessage();
            return $responseString;
        }
    }
}
