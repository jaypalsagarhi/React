<div class="modal fade" id="paymentLinkModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog custom-width" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: #FD971E;">
                <h5 class="modal-title" id="example-Modal3">PAYMENT LINK</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body table-responsive b_tbl_responsive">
                <form>
                    <table class="table table-bordered text-nowrap table-striped border-bottom">
                        <tbody>

                            <tr>
                                <td>LSH Id (IOT): &nbsp;&nbsp;&nbsp;&nbsp; <span id="lshIdPaylink"></span></td>
                                {{-- <td id="lshId"></td> --}}
                                <td>SAP Customer Code: &nbsp;&nbsp;&nbsp;&nbsp;<span id="sapCustomerCodePaylink"></span>
                                </td>
                                {{-- <td id="sapCustomerCode"></td> --}}
                            </tr>
                            <tr>
                                <td>Customer Name: &nbsp;&nbsp;<span id="customerNamePaylink"></span></td>
                                {{--  <td id="customerName"></td> --}}
                                <td>Mobile No: &nbsp;&nbsp;<span id="mobileNoPaylink"></span></td>
                                {{--   <td id="mobileNo"></td> --}}
                            </tr>
                            <tr>
                                <td>Email Id:&nbsp;&nbsp; <span id="emailIdPaylink"></span></td>
                                {{--  <td id="emailId"></td> --}}
                                <td>Machine Serial No:&nbsp;&nbsp; <span id="machineSerialNoPaylink"></span></td>
                                {{-- <td id="machineSerialNo"></td> --}}
                            </tr>
                            <tr>
                                <td>Delivery Type:&nbsp;&nbsp; <span id="deliveryTypePaylink"></span></td>
                                {{-- <td id="deliveryType"></td> --}}
                                <td>Status:&nbsp;&nbsp; <span id="statusPaylink"></span></td>
                                {{--  <td id="status"></td> --}}
                            </tr>
                            <tr>
                                <td>Recharge Type: <span id="orderTypePaylink">
                                        <select name="recharge_type" id="recharge_type" onchange="toggleHoliday()">                                           
                                            <option value="0" selected>Select</option>
                                            <option value="Holiday">Holiday</option>
                                            <option value="STC">STC (Sold To Customer)</option>
                                            <option value="MNF">MNF (Machine Not Found)</option>
                                        </select>
                                        <span>                                            
                                        </td>
                                <td>Order Type: <span id="order_typePaylink"> </span></td>
                            </tr>
                            <tr id="holidayChild" style="display: none;">
                                <td>Month
                                    <select name="holidayMonth" id="holidayMonth" onchange="toggleAmount()">
                                        <option value="0">SELECT MONTH</option>
                                        <option value="1">1 Month</option>
                                        <option value="2">2 Month</option>
                                        <option value="3">3 Month</option>
                                        <option value="4">4 Month</option>
                                        <option value="5">5 Month</option>
                                    </select>
                                </td>                                
                                <td> Amount
                                    <span id="holidayAmount">0</span>
                                </td>
                            </tr>
                            <tr id="stc_mnf_child" style="display: none;">
                                <td>Amount: <input type="text" name="stc_mnf_amount" id="stc_mnf_amount" value=""></td>
                                
                            </tr>
                            <tr>
                                <td>Agent Remarks: <input type="text" id="ramarksPaylink"></td>
                             
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary br-7" data-bs-dismiss="modal">Close</button>
                <button type="button" id="paymentLink" class="btn btn-primary br-7">Save</button>
            </div>
        </div>
    </div>
</div>
