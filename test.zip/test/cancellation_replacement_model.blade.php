<div class="modal fade" id="cancelRequestModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog custom-width" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: #FD971E;">
                <h5 class="modal-title" id="example-Modal3">CANCELLATION / REPLACEMENT REQUEST</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body table-responsive b_tbl_responsive">
                <form>
                    <table class="table table-bordered text-nowrap table-striped border-bottom">
                        <tbody>

                            <tr>
                                <td>LSH Id (IOT): &nbsp;&nbsp;&nbsp;&nbsp; <span id="lshId"></span></td>
                                {{-- <td id="lshId"></td> --}}
                                <td>SAP Customer Code: &nbsp;&nbsp;&nbsp;&nbsp;<span id="sapCustomerCode"></span></td>
                                {{-- <td id="sapCustomerCode"></td> --}}
                            </tr>
                            <tr>
                                <td>Customer Name: &nbsp;&nbsp;<span id="customerName"></span></td>
                                {{--  <td id="customerName"></td> --}}
                                <td>Mobile No: &nbsp;&nbsp;<span id="mobileNo"></span></td>
                                {{--   <td id="mobileNo"></td> --}}
                            </tr>
                            <tr>
                                <td>Email Id:&nbsp;&nbsp; <span id="emailId"></span></td>
                                {{--  <td id="emailId"></td> --}}
                                <td>Machine Serial No:&nbsp;&nbsp; <span id="machineSerialNo"></span></td>
                                {{-- <td id="machineSerialNo"></td> --}}
                            </tr>
                            <tr>
                                <td>Delivery Type:&nbsp;&nbsp; <span id="deliveryType"></span></td>
                                {{-- <td id="deliveryType"></td> --}}
                                <td>Status:&nbsp;&nbsp; <span id="status"></span></td>
                                {{--  <td id="status"></td> --}}
                            </tr>
                            <tr>
                                <td>Order Type: <span id="orderType"><span></td>
                                <td>Request Type: <span id="requestTypeDiv"> </span></td>
                                {{--  <td id="orderType"></td>  --}}
                            </tr>
                            <tr>

                                {{-- <td id="requestTypeDiv">                                    
                                </td> --}}
                                <td> Reason:
                                    <span id="requestReasonDiv"></span>
                                </td>
                                <td> Sub Reason:
                                    <span id='subReasonsDiv'>
                                        <select></select>
                                    </span>
                                </td>
                            </tr>
                            {{-- <tr>                                   
                                <td colspan="3" id='subReasonsDiv'>
                                 <select></select>
                                </td>
                            </tr> --}}
                            <tr>
                                <td>
                                    Pickup date & Time <span><select id='dateTime'></select></span>
                                </td>
                                <td>
                                    Timeslot: <span><select id='timeSlot'></select></span>
                                </td>

                                {{-- <td><select id='dateTime'></select></td>
                                <td><select id='timeSlot'></select></td>
                                <td><input type="text" id="relocationCity" placeholder="Enter your Relocate City">
                                </td> --}}
                            </tr>
                            <tr>
                                <td>Agent Remarks: <input type="text" id="agentRamarks"></td>
                                <td>
                                    <span>
                                        <input type="text" id="relocationCity"
                                            placeholder="Enter your Relocate City">
                                    </span>
                                </td>
                                {{--  <td><input type="text" id="agentRamarks"></td> --}}
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary br-7" data-bs-dismiss="modal">Close</button>
                <button type="button" id="cancelRequest" class="btn btn-primary br-7">Cancel Request</button>
            </div>
        </div>
    </div>
</div>