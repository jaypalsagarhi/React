<div class="modal fade" id="callLogModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog custom-width-call-log" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: #FD971E;">
                <h5 class="modal-title" id="example-Modal3">Call Log</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body table-responsive b_tbl_responsive">

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group m-0">
                                        <div class="row gutters-xs">
                                            <input type="hidden" id="cl_customer_details_id">
                                            <div class="col-3">
                                                <select name="cl_user_type" id="cl_user_type"
                                                    class="form-control form-select select2">
                                                    <option value="1">Customer</option>
                                                    <option value="2">Vendor</option>
                                                </select>
                                            </div>
                                            <div class="col-3">
                                                <select name="cl_request" id="cl_request"
                                                    class="form-control form-select select2">
                                                    <option selected="selected" value="Outbound">Outbound</option>
                                                    <option value="Inbound">Inbound</option>
                                                    <option value="Social Media">Social Media</option>
                                                    <option value="Churn">Churn</option>
                                                    <option value="Retention">Retention</option>
                                                    <option value="Legal">Legal</option>
                                                    <option value="Flipkart">Flipkart</option>
                                                </select>
                                            </div>
                                            <div class="col-3">
                                                <select name="call_log_type" id="call_log_type"
                                                    class="form-control form-select select2">
                                                    <option value="" disabled selected>Select Request Type
                                                    </option>
                                                    <option value="Query">Query</option>
                                                    <option value="Request">Request</option>
                                                    <option value="Complaint">Complaint</option>
                                                </select>
                                            </div>
                                            <div class="col-3">
                                                <select name="cl_call_request" id="cl_call_request"
                                                    class="form-control form-select select2">
                                                    <option value="" disabled selected>Call Type</option>
                                                    <option value="0">Select</option>
                                                    <option value="1">Cancellation</option>
                                                    <option value="2">Service</option>
                                                    <option value="4">Refund</option>
                                                    <option value="5">Pick Up</option>
                                                    <option value="6">Profile Updation</option>
                                                    <option value="7">Referral Voucher</option>
                                                    <option value="8">Delivery</option>
                                                    <option value="9">Installation</option>
                                                    <option value="10">Replacement</option>
                                                    <option value="11">Re-Installation</option>
                                                    <option value="12">Shifting</option>
                                                    <option value="13">General Enquiry</option>
                                                    <option value="14">Buyback</option>
                                                    <option value="15">EKYC</option>
                                                    <option value="16">Validity Extension</option>
                                                    <option value="17">Plan Change</option>
                                                    <option value="18">Call Drop</option>
                                                    <option value="63">Connected</option>
                                                    <option value="64">Not Contactable</option>
                                                    <option value="65">Out of station</option>
                                                    <option value="66">Other</option>
                                                    <option value="72">APP Related Query</option>
                                                    <option value="73">Holiday Plan</option>
                                                    <option value="74">Incomplete Information</option>
                                                    <option value="75">Junk</option>
                                                    <option value="76">Ownership Transfer</option>
                                                    <option value="77">Recharge</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">

                                    <div class="form-group m-0">

                                        <div class="row gutters-xs">


                                            <div class="col-3">
                                                <select name="cl_sub_type" id="cl_sub_type"
                                                    class="form-control form-select select2">
                                                    <option value="" disabled selected>Select Sub Type</option>
                                                    <option value="422">In Queue - Within TAT
                                                    </option>
                                                </select>
                                            </div>
                                            <div class="col-3">
                                                <select name="cl_sub_sub_type" id="cl_sub_sub_type"
                                                    class="form-control form-select select2">
                                                    <option value="" disabled selected>Select Sub Sub Type
                                                    </option>
                                                    <option value="173">Status of Cancellation Request</option>
                                                    <option value="174">Cancellation Process</option>
                                                    </option>
                                                </select>
                                            </div>
                                            <div class="col-3">
                                                <select name="cl_product" id="cl_product"
                                                    class="form-control form-select select2">
                                                    <option value="" disabled selected>Select Product
                                                    </option>
                                                    <option value="1">Bolt WAAS</option>
                                                    <option value="2">Envy WAAS</option>
                                                    <option value="3">Zinger Copper WAAS</option>
                                                    <option value="4">Zinger Hot WAAS</option>
                                                </select>
                                            </div>
                                            <div class="col-3">
                                                <div class="form-group form-elements">
                                                    <div class="form-label">Call Back</div>
                                                    <div class="custom-controls-inline">
                                                        <label class="form-check form-check-inline">
                                                            <input type="radio" name="cl_call_back"
                                                                class="form-check-input" value="Yes">
                                                            <span class="form-check-label">Yes</span>
                                                        </label>
                                                        <label class="form-check form-check-inline">
                                                            <input type="radio" class="form-check-input"
                                                                name="cl_call_back" value="No">
                                                            <span class="form-check-label">No</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                            <div class="col-md-12">
                                <textarea class="form-control" id="cl_comment" rows="3" placeholder="Write a large Call Comment ..."></textarea>
                            </div>
                        </div>

                    </div>

                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary br-7" data-bs-dismiss="modal">Close</button>
                <button type="button" id="update_calllog" class="btn btn-primary br-7">Update</button>

            </div>
            <div class="card-body" style="padding: 0px;">
                <div class="table-responsive">
                    <table class="table table-bordered text-nowrap text-md-nowrap  table-secondary mb-0">
                        <thead>
                            <tr>
                                <th>User Type</th>
                                <th>Call Type</th>
                                <th>Vendor</th>
                                <th>Call Reasons</th>
                                <th>Product</th>
                                <th>Request_type</th>
                                <th>Call Type</th>
                                <th>Sub Type</th>
                                <th>Sub Sub Type</th>
                                <th>Call Back</th>
                                <th>Call Back Date</th>
                                <th>Call Back Time</th>
                                <th>Comment</th>
                                <th>Create By</th>
                                <th>Create Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>User Type</td>
                                <td>Call Type</td>
                                <td>Vendor</td>
                                <td>Call Reasons</td>
                                <td>Product</td>
                                <td>Request_type</td>
                                <td>Call Type</td>
                                <td>Sub Type</td>
                                <td>Sub Sub Type</td>
                                <td>Call Back</td>
                                <td>Call Back Date</td>
                                <td>Call Back Time</td>
                                <td>Comment</td>
                                <td>Create By</td>
                                <td>Create Date</td>
                            </tr>



                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>